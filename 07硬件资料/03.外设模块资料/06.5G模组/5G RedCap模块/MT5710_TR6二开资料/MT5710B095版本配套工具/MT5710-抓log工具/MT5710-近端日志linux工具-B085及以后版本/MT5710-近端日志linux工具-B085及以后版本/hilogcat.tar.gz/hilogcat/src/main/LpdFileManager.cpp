#include "LpdFileManager.h"
#include <utils/mdm_log.h>
#include <utils/global_service.h>
#include <inc/custom_define.h>
#include <unistd.h>

using namespace ModemLogMdmLog;
using namespace ModemLogRingBuffer;
using namespace HsaLpdFileManager;

// 下行消息写入SD线程相关函数
LpdFileManager::LpdFileManager()
    : m_procDataBuffer(nullptr),
      m_procDataPos(0),
      m_fileHandler(nullptr),
      m_curLogFileSize(0)
{
}

int LpdFileManager::Init()
{
    if (m_procDataBuffer != nullptr) {
        free(m_procDataBuffer);
        m_procDataBuffer = nullptr;
    }

    m_procDataBuffer = reinterpret_cast<char *>(malloc(READ_IND_BUFFER_SIZE));
    if (m_procDataBuffer == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "LpdFileManager malloc memory size = %d failed.", READ_IND_BUFFER_SIZE);
        return -1;
    }
    if (m_fileHandler != nullptr) {
        fclose(m_fileHandler);
        m_fileHandler = nullptr;
    }
    m_curLogFileSize = 0;
    m_procDataPos = 0;
    AgentMsgManager::GetInstance()->ClearData();
    return 0;
}

LpdFileManager::~LpdFileManager()
{
    if (m_procDataBuffer != nullptr) {
        free(m_procDataBuffer);
        m_procDataBuffer = nullptr;
        m_procDataPos = 0;
    }

    if (m_fileHandler != nullptr) {
        fclose(m_fileHandler);
        m_fileHandler = nullptr;
    }
}

void LpdFileManager::LpdWriteProc(void *threadArg)
{
    if (threadArg == nullptr) {
        return;
    }

    LpdFileManager *thisPtr = reinterpret_cast<LpdFileManager *>(threadArg);
    if (!AgentMsgManager::GetInstance()->BufferIsEmpty()) {
        thisPtr->WriteLpdFileProc();
    } else {
        const uint64_t sleepTime = 50 * 1000;
        usleep(sleepTime);
    }
}

bool LpdFileManager::StartWriteLpdProc()
{
    if (m_writeLpdThread != nullptr && m_writeLpdThread->IsRunning()) {
        return true;
    }
    Init();
    try {
        m_writeLpdThread = new HsaThread("LpdWriteProc", LpdFileManager::LpdWriteProc, reinterpret_cast<void *>(this));
    } catch (std::bad_alloc) {
        IMODEMLOG(MDM_LOG_ERROR, "Fail to create lpd writing thread");
        m_writeLpdThread = nullptr;
        return false;
    }
    m_writeLpdThread->StartRun();
    IMODEMLOG(MDM_LOG_EVENT, "Lpd writing thread start");
    return true;
}

void LpdFileManager::FlushIndBuffer()
{
    uint32_t freeBytes = AgentMsgManager::GetInstance()->GetFreeBytes();
    IMODEMLOG(MDM_LOG_EVENT, "About to flush ind buffer, m_procDataPos: %ld, freeBytes: %u", m_procDataPos, freeBytes);
    if (m_procDataPos > 0) { // 记录中转buffer中数据的长度（位置）
        if (!WriteLogFile(m_procDataBuffer, m_procDataPos)) {
            IMODEMLOG(MDM_LOG_ERROR, "flush ind buffer failed");
        }
        m_procDataPos = 0;
    }
    freeBytes = AgentMsgManager::GetInstance()->GetFreeBytes();
    IMODEMLOG(MDM_LOG_INFO, "Flush ind buffer finished, m_procDataPos: %ld, freeBytes: %u", m_procDataPos, freeBytes);
}

void LpdFileManager::StopWriteLpdProc()
{
    if (m_writeLpdThread == nullptr || m_writeLpdThread->IsRunning() == false) {
        IMODEMLOG(MDM_LOG_EVENT, "Lpd writing thread already stopped");
        return;
    }
    m_writeLpdThread->StopRun();
    // 刷新buffer中数据到文件中
    FlushIndBuffer();
    if (m_fileHandler != nullptr) {
        fclose(m_fileHandler);
        m_fileHandler = nullptr;
    }
    if (g_limit == 1) {
        sleep(1);
        unlink(m_prefilename.c_str());
        unlink(m_curfilename.c_str());
    }
    IMODEMLOG(MDM_LOG_EVENT, "Lpd writing thread stopped");
}

// LPD写操作处理
void LpdFileManager::WriteLpdFileProc()
{
    OmDataHdrStru omHdr;
    int dataLen =  AgentMsgManager::GetInstance()->ReadDataPacket(m_procDataBuffer + m_procDataPos,
        READ_IND_BUFFER_SIZE - m_procDataPos, omHdr);
    if (dataLen != 0 && omHdr.srcLen == dataLen) {
        m_procDataPos += dataLen;
        // 空间不满，不写文件。
        if ((m_procDataPos + PACKET_DATA_MAX_SIZE) < READ_IND_BUFFER_SIZE) {
            return;
        }
    } else {
        IMODEMLOG(MDM_LOG_DEBUG, "omHdr.srcLen %d dataLen %d", omHdr.srcLen, dataLen);
        const uint64_t sleepTime = 50 * 1000;
        usleep(sleepTime);
        return;
    }
    if (!WriteLogFile(m_procDataBuffer, m_procDataPos)) {
        IMODEMLOG(MDM_LOG_ERROR, "Write Log File failed");
        const uint64_t sleepTime = 500 * 1000;
        usleep(sleepTime);
    } else {
        m_procDataPos = 0;
    }
}

bool LpdFileManager::WriteLogFile(char* data, uint32_t length)
{
    if ((data == nullptr) || (length == 0)) {
        IMODEMLOG(MDM_LOG_ERROR, "indvalid args, data: 0x%x, lenght: %u", data, length);
        return false;
    }
    if (m_fileHandler == nullptr) {
        if (!CreateLogFile()) {
            IMODEMLOG(MDM_LOG_ERROR, "create log file failed");
            return false;
        }
    } else {
        if (m_curLogFileSize + length > LPD_FILE_MAX_SIZE) {
            if (g_limit == 1) {
                if (m_prefilename.empty()) {
                    m_prefilename = m_curfilename;
                } else {
                    unlink(m_prefilename.c_str());
                    m_prefilename.clear();
                    m_prefilename = m_curfilename;
                }
            }
            if (!CreateLogFile()) {
                IMODEMLOG(MDM_LOG_ERROR, "create log file failed");
                return false;
            }
        }
    }
    
    const char* currentData = data;
    uint32_t currentlen = length;
    const int maxWriteCount = 3;
    // 数据写入文件
    for (int i = 0; i < maxWriteCount; i++) {
        uint32_t realWriteLen = fwrite(currentData, sizeof(char), currentlen, m_fileHandler);
        if (currentlen != realWriteLen) {
            IMODEMLOG(MDM_LOG_ERROR, "(%d) File Write is Failed: errmsg errno = %d, currentlen = %d, realWriteLen = %d",
                      i, errno, currentlen, realWriteLen);
            if (currentlen > realWriteLen) {
                currentlen = currentlen - realWriteLen;
                currentData = currentData + realWriteLen;
                m_curLogFileSize += realWriteLen;
            } else {
                return false;
            }
        } else {
            m_curLogFileSize += realWriteLen;
            return true;
        }
        // 等待10ms再次写入剩下的
        const uint64_t sleepTime = 10 * 1000;
        usleep(sleepTime);
    }
    return false;
}

bool LpdFileManager::CreateLogFile()
{
    int value = 0;
    AgentMsgManager::GetInstance()->SendReqMsg(CMDID_QUERY_FILENAME_REQ, &value, sizeof(int));

    const MsgPacket *msgHead = reinterpret_cast<const MsgPacket *>(AgentMsgManager::GetInstance()->GetLpdInfo());
    if (msgHead == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "get lpd msg head info nullptr");
        return false;
    }
    const LpdFileInfo *lpdInfo = reinterpret_cast<const LpdFileInfo *>(msgHead->acData);
    if (lpdInfo == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "get lpd info nullptr");
        return false;
    }
    
    if (m_fileHandler != nullptr) {
        fclose(m_fileHandler);
        m_fileHandler = nullptr;
    }
    
    std::string lpdFileName = DEFAULT_LPDLOG_PATH + lpdInfo->fileName;
    if (g_limit == 1) {
        if (m_curfilename.empty()) {
            m_curfilename = DEFAULT_LPDLOG_PATH + lpdInfo->fileName;
        } else {
            m_curfilename.clear();
            m_curfilename = DEFAULT_LPDLOG_PATH + lpdInfo->fileName;
        }
    }
    m_fileHandler = fopen(lpdFileName.c_str(), "wb"); // 以写的方式打开文件打开文件
    if (m_fileHandler== nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "Open LPD file failed: %s, errno: %d", lpdFileName.c_str(), errno);
        return false;
    }
    IMODEMLOG(MDM_LOG_INFO, "Open LPD file success: %s", lpdFileName.c_str());
    // 写入文件头
    uint32_t dataLen = msgHead->dataLen - sizeof(lpdInfo->fileName);
    uint32_t ret = fwrite(lpdInfo->fileHead, sizeof(char), dataLen, m_fileHandler);
    if (ret != dataLen) {
        IMODEMLOG(MDM_LOG_ERROR, "File Write failed: dataLen=%d, ret=%d, errno: %d", dataLen, ret, errno);
        return false;
    }

    IMODEMLOG(MDM_LOG_INFO, "write lpd head success");
    m_curLogFileSize = dataLen;
    return true;
}
