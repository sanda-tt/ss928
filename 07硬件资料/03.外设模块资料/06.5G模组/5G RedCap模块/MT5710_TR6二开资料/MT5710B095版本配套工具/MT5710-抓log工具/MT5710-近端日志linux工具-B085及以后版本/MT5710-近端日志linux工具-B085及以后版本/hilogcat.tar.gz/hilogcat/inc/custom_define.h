#ifndef CUSTOM_DEFINE_H
#define CUSTOM_DEFINE_H

using namespace std;
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cstdarg>

#define EOK 0
typedef int errno_t;


#define USE_CCC_TDT 1

const static int TCP_CTRL_PORT = 4000;
const static int TCP_DATA_PORT = 4001;

extern string g_ip;
extern int g_limit;

#ifdef TEST_ON_PHONE
const static std::string SOCKET_IP = string("127.0.0.1");
#else
const static std::string SOCKET_IP = string("192.168.1.1");
#endif
const static std::string WORK_PATH_BASE = string("/data/modem_tool");
const static std::string PROC_LOCKFILE = WORK_PATH_BASE + string("/hsc.pid");
const static std::string LOGCAT_LOG = WORK_PATH_BASE + string("/logcat.log");
const static std::string DEFAULT_LPDLOG_PATH = WORK_PATH_BASE + string("/lpd/");

// Buffer大小
const static int DIAG_IND_BUFFER_SIZE = (50*1024*1024 + 3);
const static int READ_IND_BUFFER_SIZE = (1 * 1024 * 1024);

// 单个文件大小
const static uint32_t LPD_FILE_MAX_SIZE = (10 * 1024 * 1024);
const static uint32_t LOG_FILE_MAX_SIZE = (20 * 1024 * 1024);


errno_t memcpy_s(void *det, size_t detSize, const void * src, size_t srcSize);
errno_t strncpy_s(char *strDest, size_t destMax, const char *strSrc, size_t count);
errno_t snprintf_s(char *strDest, size_t destMax, size_t count, const char *format,...);
errno_t sprintf_s(char *strDest, size_t destMax, const char *format, ...);
errno_t vsnprintf_s(char *strDest, size_t destMax, size_t count, const char *format, ...);
errno_t memset_s(void *dest, size_t destMax, int c, size_t count);

#endif
