﻿#ifndef FILERECEIVER_H_
#define FILERECEIVER_H_

#include "CommonDef.h"
#include "FileOper_Linux.h"
#include "DataChannel_Linux.h"
#include <string.h>

class FileReceiver
{
public:
    FileReceiver();

    ~FileReceiver();

    RET_CODE PreCheck(string file_path, FILE_OFFSET file_size);

    RET_CODE Receive(const char* file_path, E_DATACHANNEL_MODE chnl_mode = DATACHANNEL_MODE_DEFAULT);


private:
    RET_CODE InitFile(const char* file_path);

    RET_CODE InitDataChnl(E_DATACHANNEL_MODE chnl_mode);

    void ExitDownloadMode(bool is_ok);

    void CleanResource();

    void SendReadyMode();

    bool ReadPacketHead();

    RET_CODE ReadOnePacket();

    bool IsSeqRepeat(UCHAR seq, UCHAR verify_code);

    bool IsSeqValid(UCHAR seq, UCHAR verify_code);

    bool IsCheckSumValid(CHAR packet_type, const CHAR *buffer, const CHAR *checksum_buffer);

    bool IsCRCValid(CHAR packet_type, const CHAR *buffer, const CHAR *checksum_buffer);

    UINT GetPacketPayloadLen(CHAR packet_type, const CHAR *buffer);

    RET_CODE SendResp(const CHAR *resp_buffer, UINT resp_len);

    CHAR GetResp();

    void CleanLogFiles();

    inline CHAR GetSeqVerifyCode(CHAR seq)
    {
        return (~seq) & 0xFF;
    }

    inline bool HasDiskSpace(FILE_OFFSET space_size);

private:
    FileOper *m_pFileOper;
    DataChannel *m_pChannel;
    CHAR m_data_buffer[DATA_PACKET_LEN];
    UINT m_data_len;
    UINT m_bypass_len;
    unsigned long m_data_seq;
    const bool m_checksum_mode;
    string m_rcv_dir;
};


typedef struct _ST_RCV_THREAD_PARA
{
    FileReceiver *obj;
    const CHAR* file_path;
    bool upgrade_flag;

    _ST_RCV_THREAD_PARA(FileReceiver *obj_para, const CHAR* file_path_para, bool upgrade_flag_para = false)
    : obj(obj_para), file_path(file_path_para), upgrade_flag(upgrade_flag_para)
    {
        // DO NOTHING, but initialization
    }

} ST_RCV_THREAD_PARA;

#endif /* FILERECEIVER_H_ */
