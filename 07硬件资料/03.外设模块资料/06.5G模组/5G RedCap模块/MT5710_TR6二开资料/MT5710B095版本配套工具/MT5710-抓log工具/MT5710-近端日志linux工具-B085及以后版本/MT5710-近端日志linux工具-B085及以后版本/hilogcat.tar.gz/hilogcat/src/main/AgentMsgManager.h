#ifndef AGENT_MSG_MANAGER_H
#define AGENT_MSG_MANAGER_H

#include <utils/ringbuffer.h>
#include <main/TcpSocketManager.h>
#include <utils/HsaThread.h>
#include <mutex>
#include <condition_variable>

using HsaThreadManager::HsaThread;
using ModemLogRingBuffer::OmRingBuff;


#pragma pack(1)
struct MsgPacket {
    uint32_t deliMiTer;
    uint16_t msgId;
    uint16_t dataLen;
    unsigned char acData[0];
};

#pragma pack()

enum EnumHsaCmdId {
    CMDID_QUERY_AGENT_INFO_REQ = 0,
    CMDID_QUERY_AGENT_INFO_CNF = 100,
    // 查询及回复文件名信息
    CMDID_QUERY_FILENAME_REQ = 1,
    CMDID_QUERY_FILENAME_CNF = 101,
    // 查询及回复UE版本信息
    CMDID_QUERY_UE_VERSION_REQ = 2,
    CMDID_QUERY_UE_VERSION_CNF = 102,
    // 查询和回复LOG抓取的启停状态
    CMDID_QUERY_HSA_STATUS_REQ = 6,
    CMDID_QUERY_HSA_STATUS_CNF = 106,
    // 设置LOG抓取的启停状态
    CMDID_SET_HSA_START_STOP_REQ = 60,

    CMDID_MAX_BOUND = 0xFFFF,
};

class AgentMsgManager {
public:
    ~AgentMsgManager();
    static AgentMsgManager *GetInstance();
    static void DelInstance();

    void StopCnfRecvProc();
    bool StartCnfRecvProc();
    void StopIndRecvProc();
    bool StartIndRecvProc();
    
    void ProcessCnfMsg(char *msgData, int32_t msgLen);
    bool SendReqMsg(short msgId, const void *data, int length);

    bool OpenCmdChannel(std::string agentIp);
    void CloseCmdChannel();
    bool OpenIndChannel(std::string agentIp);
    void CloseIndChannel();

    void ClearData()
    {
        return m_indRingBuffer.ClearData();
    }
    bool BufferIsEmpty()
    {
        return m_indRingBuffer.IsEmpty();
    }
    uint32_t ReadDataPacket(char *data, uint32_t size, OmDataHdrStru &omHdr)
    {
        return m_indRingBuffer.ReadDataPacket(data, size, omHdr);
    }
    uint32_t GetFreeBytes()
    {
        return m_indRingBuffer.GetFreeBytes();
    }
    const char *GetLpdInfo()
    {
        std::unique_lock<std::mutex> lck(m_logMtx); // m_logMtx锁住
        if (m_cond.wait_for(lck, std::chrono::seconds(2)) == std::cv_status::timeout) {
            return nullptr;
        }
        return m_lpdFileInfo;
    }
private:
    AgentMsgManager();
    AgentMsgManager(const AgentMsgManager &obj);
    AgentMsgManager &operator = (const AgentMsgManager &obj);
    bool InitCnfBuffer();
    bool InitIndBuffer();

    // 处理上层Agent回复的开启、停止状态
    static void CnfRecvProc(void *threadArg);
    static void IndRecvProc(void *threadArg);
    bool RecvCnfMsg();
    bool RecvIndMsg();

    static AgentMsgManager *m_agentManager;
    char *m_cnfMsgData;
    int m_cnfMsgLen;
    HsaThread *m_cnfRecvThread;

    TcpSocketManager m_cmdSocket;
    TcpSocketManager m_indSocket;

    HsaThread *m_indRecvThread;
    char *m_indMsgData;
    int m_indMsgLen;
    OmRingBuff m_indRingBuffer;

    // 实现同步获取lpd文件名和文件头信息
    char *m_lpdFileInfo; // lpd文件存储相关信息
    std::mutex m_logMtx;
    std::condition_variable m_cond;
};

#endif
