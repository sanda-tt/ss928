#ifndef MACRO_DEFINE_H
#define MACRO_DEFINE_H

// LPD文件路径最大长度
#define LPD_FILE_PATH_MAX (256)

// 拼接保存LOG的路径长度
#define MAX_PATH_LENGTH (256)

// 一包数据的最大长度
#define PACKET_DATA_MAX_SIZE (64*1024)
#define  MAX_SENDBUF_LEN (64*1024)

// OM消息头中的TAG
#define OM_LTE_TAG_LEN 8
#define OM_LTE_TAG 0x7a7a7e7e7e7e7a7a
#define MAX_MSG_LENGTH (64*1024)
#define  BUFFERSIZE (512)
#define OM_MSG_DELIMITER (0x9f9f9f9f)

struct OmDataHdrStru {
    uint64_t  tag;
    uint32_t  aucRsv;
    int32_t   srcLen; // 长度
};

struct LpdFileInfo {
    char fileName[LPD_FILE_PATH_MAX];
    char fileHead[0];
};

#endif