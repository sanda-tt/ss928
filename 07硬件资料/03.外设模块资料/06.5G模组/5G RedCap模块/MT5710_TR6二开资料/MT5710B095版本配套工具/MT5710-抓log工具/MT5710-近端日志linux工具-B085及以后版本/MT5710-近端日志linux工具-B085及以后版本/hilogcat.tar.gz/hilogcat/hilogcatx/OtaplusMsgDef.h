﻿#ifndef OTAPLUSMSGDEF_H_
#define OTAPLUSMSGDEF_H_

typedef enum _E_OTAPLUS_MSG_TYPE
{
    OTAPLUS_MSG_NON = 0,
    OTAPLUS_MSG_SEND_FILE,
    OTAPLUS_MSG_RCV_FILE,
    OTAPLUS_MSG_UPGRADE,
    OTAPLUS_MSG_QUERY_RESULT,
    OTAPLUS_MSG_REPORT_DATACHNL,
    OTAPLUS_MSG_LOG_QUERY,
    OTAPLUS_MSG_LOG_LEVEL,
    OTAPLUS_MSG_TMP_CLEAN,
    OTAPLUS_MSG_FW_LOAD,
} E_OTAPLUS_MSG_TYPE;

typedef enum _E_OTAPLUS_MSG_STATUS
{
    OTAPLUS_MSG_STATUS_IDEL,
    OTAPLUS_MSG_STATUS_REQ,
    OTAPLUS_MSG_STATUS_DONE,
} E_OTAPLUS_MSG_STATUS;

typedef enum _E_OTAPLUS_MSG_CFG_INDEX
{
    OTAPLUS_MSG_CFG_INDEX_OTA = 0,
    OTAPLUS_MSG_CFG_INDEX_LOG,
    OTAPLUS_MSG_CFG_INDEX_END,
} E_OTAPLUS_MSG_CFG_INDEX;

typedef enum _E_OTAPLUS_RET_STATUS
{
    E_OTAPLUS_RET_STATUS_OK = 0,
    E_OTAPLUS_RET_STATUS_ERROR,
    E_OTAPLUS_RET_STATUS_NONE
} E_OTAPLUS_RET_STATUS;

typedef enum _E_OTAPLUS_TMP_TYPE
{
    E_OTAPLUS_TMP_TYPE_PKG = 0,
    E_OTAPLUS_TMP_TYPE_LOG = 1
} E_OTAPLUS_TMP_TYPE;

typedef struct _ST_MSG_DATA
{
    int type;
    int status;
    union {
        struct
        {
            E_OTAPLUS_RET_STATUS ret_status;
            long long size;
            char path[256];
        } file;

        struct
        {
            char para[256];
        } in;

        struct
        {
            char data[1024];
        } out;
    };
} ST_MSG_DATA;

#endif  /* OTAPLUSMSGDEF_H_ */
