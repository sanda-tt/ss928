#ifndef _LPD_FILE_MANAGER_H_
#define _LPD_FILE_MANAGER_H_

#include <main/AgentMsgManager.h>
#include <dirent.h>

namespace HsaLpdFileManager {
using HsaThreadManager::HsaThread;

class LpdFileManager {
public:
    static LpdFileManager &GetInstance()
    {
        static LpdFileManager lpdFileManager;
        return lpdFileManager;
    }
    bool StartWriteLpdProc();
    void StopWriteLpdProc();
private:
    LpdFileManager();
    ~LpdFileManager();
    LpdFileManager(const LpdFileManager &processThread);
    LpdFileManager &operator = (const LpdFileManager &);

    HsaThread *m_writeLpdThread; // 写文件线程

    char *m_procDataBuffer; // 写IND中转buffer，默认申请1M
    uint64_t m_procDataPos; // 记录中转buffer中数据的长度（位置）

    std::string m_prefilename;
    std::string m_curfilename;    
    FILE* m_fileHandler;
    uint32_t m_curLogFileSize;

    // 文件操作循环
    void WriteLpdFileProc();
    void FlushIndBuffer();
    static void LpdWriteProc(void *threadArg);

    // 初始化
    int Init();

    // 创建文件
    bool CreateLogFile();
   
    // 写LPD LOG内容
    bool WriteLogFile(char *date, uint32_t length);
};
}
#endif
