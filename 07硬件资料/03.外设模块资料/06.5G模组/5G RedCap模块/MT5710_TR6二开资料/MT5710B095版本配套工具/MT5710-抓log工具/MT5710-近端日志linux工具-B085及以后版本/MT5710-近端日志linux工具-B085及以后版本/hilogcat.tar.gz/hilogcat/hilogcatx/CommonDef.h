﻿#ifndef COMMONDEF_H_
#define COMMONDEF_H_

#include <stdio.h>
#include "OtaplusLogger.h"

typedef char CHAR;
typedef unsigned char UCHAR;
typedef unsigned int  UINT;
typedef int FILE_HANDLE;
typedef int RET_CODE;
typedef long long FILE_OFFSET;

typedef enum _E_ERROR_CODE {  // ATTENTION: ALSO REFER TO OTAPLUS_TOOL_ERROR_DESC
    ERR_CODE_SUCCESS = 0,
    ERR_CODE_PARAMETER_BADCNT,
    ERR_CODE_PARAMETER_TIMEOUT,
    ERR_CODE_PARAMETER_LOG_LEVEL,
    ERR_CODE_PARAMETER_TMP_CLEAN,
    ERR_CODE_PARAMETER_DEVICE_LOG,
    ERR_CODE_PARAMETER_BKUP_LOG,
    ERR_CODE_PARAMETER_FIRMWARE_CHECK,
    ERR_CODE_CHNL_OPEN_FAIL,
    ERR_CODE_CHNL_LOCK_FAIL,
    ERR_CODE_CHNL_EXCL_FAIL,
    ERR_CODE_CHNL_INIT_FAIL,
    ERR_CODE_CHNL_NOT_EXIST,
    ERR_CODE_OBJ_NEWFAIL,
    ERR_CODE_OBJ_NULL,
    ERR_CODE_FILE_UNAUTHERIZED,
    ERR_CODE_FILE_ACCESS_FAIL,
    ERR_CODE_FILE_OPEN_FAIL,
    ERR_CODE_FILE_RESP_FAIL,
    ERR_CODE_FILE_LACKDISK,
    ERR_CODE_FILE_MKDIR_FAIL,
    ERR_CODE_FILE_WRITE_FAIL,
    ERR_CODE_FILE_TIMER_INIT,
    ERR_CODE_FILE_TIMER_EXPIRED,
    ERR_CODE_UPGRADE_FAILED,
    ERR_CODE_UPGRADE_TIMEOUT,
    ERR_CODE_AT_NOT_READY,
    ERR_CODE_AT_UPGRADE_FAIL,
    ERR_CODE_AT_DLPKG_FAIL,
    ERR_CODE_AT_QUERYVER_FAIL,
    ERR_CODE_AT_QUERYLOG_FAIL,
    ERR_CODE_AT_QUERYCHNL_FAIL,
    ERR_CODE_AT_TMPCLEAN_FAIL,
    ERR_CODE_AT_AUTO_DLOADER,
    ERR_CODE_UBOOTENV_INIT_FAIL,
    ERR_CODE_UBOOTENV_READ_CFG,
    ERR_CODE_UBOOTENV_LOAD_CFG,
    ERR_CODE_PACKET_BAD,
    ERR_CODE_RESP_BAD,
    ERR_CODE_SQ_BAD,
    ERR_CODE_SWU_FIRMWARE_EMPTY,
    ERR_CODE_SWU_FIRMWARE_MISMATCH,
    ERR_CODE_SWU_VERSION_DEGRADE,
    ERR_CODE_END_NUM,
    ERR_CODE_PRE_INIT_FAIL,
} E_ERROR_CODE;

const UINT DATA_PAYLOAD_LEN = 1024;
const UINT DATA_PAYLOAD_LEN_SOH = 128;
typedef enum _E_1KXMODEM_OFFSET
{
    XMODEM_OFFSET_TYPE = 0,
    XMODEM_OFFSET_SEQ,
    XMODEM_OFFSET_SEQ_VERIFY,
    XMODEM_OFFSET_PAYLOAD,
    XMODEM_OFFSET_CHECKSUM = XMODEM_OFFSET_PAYLOAD + DATA_PAYLOAD_LEN,
    XMODEM_OFFSET_CHECKSUM_SOH = XMODEM_OFFSET_PAYLOAD + DATA_PAYLOAD_LEN_SOH,
} E_XMODEM_OFFSET;

typedef enum _E_DATACHANNEL_MODE // ATTENTION: ALSO REFER TO DATACHANNEL_MODE_STR
{
    DATACHANNEL_MODE_USB_PCIE  = 0,
    DATACHANNEL_MODE_PCIE = 1,
    DATACHANNEL_MODE_USB  = 2,
    DATACHANNEL_MODE_DEFAULT = DATACHANNEL_MODE_USB,
    DATACHANNEL_MODE_UNKNOWN = 3,
} E_DATACHANNEL_MODE;

const CHAR OTA_XMODEM_SOH     = 0x01;                // XMODEM协议的控制字符(128Bytes per frame)
const CHAR OTA_XMODEM_STX     = 0x02;                // 1K-XMODEM协议的控制字符(1024Bytes per frame)
const CHAR OTA_XMODEM_EOT     = 0x04;                // modem协议的文件传输结束控制符
const CHAR OTA_XMODEM_ACK     = 0x06;                // 数据包正确接收时的响应
const CHAR OTA_XMODEM_NAK     = 0x15;                // 数据包错误时的响应
const CHAR OTA_XMODEM_CAN     = 0x18;                // 取消传输时的控制字符
const CHAR OTA_XMODEM_CTRLZ   = 0x1A;                // 最后一包数据长度不足一包时的填充字符
const CHAR OTA_XMODEM_C       = 0X43;                // 采用CRC校验时开始传输的控制字符
const CHAR RESP_BLANK         = 0;

const int INVALID_FD = -1;

const UINT DATA_PACKET_LEN     = XMODEM_OFFSET_PAYLOAD + DATA_PAYLOAD_LEN + 2;     // 2 for checksum
const UINT DATA_PACKET_LEN_SOH = XMODEM_OFFSET_PAYLOAD + DATA_PAYLOAD_LEN_SOH + 2; // 2 for checksum


const UINT MAX_LOG_BLOCK_SIZE = 1023;          // 日志块内容大小-不包含结束符
const UINT MAX_ALLOW_NAK_NUM = 100;
const UINT DATACHNL_TRYTIMES_MAX = 5;          // 5 <- 10
const UINT FILETRANS_INTERVAL_US = 10;        // 10 <- 200
const UINT DATACHNL_INTERVAL_READ_US  = 10;   // 10 <- 200
const UINT DATACHNL_INTERVAL_WRITE_US = 10;   // 10 <- 200
const UINT ATCHNL_INTERVAL_US    = 1000 * 50;  // 1000 * 50 <- 1000 * 20
const UINT DATACHNL_INITDELAY_US = 1000 * 50;  // 50ms for device complete write, then upside can read
const long DATACHNL_TIMEOUT_HEAD =  60 * 1;    // 单位ms
const long DATACHNL_TIMEOUT_PKT  = 100 * 1;    // 单位ms
const long DATACHNL_TIMEOUT_1S   = 1000 * 1;   // 1秒超时定时器 - 单位ms
const long FILESEND_TIMEOUT      = 1000 * 120;  // 120秒超时-正常收发场景自动续命 - 避免I/O错误导致无法终止-允许I/O重试

const CHAR MSG_NAK[]   = {OTA_XMODEM_NAK};
const CHAR MSG_ACK[]   = {OTA_XMODEM_ACK};
const CHAR MSG_CAN[]   = {OTA_XMODEM_CAN};
const CHAR MSG_READY[] = {OTA_XMODEM_C};

extern const CHAR* UPGRADE_SUCCESS;

const char ATS3_CODE_DEFAULT = 13;
const char ATS4_CODE_DEFAULT = 10;

#define CHECK_EXPR_RET(expr, code) \
    if (expr) \
    { \
        return code; \
    }

#define CHECK_EXPR_RET_VOID(expr) \
    if (expr) \
    { \
        return; \
    }

#define CHECK_EXPR_BREAK(expr) \
    if (expr) \
    {\
        break; \
    }

#endif /* COMMONDEF_H_ */
