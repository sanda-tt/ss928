#include "ChannelDataHandler.h"
#include "FileReceiver.h"
#include "OtaplusTimer.h"
#include "XModemCrc16.h"
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <libgen.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include <sys/types.h>

const FILE_OFFSET RESERVE_SPACE_MIN = 1024 * 1024; // 1MB


// 作为全局变量-而非成员变量是为了减少头文件引用过多的系统头文件-减少外部依赖
struct statfs g_disk_info;

FileReceiver::FileReceiver():
    m_pFileOper(NULL),
    m_pChannel(NULL),
    m_data_len(0),
    m_bypass_len(0),
    m_data_seq(0),
    m_checksum_mode(true),
    m_rcv_dir("")
{
    memset(m_data_buffer, 0, sizeof(m_data_buffer));
    memset(&g_disk_info, 0, sizeof(g_disk_info));
}

FileReceiver::~FileReceiver()
{
    CleanResource();
    if (m_pChannel != NULL)
    {
        delete m_pChannel;
        m_pChannel = NULL;
    }
}

void FileReceiver::CleanResource()
{
    if (m_pFileOper != NULL)
    {
        delete m_pFileOper;
        m_pFileOper = NULL;
    }
}

RET_CODE FileReceiver::InitDataChnl(E_DATACHANNEL_MODE chnl_mode)
{
    OtaplusTimeRecorder time_logger(__FUNCTION__);

    if (m_pChannel == NULL)
    {
        m_pChannel = new DataChannel();
        CHECK_EXPR_RET(m_pChannel == NULL, ERR_CODE_OBJ_NEWFAIL);
    }

    RET_CODE ret = m_pChannel->Init(chnl_mode);
    CHECK_EXPR_RET(ret != ERR_CODE_SUCCESS, ret);

    return ERR_CODE_SUCCESS;
}

bool FileReceiver::HasDiskSpace(FILE_OFFSET space_size)
{
    int ret = statfs(m_rcv_dir.c_str(), &g_disk_info);
    bool has_disk = (ret == ERR_CODE_SUCCESS) ? ((FILE_OFFSET)(g_disk_info.f_bavail * g_disk_info.f_bsize) > space_size) : false;
    if (!has_disk)
    {
        LOG_WARN("DISK LACK size %lld, total %lld, avail %lld, free %lld, req %lld",
                g_disk_info.f_bsize, g_disk_info.f_blocks, g_disk_info.f_bavail, g_disk_info.f_bfree, space_size);
    }

    return has_disk;
}

RET_CODE FileReceiver::PreCheck(string file_path, FILE_OFFSET file_size)
{
    string::size_type base_pos = file_path.rfind("/");
    if (base_pos == string::npos)
    {
        LOG_WARN("error: %s has no / found", file_path.c_str());
        return ERR_CODE_FILE_MKDIR_FAIL;
    }

    m_rcv_dir = file_path.erase(base_pos, file_path.length() - base_pos);
    if (access(m_rcv_dir.c_str(), R_OK | W_OK | X_OK) != F_OK)  // 如果不存在路径-则创建路径
    {
        RET_CODE ret = mkdir(m_rcv_dir.c_str(), PATH_CREATE_MODE);
        LOG_WARN("mkdir %s, ret: %d", m_rcv_dir.c_str(), ret);
        CHECK_EXPR_RET(ret != ERR_CODE_SUCCESS, ERR_CODE_FILE_MKDIR_FAIL);
    }

    return ERR_CODE_SUCCESS;
}

void FileReceiver::CleanLogFiles()
{
}

RET_CODE FileReceiver::InitFile(const char* file_path)
{
    // 每次进入都需要重新设置文件句柄 - 需要删除对象后重建
    CleanResource();

    string file_name = file_path;
    LOG_INFO("Log file path %s", file_path);

    m_pFileOper = new FileOper(file_name, FileOper::WRITE_MODE);
    CHECK_EXPR_RET(m_pFileOper == NULL, ERR_CODE_OBJ_NEWFAIL);

    unlink(file_name.c_str());  // 如果文件存在-则先删除文件
    return m_pFileOper->Init();
}

void FileReceiver::ExitDownloadMode(bool is_ok)
{
    if (m_pFileOper != NULL)
    {
        m_pFileOper->Complete(is_ok);
    }

    CleanResource();
}

RET_CODE FileReceiver::Receive(const char* file_path, E_DATACHANNEL_MODE chnl_mode)
{
    OtaplusTimer timer(__FUNCTION__);
    CHECK_EXPR_RET(timer.Init(FILESEND_TIMEOUT) != ERR_CODE_SUCCESS, ERR_CODE_FILE_TIMER_INIT);    // 创建并初始化超时定时器

    RET_CODE ret = InitDataChnl(chnl_mode);
    CHECK_EXPR_RET(ret != ERR_CODE_SUCCESS, ret);

    // 1K-XMODEM 互动前读清通道残留数据-避免影响数据传输
    int read_clear_counter = 10;
    while (read_clear_counter-- != 0 && m_pChannel->ReadData(m_data_buffer, sizeof(m_data_buffer)) > 0)
    {
        // do nothing, but reading clear buffer
    }
    timer.ReLife(); // 重设超时计时器

    ret = InitFile(file_path);
    CHECK_EXPR_RET(ret != ERR_CODE_SUCCESS, ret);

    m_data_seq = 0;
    bool complete_flag = false;

    ret = ERR_CODE_SWU_FIRMWARE_EMPTY;

    while (true)
    {
        if (timer.IsLifeExpired())   // 超时判断
        {
            ret = ERR_CODE_FILE_TIMER_EXPIRED;
            break;
        }

        if ((m_data_seq == 0) && timer.IsPeriodExpired())
        {
            SendReadyMode();
        }

        if (!ReadPacketHead())
        {
            if (m_data_seq > 0)
            {
                LOG_WARN("No Head Read");
                SendResp(MSG_NAK, sizeof(MSG_NAK));  // 响应报文丢包-重传
            }

            usleep(FILETRANS_INTERVAL_US);
            continue;
        }

        if (ReadOnePacket() != ERR_CODE_SUCCESS)    // 不能读到完整数据-请求重传
        {
            LOG_WARN("No Packet Full Read");
            SendResp(MSG_NAK, sizeof(MSG_NAK));
            continue;
        }
        
        timer.ReLife(); // 收到数据-短超时续命
        if (IsSeqRepeat(m_data_buffer[XMODEM_OFFSET_SEQ], m_data_buffer[XMODEM_OFFSET_SEQ_VERIFY]))
        {
            LOG_WARN("SeqRepeat %lld, %u", m_data_seq + 1, m_data_buffer[XMODEM_OFFSET_SEQ]);
            SendResp(MSG_ACK, sizeof(MSG_ACK));
            continue;
        }

        if (!IsSeqValid(m_data_buffer[XMODEM_OFFSET_SEQ], m_data_buffer[XMODEM_OFFSET_SEQ_VERIFY]))
        {
            SendResp(MSG_CAN, sizeof(MSG_CAN));
            ret = ERR_CODE_SQ_BAD;
            break;
        }

#ifdef _OTAPLUS_CHECK_SUM_MODE
        if (!IsCheckSumValid(m_data_buffer[XMODEM_OFFSET_TYPE],
                             m_data_buffer + XMODEM_OFFSET_PAYLOAD,
                             m_data_buffer + ((m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_STX)
                                             ? XMODEM_OFFSET_CHECKSUM : XMODEM_OFFSET_CHECKSUM_SOH)))
#else
        if (!IsCRCValid(m_data_buffer[XMODEM_OFFSET_TYPE],
                        m_data_buffer + XMODEM_OFFSET_PAYLOAD,
                        m_data_buffer + ((m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_STX)
                                        ? XMODEM_OFFSET_CHECKSUM : XMODEM_OFFSET_CHECKSUM_SOH)))
#endif
        {
            SendResp(MSG_NAK, sizeof(MSG_NAK));
            continue;
        }

        if ((m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_STX)
         || (m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_SOH))
        {
            // 接收到首包时-清楚设备侧的临时文件
            if (m_data_seq == 0)
            {
                CleanLogFiles();
            }

            UINT write_len = 0;
            for (UINT last_bypass_cnt = 0; last_bypass_cnt < m_bypass_len; last_bypass_cnt++)
            {
                    write_len = m_pFileOper->WriteData(&OTA_XMODEM_CTRLZ, sizeof(OTA_XMODEM_CTRLZ));
                LOG_WARN("Fill %u last ByPass FileEndCharacter %u/%u:%u",
                          m_data_seq, last_bypass_cnt, m_bypass_len, write_len);
                if (write_len != sizeof(OTA_XMODEM_CTRLZ))
                {
                    SendResp(MSG_CAN, sizeof(MSG_CAN));
                    ret = ERR_CODE_FILE_WRITE_FAIL;
                    break;
                }
            }

            m_data_seq++;
            UINT data_payload_len = GetPacketPayloadLen(m_data_buffer[XMODEM_OFFSET_TYPE], m_data_buffer + XMODEM_OFFSET_PAYLOAD);
                write_len = m_pFileOper->WriteData(m_data_buffer + XMODEM_OFFSET_PAYLOAD, data_payload_len);

            LOG_INFO("WriteData Block %u: %u & %u", m_data_seq, write_len, data_payload_len);
            if (write_len == data_payload_len)  // 数据写成功-响应OK
            {
                SendResp(MSG_ACK, sizeof(MSG_ACK));
            }
            else  // 写失败-响应停止传送
            {
                SendResp(MSG_CAN, sizeof(MSG_CAN));
                LOG_WARN("Bad Resp ret=%u, %u vs %u", m_data_seq, write_len, data_payload_len);
                ret = ERR_CODE_FILE_WRITE_FAIL;
                break;
            }
        }
        else
        {
            SendResp(MSG_ACK, sizeof(MSG_ACK));
            LOG_WARN("Complete Rcv File Block %d", m_data_seq);
            complete_flag = true;
            break;
        }
    }

    ExitDownloadMode(complete_flag);
    return (complete_flag == true) ? ERR_CODE_SUCCESS : ret;
}

void FileReceiver::SendReadyMode()
{
    RET_CODE ret = SendResp(MSG_READY, sizeof(MSG_READY));
    LOG_WARN("CCCCCC,  ret: %d", ret);
    usleep(FILETRANS_INTERVAL_US);
}

bool FileReceiver::ReadPacketHead()
{
    OtaplusTimer timer(__FUNCTION__);
    CHECK_EXPR_RET(timer.Init(DATACHNL_TIMEOUT_HEAD), false);    // 创建并初始化超时定时器

    m_data_len = 0;
    while (m_data_len < sizeof(m_data_buffer))
    {
        if (timer.IsLifeExpired())
        {
            break;
        }

        usleep(FILETRANS_INTERVAL_US);
        m_data_len += m_pChannel->ReadData(m_data_buffer + m_data_len, sizeof(m_data_buffer) - m_data_len) ;
    }

    if (m_data_len == 0)
    {
        return false;
    }

    // 数据包头三种模式 - 重传数据, 正常数据, 结束数据
    CHAR seq_repeat = (CHAR)m_data_seq;
    CHAR seq_normal = (CHAR)(m_data_seq + 1);
    CHAR head_rpt_pkt[] = {OTA_XMODEM_STX, seq_repeat, GetSeqVerifyCode(seq_repeat)};
    CHAR head_rpt_short_pkt[] = {OTA_XMODEM_SOH, seq_repeat, GetSeqVerifyCode(seq_repeat)};
    CHAR head_normal_pkt[] = {OTA_XMODEM_STX, seq_normal, GetSeqVerifyCode(seq_normal)};
    CHAR head_normal_short_pkt[] = {OTA_XMODEM_SOH, seq_normal, GetSeqVerifyCode(seq_normal)};
    CHAR head_end_pkt[]    = {OTA_XMODEM_EOT};

    for (UINT cur = 0; cur < m_data_len; cur++)
    {
        if ((!memcmp(m_data_buffer + cur, head_normal_pkt,       sizeof(head_normal_pkt)))         // 正常数据包头
         || (!memcmp(m_data_buffer + cur, head_normal_short_pkt, sizeof(head_normal_short_pkt)))   // 正常数据包头
         || (!memcmp(m_data_buffer + cur, head_rpt_pkt,          sizeof(head_rpt_pkt)))            // 重传数据包头
         || (!memcmp(m_data_buffer + cur, head_rpt_short_pkt,    sizeof(head_rpt_short_pkt)))      // 重传数据包头
         || (!memcmp(m_data_buffer + cur, head_end_pkt,          sizeof(head_end_pkt))))           // 末包数据包头
        {
            LOG_INFO("%d/%d => %d:%d:%d", cur, m_data_len,
                                          m_data_buffer[cur], m_data_buffer[cur + 1], m_data_buffer[cur + 2]);

            if (cur != 0)    // 正常模式不需要数据拷贝， m_data_buffer读取到的就是完整的数据 - 此处逻辑主要是解决数据被污染场景
            {
                CHAR read_buffer[DATA_PACKET_LEN] = { 0 };
                memcpy(read_buffer, m_data_buffer + cur, m_data_len - cur);
                memcpy(m_data_buffer, read_buffer, m_data_len - cur);
                m_data_len -= cur;
            }

            return true;
        }
        LOG_INFO("%d:%d", cur, m_data_buffer[cur]);
    }

    return false;
}

RET_CODE FileReceiver::ReadOnePacket()
{
    UINT EXPECT_LEN = 0;
    switch (m_data_buffer[XMODEM_OFFSET_TYPE])
    {
        case OTA_XMODEM_SOH:
            EXPECT_LEN = DATA_PACKET_LEN_SOH;
            break;
        case OTA_XMODEM_STX:
            EXPECT_LEN = DATA_PACKET_LEN;
            break;
        case OTA_XMODEM_EOT:
            return ERR_CODE_SUCCESS;
        default:
            return ERR_CODE_PACKET_BAD;
    }

    if (m_data_len == EXPECT_LEN)
    {
        return ERR_CODE_SUCCESS;
    }

    OtaplusTimer timer(__FUNCTION__);
    CHECK_EXPR_RET(timer.Init(DATACHNL_TIMEOUT_PKT) != ERR_CODE_SUCCESS, ERR_CODE_FILE_TIMER_INIT);    // 创建并初始化超时定时器

    while (m_data_len < EXPECT_LEN)
    {
        m_data_len += m_pChannel->ReadData(m_data_buffer + m_data_len, EXPECT_LEN - m_data_len);
        if (timer.IsLifeExpired())
        {
            return ERR_CODE_PACKET_BAD;
        }

        usleep(FILETRANS_INTERVAL_US);
    }

    return ERR_CODE_SUCCESS;
}

bool FileReceiver::IsSeqRepeat(UCHAR seq, UCHAR verify_code)
{
    CHECK_EXPR_RET(m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_EOT, false);
    return (seq == (m_data_seq & 0xFF)) && ((seq ^ verify_code) == 0xFF);
}

bool FileReceiver::IsSeqValid(UCHAR seq, UCHAR verify_code)
{
    CHECK_EXPR_RET(m_data_buffer[XMODEM_OFFSET_TYPE] == OTA_XMODEM_EOT, true);

    UCHAR expect_seq = (m_data_seq + 1) & 0xFF;
    UCHAR expect_verify_code = (~expect_seq) & 0xFF;

    bool is_valid = (seq == expect_seq) && (verify_code == expect_verify_code);
    if (!is_valid)
    {
        LOG_ERROR("%d: seq %d vs exp %d, verify %d vs exp %d", m_data_seq + 1, seq, expect_seq, verify_code, expect_verify_code);
    }
    else
    {
        LOG_INFO("%d: seq %d vs exp %d, verify %d vs exp %d", m_data_seq + 1, seq, expect_seq, verify_code, expect_verify_code);
    }

    return is_valid;
}

bool FileReceiver::IsCheckSumValid(CHAR packet_type, const CHAR *buffer, const CHAR *checksum_buffer)
{
    CHECK_EXPR_RET(packet_type == OTA_XMODEM_EOT, true);

    unsigned checksum_calc = 0;
    if (m_checksum_mode)
    {
        for (UINT index = 0; index < DATA_PAYLOAD_LEN; index++)
        {
            checksum_calc += (unsigned char)buffer[index];
        }

        bool is_valid = (checksum_calc & 0xFF) == (checksum_buffer[0] & 0xFF);
        if (!is_valid)
        {
            LOG_ERROR("checksum rcv: %d, exp: %d", (checksum_buffer[0] & 0xFF), (checksum_calc & 0xFF));
        }
        return is_valid;
    }

    return false;
}

bool FileReceiver::IsCRCValid(CHAR packet_type, const CHAR *buffer, const CHAR *checksum_buffer)
{
    CHECK_EXPR_RET(packet_type == OTA_XMODEM_EOT, true);

    unsigned char* crc_buffer = (unsigned char*)checksum_buffer;
    unsigned short crc16 = XModemCrc16::CalcCrc16((unsigned char*)buffer,
                                        (packet_type == OTA_XMODEM_STX) ? DATA_PAYLOAD_LEN : DATA_PAYLOAD_LEN_SOH);
    bool is_valid = (crc_buffer[0] == ((crc16 >> BIT_NUM_PER_BYTE) & 0xFF)) && (crc_buffer[1] == (crc16 & 0xFF));
    if (!is_valid)
    {
        LOG_ERROR("Receive Crc: 0x%02x%02x, exp: 0x%04x", crc_buffer[0], crc_buffer[1], crc16);
    }

    return is_valid;
}

UINT FileReceiver::GetPacketPayloadLen(CHAR packet_type, const CHAR *buffer)
{
    UINT normal_len = (packet_type == OTA_XMODEM_STX) ? DATA_PAYLOAD_LEN : DATA_PAYLOAD_LEN_SOH;
    UINT index = normal_len -1;

    m_bypass_len = 0;
    for (; index > 0; index--)
    {
        if (buffer[index] != OTA_XMODEM_CTRLZ)
        {
            break;
        }
        m_bypass_len++;
    }

    UINT payload_len = index + 1;
    LOG_INFO("GetPacketPayloadLen %u : %u, %u", m_data_seq, payload_len, m_bypass_len);
    return payload_len;
}

RET_CODE FileReceiver::SendResp(const CHAR *resp_buffer, UINT resp_len)
{
    UINT send_len = m_pChannel->SendData(resp_buffer, resp_len);

    if (send_len != resp_len)
    {
        LOG_WARN("SendResp[%lld]: %d Fail", m_data_seq, resp_buffer[0]);
        return ERR_CODE_FILE_RESP_FAIL;
    }
    else
    {
        LOG_INFO("SendResp[%lld]: %d Pass", m_data_seq, resp_buffer[0]);
        return ERR_CODE_SUCCESS;
    }
}
