#ifndef MODEMLOGCAT_HSA_UTILS_RING_BUFFER_H
#define MODEMLOGCAT_HSA_UTILS_RING_BUFFER_H

#include <string>
#include <atomic>
#include <inc/macro_define.h>

namespace ModemLogRingBuffer {
class OmRingBuff {
public:
    OmRingBuff();
    ~OmRingBuff();
    // 创建环形buffer
    bool Create(int nbytes, const char* pszBufferName);
    // 清空数据
    void ClearData();
    // 读写数据包
    int WriteDataPacket(const char *buffer, int nbytes);
    int ReadDataPacket(char *buffer, int nbuffersize, OmDataHdrStru &stHdr);

    bool IsEmpty();
    int GetFreeBytes();

private:
    OmRingBuff(const OmRingBuff &ringBuff);
    OmRingBuff &operator = (const OmRingBuff &);

    int GetData(char *buffer, int iBufferSize, int maxbytes);
    int PutData(const char *buffer, int nbytes);
    int GetOmHeader(OmDataHdrStru &omHdr);
    void UpdateAtomicPosVal(int32_t &readPos, int32_t &writePos); // 更新原子锁指针变量

    std::string m_bufferName;  // buffer名称
    char *m_bufferData;        // buffer内存地址
    int m_bufferLen;           // buffer大小
    std::atomic<int> m_writePos;   // buffer写指针位置
    std::atomic<int> m_readPos;    // buffer读指针位置
};
}
#endif // MODEMLOGCAT_HSA_UTILS_RING_BUFFER_H
