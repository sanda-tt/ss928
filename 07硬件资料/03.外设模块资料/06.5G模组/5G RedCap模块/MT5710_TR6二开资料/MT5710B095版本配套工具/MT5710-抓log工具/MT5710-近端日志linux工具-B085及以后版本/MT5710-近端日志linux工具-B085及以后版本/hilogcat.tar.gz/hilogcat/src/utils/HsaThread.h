#ifndef HsaThread_H
#define HsaThread_H

#include <string>
#include <pthread.h>

namespace HsaThreadManager {
typedef void (*ThreadProcFunction)(void*);
const uint32_t DEFAULT_THREAD_SIZE = 2 * 1024;
const uint32_t DEFAULT_WAIT_SECS = 2;

enum ThreadState {
    TS_INIT = 0,
    TS_STARTED = 1,
    TS_STOPPING = 2,
    TS_STOPPED = 3
};

struct ThreadArg {
    void *threadObj;
    ThreadProcFunction procFunction;
    void *procArg;
    ThreadArg()
    {
        threadObj = nullptr;
        procFunction = nullptr;
        procArg = nullptr;
    }
};

class HsaThread {
public:
    HsaThread(std::string threadName, ThreadProcFunction procFunction, void *procArg);
    ~HsaThread();

    inline pthread_t ThreadId()
    {
        return m_threadId;
    }

    inline bool IsRunning()
    {
        return m_isRunning;
    }

    inline int GetThreadState()
    {
        return m_threadState;
    }

    inline void SetThreadState(int state)
    {
        m_threadState = state;
        if (state == TS_STARTED) {
            m_isRunning = true;
        } else if (state == TS_STOPPED) {
            m_isRunning = false;
        }
    }

    bool StartRun();
    bool StopRun(int waitSecs = DEFAULT_WAIT_SECS);

    ThreadProcFunction m_procFunction;
    void *m_procArg;

private:
    static void *ThreadLoop(void*);

    pthread_t m_threadId;
    std::string m_threadName;
    volatile bool m_isRunning;
    volatile int m_threadState;
    ThreadArg m_threadArg;
};
}
#endif
