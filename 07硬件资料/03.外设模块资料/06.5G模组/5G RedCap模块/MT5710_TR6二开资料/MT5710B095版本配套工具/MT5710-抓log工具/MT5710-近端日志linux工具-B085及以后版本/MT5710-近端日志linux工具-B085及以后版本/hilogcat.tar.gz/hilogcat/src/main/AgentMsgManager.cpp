#include <main/AgentMsgManager.h>
#include <utils/global_service.h>
#include <utils/mdm_log.h>
#include <inc/custom_define.h>
#include <unistd.h>

using namespace ModemLogMdmLog;
using namespace HsaThreadManager;
using std::string;

AgentMsgManager *AgentMsgManager::m_agentManager = nullptr;

const int LPD_FILE_INFO_BUFFER_SIZE = 2048;

AgentMsgManager::AgentMsgManager()
    : m_cnfMsgData(nullptr),
      m_lpdFileInfo(nullptr),
      m_cnfMsgLen(0),
      m_cnfRecvThread(nullptr),
      m_indRecvThread(nullptr),
      m_indMsgData(nullptr),
      m_indMsgLen(0),
      m_indRingBuffer()
{
}

AgentMsgManager::~AgentMsgManager(void)
{
    if (m_cnfMsgData != nullptr) {
        free(m_cnfMsgData);
        m_cnfMsgData = nullptr;
        m_cnfMsgLen = 0;
    }
   
    if (m_indMsgData != nullptr) {
        free(m_indMsgData);
        m_indMsgData = nullptr;
        m_indMsgLen = 0;
    }
    if (m_lpdFileInfo != nullptr) {
        free(m_lpdFileInfo);
        m_lpdFileInfo = nullptr;
    }
}

AgentMsgManager *AgentMsgManager::GetInstance()
{
    if (m_agentManager == nullptr) {
        m_agentManager = new AgentMsgManager();
    }
    return m_agentManager;
}

void AgentMsgManager::DelInstance()
{
    if (m_agentManager != nullptr) {
        delete m_agentManager;
        m_agentManager = nullptr;
    }
}

bool AgentMsgManager::InitCnfBuffer()
{
	// 申请内存前先释放，避免内存泄漏
    if (m_cnfMsgData != nullptr) {
        free(m_cnfMsgData);
        m_cnfMsgData = nullptr;
    }
    m_cnfMsgData = reinterpret_cast<char *>(malloc(MAX_SENDBUF_LEN));
    if (m_cnfMsgData == nullptr) {
        return false;
    }


    if (m_lpdFileInfo != nullptr) {
        free(m_lpdFileInfo);
        m_lpdFileInfo = nullptr;
    }
    m_lpdFileInfo = reinterpret_cast<char *>(malloc(LPD_FILE_INFO_BUFFER_SIZE));
    if (m_lpdFileInfo == nullptr) {
        return false;
    }

    return true;
}

bool AgentMsgManager::InitIndBuffer()
{
	// 申请内存前先释放，避免内存泄漏
    if (m_indMsgData != nullptr) {
        free(m_indMsgData);
        m_indMsgData = nullptr;
    }
    m_indMsgData = reinterpret_cast<char *>(malloc(MAX_SENDBUF_LEN));
    if (m_indMsgData == nullptr) {
        return false;
    }
    if (!m_indRingBuffer.Create(DIAG_IND_BUFFER_SIZE, "IndBuffer")) {
        IMODEMLOG(MDM_LOG_ERROR, "m_indRingBuffer Create failed.");
        return false;
    }
    return true;
}

void AgentMsgManager::CnfRecvProc(void *threadArg)
{
    if (threadArg == nullptr) {
        return;
    }

    AgentMsgManager *thisPtr = reinterpret_cast<AgentMsgManager *>(threadArg);
    thisPtr->RecvCnfMsg();
}

bool AgentMsgManager::StartCnfRecvProc()
{
    if (m_cnfRecvThread != 0 && m_cnfRecvThread->IsRunning()) {
        return true;
    }
    InitCnfBuffer();
    try {
        m_cnfRecvThread = new HsaThread("CnfRecvThread", AgentMsgManager::CnfRecvProc, reinterpret_cast<void *>(this));
    } catch (std::bad_alloc) {
        IMODEMLOG(MDM_LOG_ERROR, "Create m_cnfRecvThread failed.");
        m_cnfRecvThread = nullptr;
        return false;
    }
    // 启动接收线程
    bool res = m_cnfRecvThread->StartRun();
    if (!res) {
        StopCnfRecvProc();
        IMODEMLOG(MDM_LOG_INFO, "start m_cnfRecvThread failed");
        return false;
    }
    IMODEMLOG(MDM_LOG_INFO, "m_cnfRecvThread started");
    return true;
}

void AgentMsgManager::StopCnfRecvProc()
{
    if (m_cnfRecvThread == 0 || m_cnfRecvThread->IsRunning() == false) {
        return;
    }
    m_cnfRecvThread->StopRun();
    IMODEMLOG(MDM_LOG_EVENT, "m_cnfRecvThread stopped");
}

void AgentMsgManager::IndRecvProc(void *threadArg)
{
    if (threadArg == nullptr) {
        return;
    }
    AgentMsgManager *thisPtr = reinterpret_cast<AgentMsgManager *>(threadArg);
    thisPtr->RecvIndMsg();
}

bool AgentMsgManager::StartIndRecvProc()
{
    if (m_indRecvThread != 0 && m_indRecvThread->IsRunning()) {
        return true;
    }
    InitIndBuffer();
    try {
        m_indRecvThread = new HsaThread("IndRecvThread", AgentMsgManager::IndRecvProc, reinterpret_cast<void *>(this));
    } catch (std::bad_alloc) {
        IMODEMLOG(MDM_LOG_ERROR, "Create m_indRecvThread failed.");
        m_indRecvThread = nullptr;
        return false;
    }
    // 启动发送线程
    bool res = m_indRecvThread->StartRun();
    if (!res) {
        StopIndRecvProc();
        IMODEMLOG(MDM_LOG_INFO, "start m_indRecvThread failed");
        return false;
    }
    IMODEMLOG(MDM_LOG_INFO, "start m_indRecvThread succeed");
    return true;
}

void AgentMsgManager::StopIndRecvProc()
{
    if (m_indRecvThread == 0 || m_indRecvThread->IsRunning() == false) {
        return;
    }
    m_indRecvThread->StopRun();
    IMODEMLOG(MDM_LOG_EVENT, "m_indRecvThread stopped");
}

void AgentMsgManager::ProcessCnfMsg(char *msgData, int32_t msgLen)
{
    if (msgData == nullptr || msgLen < sizeof(MsgPacket)) {
        IMODEMLOG(MDM_LOG_WARNING, "invalid msg, msgData: 0x%x, msgLen: %d", msgData, msgLen);
        return;
    }
    MsgPacket *msgHead = reinterpret_cast<MsgPacket *>(msgData);
    IMODEMLOG(MDM_LOG_INFO, "received cnf msg: %d, msgLen: %d", msgHead->msgId, msgLen);
    if (msgHead->msgId == CMDID_QUERY_AGENT_INFO_CNF) {
        if (!AgentMsgManager::GetInstance()->OpenIndChannel(g_ip)) {
            IMODEMLOG(MDM_LOG_ERROR, "OpenIndChannel failed");
        }
        AgentMsgManager::GetInstance()->StartIndRecvProc();
    } else if (msgHead->msgId == CMDID_QUERY_HSA_STATUS_CNF) {
        uint32_t state = *reinterpret_cast<uint32_t*>(msgHead->acData);
        IMODEMLOG(MDM_LOG_DEBUG, "received modem log state: %d", state);
        if (state == MODEMLOG_STOP) {
            GlobalService::m_processExit = true;
        }
    } else if (msgHead->msgId == CMDID_QUERY_FILENAME_CNF) {
       #ifdef USE_CCC_TDT
        int err =  memcpy_s(m_lpdFileInfo, LPD_FILE_INFO_BUFFER_SIZE, msgData, msgLen);
        
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "copy lpd file info failed, errno: %d", err);
        }
        #endif
        m_cond.notify_one();
    }
}

bool AgentMsgManager::SendReqMsg(short msgId, const void *data, int length)
{
    if (length > MAX_MSG_LENGTH) {
        IMODEMLOG(MDM_LOG_ERROR, "too large data ignored, length = %d", length);
        return false;
    }

    MsgPacket *msgHead = reinterpret_cast<MsgPacket *>(malloc(sizeof(MsgPacket) + length));
    if (msgHead == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "send req msg: malloc failed.");
        return false;
    }
    msgHead->deliMiTer = OM_MSG_DELIMITER;
    msgHead->msgId = msgId;
    msgHead->dataLen = length;
    if (data != nullptr) {
       #ifdef USE_CCC_TDT
        int err = memcpy_s(msgHead->acData, length, data, length);
        
        if (err != EOK) {
            free(msgHead);
            return false;
        }
        #endif
    }
   
    uint32_t sentSize = 0;
    bool ret = m_cmdSocket.SendMsg(reinterpret_cast<const char *>(msgHead), sizeof(MsgPacket) + length, sentSize);
    if (!ret && sentSize == 0) {
        IMODEMLOG(MDM_LOG_ERROR, "AgentMsgManager::SendCnfMsg failed");
        free(msgHead);
        return false;
    }
  
    return true;
}

bool AgentMsgManager::OpenCmdChannel(string agentIp)
{
    if (!m_cmdSocket.OpenAsClient(agentIp, TCP_CTRL_PORT)) {
        return false;
    }
    return true;
}

void AgentMsgManager::CloseCmdChannel()
{
    m_cmdSocket.CloseTcpSocket();
}

bool AgentMsgManager::OpenIndChannel(string agentIp)
{
    if (!m_indSocket.OpenAsClient(agentIp, TCP_DATA_PORT)) {
        return false;
    }
    return true;
}

void AgentMsgManager::CloseIndChannel()
{
    m_indSocket.CloseTcpSocket();
}

bool AgentMsgManager::RecvCnfMsg()
{
    uint32_t recvedSize = 0;
    if (!m_cmdSocket.RecvMsg(m_cnfMsgData, MAX_SENDBUF_LEN, recvedSize)) {
        const uint64_t sleepTime = 50 * 1000;
        usleep(sleepTime);
        return false;
    }
    if (recvedSize <= 0) {
        return false;
    }
    ProcessCnfMsg(m_cnfMsgData, recvedSize);
    return true;
}

uint32_t g_curPackSize = 0;
uint32_t g_curRecvSize = 0;
uint32_t g_subPackId = 0;

bool AgentMsgManager::RecvIndMsg()
{
    // 判断缓冲区中是否有数据加长度的空间(8kb)
    uint32_t res = m_indRingBuffer.GetFreeBytes();
    if (res < MAX_MSG_LENGTH) {
        IMODEMLOG(MDM_LOG_ERROR, "Ind ring buffer empty");
        const uint64_t sleepTime = 1000;
        usleep(sleepTime);
        return false;
    }

    uint32_t recvedSize = 0;
    if (!m_indSocket.RecvMsg(m_indMsgData, MAX_SENDBUF_LEN, recvedSize)) {
        const uint64_t sleepTime = 50 * 1000;
        usleep(sleepTime);
        return false;
    }
    if (recvedSize == 0 || recvedSize > MAX_SENDBUF_LEN) {
        return false;
    }
    //IMODEMLOG(MDM_LOG_ERROR, "MAX_SENDBUF_LEN 64K, recvedSize: %d", recvedSize);
    res = m_indRingBuffer.WriteDataPacket(m_indMsgData, recvedSize);
    if (res != recvedSize) {
        IMODEMLOG(MDM_LOG_ERROR, "WriteDataPacket failed, res: %u, srcLen: %d", res, recvedSize);
        return false;
    }
    return true;
}
