#ifndef TCP_SOCKET_MANAGER_H
#define TCP_SOCKET_MANAGER_H

#include <string>
#include <netinet/in.h>
#include <utils/HsaThread.h>
#include <sys/socket.h>
#include <cerrno>

const static int MAX_BACKLOG = 10; // 连接请求队列最大长度
const static int TCP_DEFAULT_WAIT_USECS = 50 * 1000;
const static int DEFAULT_WAIT_CNT_FOR_LOG = 1200; // 用于一分钟打印一次LOG的情况

class TcpSocketManager {
public:
    TcpSocketManager();
    ~TcpSocketManager();
    bool OpenAsServer(int serverPort);
    bool OpenAsClient(std::string serverIp, int serverPort);
    static void AcceptTcpClient(void *thisPtr);
    void CloseTcpSocket();

    bool RecvMsg(char *msgBuf, uint32_t bufSize, uint32_t &recvedSize);
    bool SendMsg(const char *msgData, uint32_t msgSize, uint32_t &sentSize);


private:
    // 启动/停止接收客户端连接的线程
    bool StartAcceptingProc();
    void StopAcceptingProc();
    bool SetNonBlockMode(int socketFd);
    bool CheckConnection(int32_t &sockFd, int checkCnt);

    std::string m_serverIp;
    int m_serverPort;
    int m_hostSocketFd;
    int m_peerSocketFd;
    HsaThreadManager::HsaThread *m_acceptingThread;
    int m_curRecvCnt;
};

#endif // TCP_SOCKET_MANAGER_H
