#include "ringbuffer.h"
#include <cstdlib>
#include <utils/mdm_log.h>
#include <unistd.h>
#include "global_service.h"
#include <inc/custom_define.h>

using namespace ModemLogRingBuffer;
using namespace ModemLogMdmLog;
using namespace std;

#define OM_MIN(x, y) (((x) < (y)) ? (x) : (y))

const int RING_BUFFER_MAX_SIZE = 256 * 1024 * 1024; // 256M

OmRingBuff::OmRingBuff()
    : m_bufferName(""),
      m_bufferData(nullptr),
      m_bufferLen(0),
      m_writePos(0),
      m_readPos(0)
{}

OmRingBuff::~OmRingBuff()
{
    if (m_bufferData != nullptr) {
        free(m_bufferData);
        m_bufferData = nullptr;
    }
}

bool OmRingBuff::Create(int nbytes, const char *pszBufferName)
{
    int actualBytes = nbytes + 1;
    if (actualBytes <= 0 || actualBytes > RING_BUFFER_MAX_SIZE) {
        IMODEMLOG(MDM_LOG_ERROR, "Invalid params, buffer size: %d", actualBytes);
        return false;
    }
    // 申请内存前先释放，避免内存泄漏
    if (m_bufferData != nullptr) {
        free(m_bufferData);
        m_bufferData = nullptr;
    }
    m_bufferData = reinterpret_cast<char *>(malloc(actualBytes));
    if (m_bufferData == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "malloc failed");
        return false;
    }

    m_bufferLen = actualBytes;
    m_bufferName = pszBufferName;
    ClearData();
    IMODEMLOG(MDM_LOG_INFO, "Create m_bufferName[%s], m_bufferLen[%d]", m_bufferName.c_str(), m_bufferLen);
    return true;
}

void OmRingBuff::ClearData()
{
    m_writePos.store(0, memory_order_release);
    m_readPos.store(0, memory_order_release);
}

int OmRingBuff::GetData(char *buffer, int iBufferSize, int maxbytes)
{
    if (m_bufferData == nullptr || buffer == nullptr || maxbytes <= 0) {
        return 0;
    }

    int bytesgot;
    int pToBuf;
    int pFromBufRef;
    UpdateAtomicPosVal(pFromBufRef, pToBuf);
    if (pToBuf >= pFromBufRef) {
        /* pToBuf has not wrapped around */
        bytesgot = OM_MIN(maxbytes, pToBuf - pFromBufRef);
       #ifdef USE_CCC_TDT
       int err = memcpy_s(buffer, iBufferSize, m_bufferData + pFromBufRef, bytesgot);
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d, %d, %d", err, maxbytes, bytesgot);
            return -1;
        }
        #endif
        pFromBufRef += bytesgot;
    } else {
        /* pToBuf has wrapped around.  Grab chars up to the end of the
         * buffer, then wrap around if we need to. */
        bytesgot = OM_MIN(maxbytes, m_bufferLen - pFromBufRef);
        if (bytesgot <= 0) {
            IMODEMLOG(MDM_LOG_ERROR, "invalid bytesgot: %d", bytesgot);
            return -1;
        }
       #ifdef USE_CCC_TDT
       int err = memcpy_s(buffer, iBufferSize, m_bufferData + pFromBufRef, bytesgot);
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d", err);
            return -1;
        }
        #endif

        int pRngTmp = pFromBufRef + bytesgot;

        /* If pFromBuf is equal to bufSize, we've read the entire buffer,
         * and need to wrap now.  If bytesgot < maxbytes, copy some more chars
         * in now. */
        if (pRngTmp == m_bufferLen) {
            int bytes2 = OM_MIN(maxbytes - bytesgot, pToBuf);
           #ifdef USE_CCC_TDT
           int err = memcpy_s(buffer + bytesgot, iBufferSize - bytesgot, m_bufferData, bytes2);
            if (err != EOK) {
                IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d", err);
                return -1;
            }
            #endif
            pFromBufRef = bytes2;
            bytesgot += bytes2;
        } else {
            pFromBufRef = pRngTmp;
        }
    }
    m_readPos.store(pFromBufRef, memory_order_release);
    return (bytesgot);
}

int OmRingBuff::PutData(const char *buffer, int nbytes)
{
    if (buffer == nullptr || nbytes <= 0 || m_bufferData == nullptr) {
        return 0;
    }

    int bytesput;
    int pFromBuf;
    int pToBuf;
    UpdateAtomicPosVal(pFromBuf, pToBuf);
    int iReaminBuffLen;
    if (pFromBuf > pToBuf) {
        /* pFromBuf is ahead of pToBuf.  We can fill up to two bytes
         * before it */
        bytesput = OM_MIN(nbytes, pFromBuf - pToBuf - 1);
        // 环形buffer剩余字节数，这里不考虑读写指针覆盖，仅仅是理论上环形buffer剩余的字节数，在memcpy_s中使用
        iReaminBuffLen = m_bufferLen - pToBuf - 1;
       #ifdef USE_CCC_TDT
       int err = memcpy_s(m_bufferData + m_writePos, iReaminBuffLen, buffer, bytesput);
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed");
        }
        #endif
        pToBuf += bytesput;
    } else if (pFromBuf == 0) {
        /* pFromBuf is at the beginning of the buffer.  We can fill till
         * the next-to-last element */
        bytesput = OM_MIN(nbytes, m_bufferLen - pToBuf - 1);
        iReaminBuffLen = m_bufferLen - pToBuf - 1;
       #ifdef USE_CCC_TDT
       int err = memcpy_s(m_bufferData + m_writePos, iReaminBuffLen, buffer, bytesput);
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d", err);
        }
        #endif
        pToBuf += bytesput;
    } else {
        /* pFromBuf has wrapped around, and its not 0, so we can fill
         * at least to the end of the ring buffer.  Do so, then see if
         * we need to wrap and put more at the beginning of the buffer. */
        bytesput = OM_MIN(nbytes, m_bufferLen - pToBuf);
        // clean fortify 20170815 mawenming
        iReaminBuffLen = m_bufferLen - pToBuf;
       #ifdef USE_CCC_TDT
       int err = memcpy_s(m_bufferData + m_writePos, iReaminBuffLen, buffer, bytesput);
        if (err != EOK) {
            IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d", err);
        }
        #endif

        int pRngTmp = pToBuf + bytesput;
        if (pRngTmp == m_bufferLen) {
            /* We need to wrap, and perhaps put some more chars */
            int bytes2 = OM_MIN(nbytes - bytesput, pFromBuf - 1);
            // clean fortify 20170815 mawenming
           #ifdef USE_CCC_TDT
            err = memcpy_s(m_bufferData, m_bufferLen, buffer + bytesput, bytes2);
            if (err != EOK) {
                // ring buffer 操作特殊，内存拷贝出错只记录，不改变处理逻辑
                IMODEMLOG(MDM_LOG_ERROR, "memcpy_s failed, errno: %d", err);
            }
            #endif

            pToBuf = bytes2;
            bytesput += bytes2;
        } else {
            pToBuf = pRngTmp;
        }
    }
    m_writePos.store(pToBuf, memory_order_release);
    return (bytesput);
}

bool OmRingBuff::IsEmpty()
{
    if (m_bufferData == nullptr) {
        return true; // ST 缓存未初始化时，认为空状态
    }
    // 原子操作 20170728 mawenming
    int32_t readPos = 0;
    int32_t writePos = 0;
    UpdateAtomicPosVal(readPos, writePos);

    return (readPos == writePos);
}

int OmRingBuff::GetFreeBytes()
{
    if (m_bufferData == nullptr) {
        return 0;
    }

    // 原子指针操作 20170728 mawenming
    int32_t readPos = 0;
    int32_t writePos = 0;
    UpdateAtomicPosVal(readPos, writePos);
    int n = readPos - writePos - 1;

    if (n < 0) {
        n += m_bufferLen;
    }
    return (n);
}

int OmRingBuff::WriteDataPacket(const char *buffer, int nbytes)
{
    // ignore invalid data
    if (IsEmpty()) {
        if (nbytes < sizeof(OmDataHdrStru)) {
            IMODEMLOG(MDM_LOG_WARNING, "Invalid data ignored[%d]: %s", nbytes,
                GlobalService::GetHexString(reinterpret_cast<const unsigned char*>(buffer), nbytes).c_str());
            return 0;
        }
        const OmDataHdrStru *omHdr = reinterpret_cast<const OmDataHdrStru *>(buffer);
        if ((omHdr->srcLen <= 0) || (omHdr->tag != OM_LTE_TAG)) {
            IMODEMLOG(MDM_LOG_WARNING, "Invalid data ignored[%d]: %s", nbytes,
                GlobalService::GetHexString(reinterpret_cast<const unsigned char*>(buffer), nbytes).c_str());
            return 0;
        }
    }

    // 数据写入缓冲区
    int datalen = PutData(buffer, nbytes);
    //IMODEMLOG(MDM_LOG_DEBUG, "[%s] put data, srcLen: %d, resLen: %d",
    //        m_bufferName.c_str(), nbytes, datalen);
    if (datalen != nbytes) {
        IMODEMLOG(MDM_LOG_ERROR, "[%s] put data failed, srcLen: %d, resLen: %d",
            m_bufferName.c_str(), nbytes, datalen);
        return datalen;
    }
    return nbytes;
}

int OmRingBuff::ReadDataPacket(char *buffer, int nbuffersize, OmDataHdrStru &stHdr)
{
    // 添加校验数据长度 20170729
    if (buffer == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "[%s] get packet buffer is null", m_bufferName.c_str());
        return 0;
    }

    if (sizeof(OmDataHdrStru) != GetOmHeader(stHdr)) {
        return 0;
    }

    // 等待Ring Buffer有数据，或超过100ms
    int i = 0;
    const int timesLimit = 10;
    const uint64_t sleepTime = 10 * 1000;
    int dataLen = m_bufferLen - GetFreeBytes();
    while (dataLen < stHdr.srcLen && i < timesLimit) {
        // 等待10ms再次写入剩下的
        usleep(sleepTime);
        i++;
        dataLen = m_bufferLen - GetFreeBytes();
    }

    int datalen = GetData(buffer, nbuffersize, stHdr.srcLen);
    //IMODEMLOG(MDM_LOG_DEBUG, "[%s] get data, srcLen: %d, resLen: %d",
    //        m_bufferName.c_str(), stHdr.srcLen, datalen);
    if (datalen != stHdr.srcLen) {
        IMODEMLOG(MDM_LOG_ERROR, "[%s] get data failed, srcLen: %d, resLen: %d",
            m_bufferName.c_str(), stHdr.srcLen, datalen);
    }
    return datalen;
}

// 从RingBuffer读取消息头
int OmRingBuff::GetOmHeader(OmDataHdrStru &omHdr)
{
    int dataLen = m_bufferLen - GetFreeBytes();
    if (dataLen < sizeof(OmDataHdrStru)) {
        return 0;
    }
   #ifdef USE_CCC_TDT
    memset_s(&omHdr, sizeof(OmDataHdrStru), 0, sizeof(OmDataHdrStru));
    #endif
    if (sizeof(OmDataHdrStru) != GetData(reinterpret_cast<char *>(&omHdr),
        sizeof(OmDataHdrStru), sizeof(OmDataHdrStru))) {
        int32_t readPos = 0;
        int32_t writePos = 0;
        UpdateAtomicPosVal(readPos, writePos);
        IMODEMLOG(MDM_LOG_WARNING, "Invalid data droped[%d, read:%d, write:%d]: %s",
            dataLen, readPos, writePos,
            GlobalService::GetHexString(reinterpret_cast<const unsigned char*>(&omHdr), sizeof(OmDataHdrStru)).c_str());
        ClearData();
        return 0;
    }

    if ((omHdr.srcLen <= 0) || (omHdr.tag != OM_LTE_TAG)) {
        int32_t readPos = 0;
        int32_t writePos = 0;
        UpdateAtomicPosVal(readPos, writePos);
        IMODEMLOG(MDM_LOG_WARNING, "Invalid data droped[%d, read:%d, write:%d]: %s",
            dataLen, readPos, writePos,
            GlobalService::GetHexString(reinterpret_cast<const unsigned char*>(&omHdr), sizeof(OmDataHdrStru)).c_str());
        ClearData();
        return 0;
    }
    return static_cast<int>(sizeof(OmDataHdrStru));
}

void OmRingBuff::UpdateAtomicPosVal(int32_t &readPos, int32_t &writePos)
{
    readPos = m_readPos.load(memory_order_acquire);
    writePos = m_writePos.load(memory_order_acquire);
}
