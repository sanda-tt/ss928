﻿#include "DataChannel_Linux.h"
#include "OtaplusTimer.h"
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/file.h>
#include <sys/ioctl.h>

const char* QUERY_DATACNNL_CMD_INTF7 = "ls -d /sys/bus/usb/devices/*-*/*:*.7/ttyUSB* 2>/dev/null";
const char* QUERY_DATACNNL_CMD_INTF6 = "ls -d /sys/bus/usb/devices/*-*/*:*.6/ttyUSB* 2>/dev/null";
const char* DATACHNL_PATH_PCIE = "/dev/stty_nr0";
const char* DATACHANNEL_MODE_STR[] = {"USB_PCIE", "PCIE", "USB", "UNKNOWN"};
const char* g_portTypeName[] = 
{
    "DIAG",
    "MODEM",
    "MBIM",
    "WIFI",
    "PCUI",
    "DIAG",
    "COMB",
    "MAX"
};

const int SYS_ERROR = -1;

DataChannel::DataChannel(const char* chnl_path) : m_chnl_path(string(chnl_path)), m_chnl_mode(DATACHANNEL_MODE_UNKNOWN),
                                                      m_fd_in(INVALID_FD), m_fd_out(INVALID_FD)
{
    memset(&m_chnl_option, 0, sizeof(m_chnl_option));
	initPcuiSignList();
	initGpsSignList();
}

DataChannel::~DataChannel()
{
    (void)Destroy();
}

RET_CODE DataChannel::Destroy()
{
    if (m_fd_in != INVALID_FD)
    {
        CleanResource();
    }

    return ERR_CODE_SUCCESS;
}

void DataChannel::CleanResource()
{
    if (m_fd_in != INVALID_FD)
    {
        close(m_fd_in);
        m_fd_out = m_fd_in = INVALID_FD;
        LOG_WARN("%s %s", __FUNCTION__, m_chnl_path.c_str());
    }
}

// 返回成功场景需要执行初始化动作，否则不执行重复动作
bool DataChannel::SetChnlMode(E_DATACHANNEL_MODE chnl_mode)
{
    CHECK_EXPR_RET(m_chnl_mode == chnl_mode, true);
    string chnl_path = GetPcieChnlPath();

    if (chnl_mode == DATACHANNEL_MODE_USB_PCIE || chnl_mode == DATACHANNEL_MODE_USB)
    {
        char queryResult[512] = { 0 };
        bool is_1st_try = true;
        bool has_chnl_found = false;
        FILE *fp = popen(GetChnlQueryScript(is_1st_try), "r");
        if (fp != NULL)
        {
            fgets(queryResult, sizeof(queryResult), fp);
            pclose(fp);
            if (strlen(queryResult) > 0)
            {
                queryResult[strlen(queryResult) - 1] = 0; // 替换换行符
                char *node_pos = strrchr(queryResult, '/');
                chnl_path = string("/dev") + node_pos;
                has_chnl_found = true;
            }
        }

        if (!has_chnl_found)
        {
            is_1st_try = false;
            fp = popen(GetChnlQueryScript(is_1st_try), "r");
            if (fp != NULL)
            {
                memset(queryResult, 0, sizeof(queryResult));
                fgets(queryResult, sizeof(queryResult), fp);
                pclose(fp);
                if (strlen(queryResult) > 0)
                {
                    queryResult[strlen(queryResult) - 1] = 0; // 替换换行符
                    char *node_pos = strrchr(queryResult, '/');
                    chnl_path = string("/dev") + node_pos;
                    has_chnl_found = true;
                }
            }
        }

        if (!has_chnl_found)
        {
            return false;
        }
    }

    LOG_WARN("%s %s(%s) -> %s(%s)", __FUNCTION__,
             DATACHANNEL_MODE_STR[m_chnl_mode], m_chnl_path.c_str(),
             DATACHANNEL_MODE_STR[chnl_mode], chnl_path.c_str());

    CleanResource();
    m_chnl_path = chnl_path;

    return true;
}

const char* DataChannel::GetChnlQueryScript(bool is_1st_try)
{
    if (is_1st_try)
    {
        LOG_WARN("%s => %s", __FUNCTION__, QUERY_DATACNNL_CMD_INTF7);
        return QUERY_DATACNNL_CMD_INTF7;
    }
    else
    {
        LOG_WARN("%s => %s", __FUNCTION__, QUERY_DATACNNL_CMD_INTF6);
        return QUERY_DATACNNL_CMD_INTF6;
    }
}

const char* DataChannel::GetPcieChnlPath()
{
    return DATACHNL_PATH_PCIE;
}

void DataChannel::SendAtCmd(const char *cmd, UINT buff_len)
{
    int len = write(m_fd_out, cmd, buff_len);
	if (len >= 0)
    {
        
    }
}

void DataChannel::initPcuiSignList()
{
    m_pcuiSignList.clear();
    m_pcuiSignList.push_back("PC UI");
    m_pcuiSignList.push_back(" AT ");
    m_pcuiSignList.push_back("Pcui");
    m_pcuiSignList.push_back("pcui");
    m_pcuiSignList.push_back("Vodafone Mobile Broadband Secondary Port Modem");
}

void DataChannel::initGpsSignList()
{
    m_gpsSignList.clear();
    m_gpsSignList.push_back("DIAG");
}

bool DataChannel::getPorts( vector<string> &strPorts )
{
    OS_ADAPT_DEVICEINFOLIST pstDeviceList;

    memset(&pstDeviceList, 0, sizeof(OS_ADAPT_DEVICEINFOLIST));

    // 调用底层库函数，枚举设备
    if(OS_ADAPT_ERROR_SUCCED != OS_ADAPT_EnumDevicePortInfo(OS_ADAPT_MAX_TYPE, &pstDeviceList))
    {
        LOG_WARN("Enum device port info faile!");
        return false;
    }

    for (int i = 0; i < pstDeviceList.lDeviceCount; i++)
    {
        for (int j = 0; j < pstDeviceList.szStDeviceInfo[i].lPortCount; j++)
        {
            string strPortName = pstDeviceList.szStDeviceInfo[i].szStPortInfo[j].szPortName;
            strPorts.push_back(strPortName);
            m_ports_type[strPortName] = pstDeviceList.szStDeviceInfo[i].szStPortInfo[j].enPortType;
            if( m_ports_type[strPortName] >= OS_ADAPT_COMM_PORT && m_ports_type[strPortName] <= OS_ADAPT_MAX_TYPE )
            {
                LOG_WARN("porttype=%s, portname=%s", g_portTypeName[m_ports_type[strPortName]], strPortName.c_str());
            }
            else
            {
                LOG_WARN("Port type: Unknown");
            }
        }
    }
    return true;
}

bool DataChannel::isPcuiPort( const string& portName )
{
    vector<string>::iterator iter = m_pcuiSignList.begin();
    while (iter != m_pcuiSignList.end())
    {
        if (std::string::npos != portName.find(*iter))
        {
            return true;
        }
        iter++;
    }

    if( OS_ADAPT_PCUI_PORT == m_ports_type[portName] )
    {
        return true;
    }

    return false;
}

bool DataChannel::isGpsPort( const string& portName )
{
    vector<string>::iterator iter = m_gpsSignList.begin();
    while (iter != m_gpsSignList.end())
    {
        if (std::string::npos != portName.find(*iter))
        {
            return true;
        }
        iter++;
    }

    if( OS_ADAPT_COMM_PORT == m_ports_type[portName] )
    {
        return true;
    }

    return false;
}

string DataChannel::getPcuiPortName()
{
    string strPortName = "";
    vector<string> ports;
    getPorts(ports);
    if (0 == ports.size())
    {
        LOG_WARN("Did not find any pcui port!");
        return strPortName;
    }

    vector<string>::iterator iter = ports.begin();
    while(iter != ports.end())
    {
        if (isPcuiPort(*iter))
        {
            strPortName = *iter;
        }
        iter ++;
    }
	LOG_WARN("pcui port: %s", strPortName.c_str());
    return strPortName;
}

string DataChannel::getGpsPortName()
{
    string gpsPortName = "";
    string strPortName = "";
    vector<string> ports;
    getPorts(ports);
    if (0 == ports.size())
    {
        LOG_WARN("Did not find any pcui port!");
        return strPortName;
    }

    vector<string>::iterator iter = ports.begin();
    // hertz
    while(iter != ports.end())
    {
        if (*iter > gpsPortName)
		//if (isGpsPort(*iter))
        {
            gpsPortName = *iter;
        }
        iter ++;
    }
    iter = ports.begin();
    while(iter != ports.end())
    {
        if ((*iter > strPortName) && (*iter < gpsPortName))
		//if (isGpsPort(*iter))
        {
            strPortName = *iter;
        }
        iter ++;
    }
    //moses
    /*while(iter != ports.end())
    {
        if (*iter > strPortName)
        {
            strPortName = *iter;
        }
        iter ++;
    }*/
	LOG_WARN("gps port: %s", strPortName.c_str());
    return strPortName;
}

RET_CODE DataChannel::Init(E_DATACHANNEL_MODE chnl_mode)
{
    OtaplusTimeRecorder time_logger(__FUNCTION__);
    //SetChnlMode(chnl_mode);

    //CHECK_EXPR_RET(!IsChannelAvailable(), ERR_CODE_CHNL_NOT_EXIST);
    //CHECK_EXPR_RET(m_fd_in != INVALID_FD, ERR_CODE_SUCCESS); // 重复初始化校验

    RET_CODE ret = ERR_CODE_SUCCESS;
    do
    {
        errno = 0;
		if (chnl_mode == DATACHANNEL_MODE_USB){
			m_fd_out = m_fd_in = open(getGpsPortName().c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);  // O_NONBLOCK
		}
		else if (chnl_mode == DATACHANNEL_MODE_PCIE) {
        	m_fd_out = m_fd_in = open(getPcuiPortName().c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);  // O_NONBLOCK
		}
        if (m_fd_in == INVALID_FD)
        {
            LOG_WARN("DataChannel::Init open %s failed, errno=%d, err=%s", m_chnl_path.c_str(), errno, strerror(errno));
            ret = ERR_CODE_CHNL_OPEN_FAIL;
            break;
        }
        else
        {
            LOG_WARN("DataChannel::Init open %s ok -> %d", m_chnl_path.c_str(), m_fd_in);
        }
    } while (false);

    if (ret != ERR_CODE_SUCCESS)
    {
        CleanResource();
        return ret;
    }

    if (ConfigChannel(m_fd_in) == ERR_CODE_SUCCESS)
    {
        m_chnl_mode = chnl_mode;
        return ERR_CODE_SUCCESS;
    }
    else
    {
        return ERR_CODE_CHNL_INIT_FAIL;
    }
}

RET_CODE DataChannel::ConfigChannel(FILE_HANDLE fd)
{
    OtaplusTimeRecorder time_logger(__FUNCTION__);
    struct termios opt_cfg;
    memset(&opt_cfg, 0, sizeof(opt_cfg));

    // CTTYComm2::SetTTYAtt
    int ret = tcgetattr(fd, &opt_cfg);
    if (ret < 0)
    {
        LOG_WARN("%s tcgetattr failed, %d : %d, error (%s)", __FUNCTION__, ret, errno, strerror(errno));
        return ret;
    }
    memcpy(&m_chnl_option, &opt_cfg, sizeof(m_chnl_option));

    cfmakeraw(&opt_cfg);
    opt_cfg.c_cflag |= CS8;
    opt_cfg.c_cflag &= ~CSTOPB;
    opt_cfg.c_cflag &= ~PARENB;
    opt_cfg.c_cflag |= (CLOCAL | CREAD);

    opt_cfg.c_cc[VMIN]=0;
    opt_cfg.c_cc[VTIME]=0;

    cfsetispeed(&opt_cfg,B115200);
    cfsetospeed(&opt_cfg,B115200);

    tcflush(fd,TCOFLUSH);
    tcflush(fd,TCIFLUSH);

    ret = tcsetattr(fd, TCSANOW, &opt_cfg);
    LOG_WARN("tcsetattr ret: %d", ret);

    usleep(DATACHNL_INITDELAY_US);  // 延时50ms-确保写配置生效
    return (ret == ERR_CODE_SUCCESS) ? ERR_CODE_SUCCESS : ERR_CODE_CHNL_INIT_FAIL;
}

bool DataChannel::IsChannelAvailable()
{
    LOG_INFO("Access channel %s", m_chnl_path.c_str());
    return (access(m_chnl_path.c_str(), R_OK) == F_OK);
}

RET_CODE DataChannel::SetChnlPath(string chnl_path)
{
    m_chnl_path = chnl_path;
    return IsChannelAvailable() ? ReOpen() : ERR_CODE_CHNL_NOT_EXIST;
}

RET_CODE DataChannel::ReOpen()
{
    CleanResource();
    return Init(m_chnl_mode);
}

RET_CODE DataChannel::AdjustChnlMode(E_DATACHANNEL_MODE& chnl_mode)
{
    return ERR_CODE_SUCCESS;
}

UINT DataChannel::ReadData(CHAR *buff, UINT max_len, READEND_FUNC is_end_func)
{
    CHECK_EXPR_RET(m_fd_in == INVALID_FD, 0);

    //UINT try_counter = DATACHNL_TRYTIMES_MAX;
	UINT try_counter = 1;
    UINT read_len = 0;

    if (is_end_func != NULL)
    {
        errno = 0;
        while ((read_len < max_len) && (try_counter-- != 0))
        {
            int len = read(m_fd_in, buff + read_len, max_len - read_len);
            if (len > 0)
            {
                read_len += len;
            }

            if (is_end_func(buff, read_len))
            {
                break;
            }
            usleep(ATCHNL_INTERVAL_US);  // 放大延时 - 避免USB被读坏
        }

        if (read_len == 0)
        {
            LOG_WARN("AT ReadData %d, %s", errno, strerror(errno));  // strerror(errno) 系统全局变量和函数
            errno = 0;
        }
        else
        {
            LOG_INFO("AT ReadData [%s]", buff);
        }
    }
    else
    {
        while ((read_len < max_len) && (try_counter-- != 0))
        {
            int len = read(m_fd_in, buff + read_len, max_len - read_len);
            if (len > 0)
            {
                read_len += len;
            }
            else
            {
                usleep(DATACHNL_INTERVAL_READ_US);
            }
        }
    }

    return read_len;
}

UINT DataChannel::SendData(const CHAR *buff, UINT buff_len)
{
    CHECK_EXPR_RET(m_fd_out == INVALID_FD, 0);

    //UINT try_counter = DATACHNL_TRYTIMES_MAX;
	UINT try_counter = 1;
    UINT write_len = 0;

    errno = 0;
    while ((write_len < buff_len) && (try_counter-- != 0))
    {
        int len = write(m_fd_out, buff + write_len, buff_len - write_len);
        if (len >= 0)
        {
            write_len += len;
        }
        else
        {
            RET_CODE ret = ReOpen();
            LOG_WARN("%s ReOpen Channel %s, ret: %d", __FUNCTION__, m_chnl_path.c_str(), ret);
            UINT reopen_counter = 3;
            while (ret != ERR_CODE_SUCCESS && reopen_counter-- != 0)
            {
                sleep(1);
                ret = ReOpen();
            }

            if (ret != ERR_CODE_SUCCESS)
            {
                break;
            }
            else
            {
                LOG_WARN("%s ReOpen Channel %s, ret: %d", __FUNCTION__, m_chnl_path.c_str(), ret);
            }
        }
    }

    if (write_len != buff_len)
    {
        LOG_WARN("SendData %d, %s", errno, strerror(errno));  // strerror(errno) 系统全局变量和函数
    }

    return write_len;
}
