#ifndef MODEMLOGCAT_HSA_UTILS_MDM_LOG_H
#define MODEMLOGCAT_HSA_UTILS_MDM_LOG_H

#include <pthread.h>
#include <string>
#include <string.h>

namespace ModemLogMdmLog {
const int MAX_LOG_BUF_LEN = 2048;

enum MdmLogType {
    MDM_LOG_DEBUG = 0,
    MDM_LOG_INFO = 1,
    MDM_LOG_EVENT = 2,
    MDM_LOG_WARNING = 3,
    MDM_LOG_ERROR = 4,
    MDM_LOG_OTHER = 5,
    MDM_LOG_TYPE_CNT
};

const std::string MODEM_LOG_TYPE[MDM_LOG_TYPE_CNT] = {
    "DEBUG",
    "INFO",
    "EVENT",
    "WARN",
    "ERROR",
    "OTHER"
};

// 根据文件绝对路径，获取文件名称
#define GET_FILE_NAME(x) (strrchr((x), '/') ? (strrchr((x), '/') + 1) : (x))
#define IMODEMLOG(type, fmt, ...) \
    MdmLog::GetInstance().WriteLog(type, GET_FILE_NAME(__FILE__), __LINE__, __FUNCTION__, fmt, ##__VA_ARGS__)

class MdmLog {
public:
    static MdmLog &GetInstance()
    {
        static MdmLog mdmLog;
        return mdmLog;
    }
    // 写文件
    void WriteLog(MdmLogType logType, std::string fileName, uint32_t lineNumber,
        std::string funcName, const char *fmt, ...);
    

private:
    MdmLog();
    ~MdmLog();
    // 明确禁止使用拷贝构造和赋值操作符
    MdmLog(const MdmLog &mdmLog);
    MdmLog &operator = (const MdmLog &);

    void Close();
    void Open(const char *m_acFilePath);
    uint32_t GetFileSize(const char *filename);
    std::string ModifyFileName(const char *fileSrcName);

    int m_fd;
    std::string m_fileName;
    bool m_fileMutexFlag;
    uint32_t m_ulFileMaxSize;
    pthread_mutex_t m_fileMutex;
};
}


#endif // MODEMLOGCAT_HSA_UTILS_MDM_LOG_H