#ifndef __ATSERVICE_H__
#define __ATSERVICE_H__

#include "CommonDef.h"
#include "AtChannel_Linux.h"
#include <string>
#include <list>
#include <stdint.h>

using std::string;
using std::list;

const UINT INTERVAL_READ_NODATA = 10000;        // ��λus, 10ms
const UINT INTERVAL_WAIT_RESPONSE_US = 20000;   // ��λus, 20ms
const UINT AT_EXECUTE_READ_DEFAULT_TIMEOUT = 4; // ��ʱ����4S
const UINT AT_RESULT_BUFFER_LEN_LITTLE = 2048;  // ATӦ�𻺴�2048�ֽ�

typedef enum _AT_EXECUTE_RESULT_CODE
{
    AT_EXECUTE_FAILED = -2,    //ִ������ʧ��
    AT_RESULT_UNKNOWN = -1,    //δ֪����
    AT_RESULT_OK = 0,
    AT_RESULT_ERROR,
    AT_RESULT_CMD_NOT_SUPPORT,
    AT_RESULT_TOO_MANY_PARAMS,
    AT_RESULT_ERROR_COUNT,
    AT_RESULT_ERROR_CMEE_4,
} AT_EXECUTE_RESULT_CODE;

//�����ն˱�������+CMEE=?
typedef enum _EM_CMEE_MODE
{
    CME_CODE_NONE   = 0,    //0 ��ʹ��+CME ERROR:<err>result code������ʱ������ERROR��
    CME_CODE_NUMBER = 1,    //1 ʹ��+CME ERROR:<err>result code��<err>���ô�����ֵ��
    CME_CODE_STRING = 2     //2 ʹ��+CME ERROR:<err>result code��<err>���ô������ϸ�ַ���ֵ
} EM_CMEE_MODE;

class CATService
{
public:
    static CATService* Instance();

    static void Destroy();

    static bool IsReadEnd(CHAR* buffer, UINT len);

    RET_CODE Init(E_DATACHANNEL_MODE chnl_mode);

    RET_CODE QueryChnlMode(E_DATACHANNEL_MODE &chnl_mode);

    void CleanResource();

    AT_EXECUTE_RESULT_CODE SimpleATCmdExecute(const char * pszCmd,
                                              UINT iTimeOut = AT_EXECUTE_READ_DEFAULT_TIMEOUT);

private:

    CATService();

    ~CATService();

    void InitReportATList(void);

    RET_CODE SearchATChnl();

    bool ExecuteCmdWaitResponse(const char * szCmdString,
                                list<string>& listCmdResult,
                                AT_EXECUTE_RESULT_CODE * enAtResCode,
                                UINT iTimeOut = AT_EXECUTE_READ_DEFAULT_TIMEOUT);

    void ParseATResult(const char * strRes, list<string>& listRes);

    bool SetParseATCmdCondtion();

    bool ATSetCmee(EM_CMEE_MODE enMode);

    bool ATCloseEcho();

    bool ATTest();

    bool ATReturnStringResult();

    bool IsReportAT(const char * pszAT);

    void TransformATMsgFromModule(char * buffer, UINT len);

public:
    static char s_S3Code;
    static char s_S4Code;

private:
    static CATService *s_pInstance;       // ��ʵ��ָ��
    AtChannel *m_pAtChnl;                 // ���ݴ���
    list<string> m_listReportAT;          // AT�����ϱ��б�
};

#endif
