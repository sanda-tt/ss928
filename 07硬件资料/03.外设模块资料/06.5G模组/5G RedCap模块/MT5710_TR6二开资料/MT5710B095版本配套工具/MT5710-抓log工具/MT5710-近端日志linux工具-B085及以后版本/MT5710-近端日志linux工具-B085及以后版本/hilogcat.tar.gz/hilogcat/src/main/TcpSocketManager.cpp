#include "TcpSocketManager.h"
#include <sys/types.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fcntl.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <cstring>
#include <linux/tcp.h>
#include <linux/ip.h>
#include <utils/mdm_log.h>
#include <sys/socket.h>
#include <cerrno>
#include <utils/global_service.h>
#include <utils/mdm_log.h>

using namespace HsaThreadManager;
using namespace ModemLogMdmLog;

TcpSocketManager::TcpSocketManager()
    : m_hostSocketFd(-1),
      m_peerSocketFd(-1),
      m_acceptingThread(nullptr),
      m_curRecvCnt(0)
{}

TcpSocketManager::~TcpSocketManager() {}

bool TcpSocketManager::OpenAsServer(int serverPort)
{
    if (m_hostSocketFd >= 0) {
        IMODEMLOG(MDM_LOG_INFO, "tcp server already opened, m_serverPort: %d, m_hostSocketFd: %d",
            m_serverPort, m_hostSocketFd);
        return true;
    }

    m_serverPort = serverPort;
    struct sockaddr_in serverAddr; /* my address information */
    m_hostSocketFd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (m_hostSocketFd < 0) {
        IMODEMLOG(MDM_LOG_ERROR, "create socket failed, m_serverPort: %d, m_hostSocketFd: %d, errno: %d",
            m_serverPort, m_hostSocketFd, errno);
        return false;
    }
    bzero(&serverAddr, sizeof(serverAddr));
    serverAddr.sin_family = AF_INET;                /* host byte order */
    serverAddr.sin_port = htons(m_serverPort);      /* short, network byte order */
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* auto-fill with my IP */

    // 设置非阻塞模式
    if (!SetNonBlockMode(m_hostSocketFd)) {
        return false;
    }
    if (::bind(m_hostSocketFd, (struct sockaddr *)&serverAddr, sizeof(struct sockaddr)) == -1) {
        IMODEMLOG(MDM_LOG_ERROR, "bind failed, m_serverPort: %d, m_hostSocketFd: %d, errno: %d",
            m_serverPort, m_hostSocketFd, errno);
        return false;
    }
    if (listen(m_hostSocketFd, MAX_BACKLOG) == -1) {
        IMODEMLOG(MDM_LOG_ERROR, "listen failed, m_serverPort: %d, m_hostSocketFd: %d, errno: %d",
            m_serverPort, m_hostSocketFd, errno);
        return false;
    }
    if (!StartAcceptingProc()) {
        IMODEMLOG(MDM_LOG_ERROR, "StartAcceptingProc failed, m_serverPort: %d, m_hostSocketFd: %d, errno: %d",
            m_serverPort, m_hostSocketFd, errno);
        return false;
    }
    IMODEMLOG(MDM_LOG_INFO, "open tcp server succeed, m_serverPort: %d, m_hostSocketFd: %d",
        m_serverPort, m_hostSocketFd);
    return true;
}

bool TcpSocketManager::OpenAsClient(std::string serverIp, int serverPort)
{
    if (m_peerSocketFd >= 0) {
        IMODEMLOG(MDM_LOG_INFO, "tcp client already opened, m_serverPort: %d, m_peerSocketFd: %d",
            m_serverPort, m_peerSocketFd);
        return true;
    }

    m_serverIp = serverIp;
    m_serverPort = serverPort;
    m_peerSocketFd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (m_peerSocketFd < 0) {
        IMODEMLOG(MDM_LOG_ERROR, "create socket failed, m_serverPort: %d, m_peerSocketFd: %d, errno: %d",
            m_serverPort, m_peerSocketFd, errno);
        return false;
    }
    // 设置端口信息
    struct sockaddr_in destAddr;
    bzero(&destAddr, sizeof(destAddr));
    destAddr.sin_family = AF_INET;
    destAddr.sin_addr.s_addr = inet_addr(m_serverIp.c_str());
    destAddr.sin_port = htons(m_serverPort);

    // 设置非阻塞模式
    if (!SetNonBlockMode(m_peerSocketFd)) {
        return false;
    }

    int ret = connect(m_peerSocketFd, (struct sockaddr*)&destAddr, sizeof(struct sockaddr));
    if (ret < 0) {
        if (errno != EINPROGRESS || !CheckConnection(m_peerSocketFd, 10)) { // 10s
            IMODEMLOG(MDM_LOG_ERROR, "open tcp client failed, m_serverPort: %d, m_peerSocketFd: %d, ret: %d, errno: %d",
                m_serverPort, m_peerSocketFd, ret, errno);
            close(m_peerSocketFd);
            m_peerSocketFd = -1;
            return false;
        }
    }
    IMODEMLOG(MDM_LOG_INFO, "open tcp client succeed, m_serverPort: %d, m_peerSocketFd: %d",
        m_serverPort, m_peerSocketFd);
    return true;
}

bool TcpSocketManager::SetNonBlockMode(int socketFd)
{
    int flags = fcntl(socketFd, F_GETFL, 0);
    fcntl(socketFd, F_SETFL, flags | O_NONBLOCK); // 设置为非阻塞
    // 设置超时
    struct timeval timeout = { 10, 0 }; // 10s
    if (setsockopt(socketFd, SOL_SOCKET, SO_SNDTIMEO, (const char *)&timeout, sizeof(timeout)) != 0) {
        IMODEMLOG(MDM_LOG_ERROR, "set SO_SNDTIMEO failed, m_serverPort: %d, errno: %d",
            m_serverPort, errno);
        return false;
    }
    if (setsockopt(socketFd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&timeout, sizeof(timeout)) != 0) {
        IMODEMLOG(MDM_LOG_ERROR, "set SO_RCVTIMEO failed, m_serverPort: %d, errno: %d",
            m_serverPort, errno);
        return false;
    }
    // 设置重用地址，防止Address already in use
    int on = 1;
    setsockopt(socketFd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    IMODEMLOG(MDM_LOG_INFO, "set NonBlock mode succeed, m_serverPort: %d", m_serverPort);
    return true;
}

// 非阻塞模式accept
void TcpSocketManager::AcceptTcpClient(void *thisPtr)
{
    TcpSocketManager *selfManager = reinterpret_cast<TcpSocketManager *>(thisPtr);
    if (selfManager == nullptr || selfManager->m_hostSocketFd < 0) {
        usleep(TCP_DEFAULT_WAIT_USECS);
        return;
    }

    struct sockaddr_in clientAddr; /* connector's address information */
    int sin_size = sizeof(struct sockaddr_in);
    int clientFd = accept(selfManager->m_hostSocketFd,
        reinterpret_cast<struct sockaddr *>(&clientAddr),
        reinterpret_cast<socklen_t *>(&sin_size));
    if (clientFd < 0) {
        // 没有新连接请求
        if (errno == EWOULDBLOCK || errno == ECONNABORTED || errno == EPROTO || errno == EINTR) {
            usleep(TCP_DEFAULT_WAIT_USECS);
            return;
        }
        IMODEMLOG(MDM_LOG_ERROR, "accept client failed, m_serverPort: %d, clientFd: %d, errno: %d",
            selfManager->m_serverPort, clientFd, errno);
        return;
    } else {
        // 设置非阻塞模式
        selfManager->SetNonBlockMode(clientFd);
        selfManager->m_peerSocketFd = clientFd;
        IMODEMLOG(MDM_LOG_INFO, "accept client succeed, m_serverPort: %d, clientFd: %d",
            selfManager->m_serverPort, clientFd);
        return;
    }
}

bool TcpSocketManager::CheckConnection(int32_t &sockFd, int checkCnt)
{
    fd_set rset;
    fd_set wset;
    FD_ZERO(&rset);
    FD_SET(sockFd, &rset);
    wset = rset;

    struct timeval tv;
    tv.tv_sec = 1; // 超时时间
    tv.tv_usec = 0;

    while (checkCnt > 0) {
        // ">0" means sockfd ready to read, "=0" means timeout cause retrun, "<0" means error.
        if (select(sockFd + 1, &rset, &wset, NULL, &tv) <= 0) {
            usleep(TCP_DEFAULT_WAIT_USECS);
            checkCnt--;
        } else {
            break;
        }
    }

    if (FD_ISSET(sockFd, &rset) || FD_ISSET(sockFd, &wset)) {
        IMODEMLOG(MDM_LOG_INFO, "CheckConnection success");
        return true;
    }
    IMODEMLOG(MDM_LOG_INFO, "CheckConnection failed");
    return false;
}

void TcpSocketManager::CloseTcpSocket()
{
    if (m_hostSocketFd < 0 && m_peerSocketFd < 0) {
        IMODEMLOG(MDM_LOG_INFO, "socket already closed, m_serverPort: %d, m_hostSocketFd: %d, m_peerSocketFd: %d",
            m_serverPort, m_hostSocketFd, m_peerSocketFd);
        return;
    }
    StopAcceptingProc();
    if (m_peerSocketFd >= 0) {
        close(m_peerSocketFd);
        m_peerSocketFd = -1;
    }
    if (m_hostSocketFd >= 0) {
        close(m_hostSocketFd);
        m_hostSocketFd = -1;
    }
    IMODEMLOG(MDM_LOG_INFO, "close socket succeed, m_serverPort: %d", m_serverPort);
}

bool TcpSocketManager::RecvMsg(char *msgBuf, uint32_t bufSize, uint32_t &recvedSize)
{
    if (m_peerSocketFd < 0) {
        if ((m_curRecvCnt % DEFAULT_WAIT_CNT_FOR_LOG) == 0) {
            IMODEMLOG(MDM_LOG_INFO, "no tcp client connected, m_serverPort: %d", m_serverPort);
            m_curRecvCnt = 0;
        }
        m_curRecvCnt++;
        usleep(TCP_DEFAULT_WAIT_USECS);
        return false;
    }
    if (msgBuf == nullptr || bufSize == 0) {
        IMODEMLOG(MDM_LOG_ERROR, "invalid msg buffer, m_serverPort: %d, msgBuf: 0x%s, bufSize: %u",
            m_serverPort, msgBuf, bufSize);
        return false;
    }
    fd_set fds;
    timeval timeout = { 1, 0 };      // select 每1秒轮询，置0则为非阻塞
    FD_ZERO(&fds);                   // 每次循环都要清空集合，否则不能检测描述符变化
    FD_SET(m_peerSocketFd, &fds);    // 添加描述符
    switch (select(m_peerSocketFd + 1, &fds, nullptr, nullptr, &timeout)) {
        case -1: {
            // select错误
            IMODEMLOG(MDM_LOG_ERROR, "select failed, m_serverPort: %d, m_peerSocketFd: %d",
                m_serverPort, m_peerSocketFd);
            return false;
        }
        case 0: {
            // no data
            recvedSize = 0;
            return false;
        }
        default: {
            int32_t ret = recv(m_peerSocketFd, msgBuf, bufSize, 0);
            //IMODEMLOG(MDM_LOG_DEBUG, "TcpSocketManager::RecvMsg ret: %d", ret);
            if (ret < 0) {
                IMODEMLOG(MDM_LOG_ERROR, "recv failed, m_serverPort: %d, m_peerSocketFd: %d, ret: %d, errno: %d",
                    m_serverPort, m_peerSocketFd, ret, errno);
                return false;
            }
            recvedSize = ret;
            return true;
        }
    }
}

bool TcpSocketManager::SendMsg(const char *msgData, uint32_t msgSize, uint32_t &sentSize)
{
    if (m_peerSocketFd < 0) {
        IMODEMLOG(MDM_LOG_WARNING, "no tcp client connected, m_serverPort: %d", m_serverPort);
        usleep(TCP_DEFAULT_WAIT_USECS);
        return false;
    }
    if (msgData == nullptr || msgSize == 0) {
        IMODEMLOG(MDM_LOG_ERROR, "invalid msg data, m_serverPort: %d, msgData: 0x%s, msgSize: %u",
            m_serverPort, msgData, msgSize);
        return false;
    }

    int ret = send(m_peerSocketFd, msgData, msgSize, 0);
    if (ret < 0) {
        IMODEMLOG(MDM_LOG_ERROR, "send socket failed, m_serverPort: %d, m_peerSocketFd: %d, ret: %d, errno: %d",
            m_serverPort, m_peerSocketFd, ret, errno);
        return false;
    } else {
        sentSize = ret;
        return true;
    }
}

// 创建tcp服务器连接线程
bool TcpSocketManager::StartAcceptingProc()
{
    if (m_acceptingThread != nullptr && m_acceptingThread->IsRunning()) {
        return true;
    }
    m_acceptingThread = new HsaThread("AcceptingThread",
                                    TcpSocketManager::AcceptTcpClient,
                                    reinterpret_cast<void *>(this));
    if (!m_acceptingThread->StartRun()) {
        delete m_acceptingThread;
        m_acceptingThread = nullptr;
        return false;
    }
    IMODEMLOG(MDM_LOG_INFO, "accepting thread started, m_serverPort: %d", m_serverPort);
    return true;
}

void TcpSocketManager::StopAcceptingProc()
{
    if (m_acceptingThread == nullptr || m_acceptingThread->IsRunning() == false) {
        return;
    }
    m_acceptingThread->StopRun();
    delete m_acceptingThread;
    m_acceptingThread = nullptr;
    IMODEMLOG(MDM_LOG_INFO, "accepting thread stopped, m_serverPort: %d", m_serverPort);
}