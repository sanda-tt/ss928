﻿#include "ATService.h"
#include "OtaplusTimer.h"
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define AT_NORMAL_HEAD      "AT"
#define AT_SET_CMEE         "AT+CMEE=%d"
#define AT_ATE0             "ATE0"    // 关闭回显
#define AT_ATQ0             "ATQ0"    // 返回结果码到TE
#define AT_ATV1             "ATV1"    // 字符串形式返回结果
#define AT_ATV_QUERY        "ATV?"    // 字符串形式返回结果
#define CR_LF_DEFAULT       "\r\n"

const char* AT_CMD_QUERY_CHNLMODE   = "AT^PORTSW?";
const string PORT_MODE_USB_PCIE = "0";
const string PORT_MODE_PCIE = "1";
const string PORT_MODE_USB  = "2";
const string CMEE_ERROR_4 = "+CME ERROR: 4";

char CATService::s_S3Code = ATS3_CODE_DEFAULT;
char CATService::s_S4Code = ATS4_CODE_DEFAULT;

CATService *CATService::s_pInstance = NULL;
static const char *g_report_set[] =
{
    "RING",
    "CONNECT"
};

static const char *AT_RESULT_TBL[] =
{
    "OK",
    "ERROR",
    "COMMAND NOT SUPPORT",
    "TOO MANY PARAMETERS",
};

const unsigned AT_RESULT_TBL_NORMAL_ITEM_CNT = sizeof(AT_RESULT_TBL)/sizeof(AT_RESULT_TBL[0]);
bool CATService::IsReadEnd(CHAR* buffer, UINT len)
{
    string data_string(buffer, 0, len);
    for (size_t index = 0; index < AT_RESULT_TBL_NORMAL_ITEM_CNT; index++)
    {
        if (data_string.rfind(string(AT_RESULT_TBL[index]) + CR_LF_DEFAULT) != string::npos)
        {
            return true;
        }
    }

    return false;
}

CATService::CATService() : m_pAtChnl(NULL)
{
    // DO NOTHING but initialization
}

CATService::~CATService()
{
    if (m_pAtChnl != NULL)
    {
        delete m_pAtChnl;
        m_pAtChnl = NULL;
    }
}

CATService *CATService::Instance()
{
    if (s_pInstance == NULL)
    {
        s_pInstance = new CATService();
        s_pInstance->InitReportATList();
    }

    return s_pInstance;
}

void CATService::Destroy()
{
    if (s_pInstance != NULL)
    {
        delete s_pInstance;
        s_pInstance = NULL;
    }
}

void CATService::CleanResource()
{
    if (m_pAtChnl != NULL)
    {
        m_pAtChnl->CleanResource();
    }
}

RET_CODE CATService::Init(E_DATACHANNEL_MODE chnl_mode)
{
    if (m_pAtChnl == NULL)   // 复位后查询AT结果，AT通道需要重新打开
    {
        m_pAtChnl = new AtChannel();
        CHECK_EXPR_RET(m_pAtChnl == NULL, ERR_CODE_OBJ_NULL);
    }

    RET_CODE ret = m_pAtChnl->Init(chnl_mode);  // AT通道不关心数据通道-使用缺省模式
    if (ret == ERR_CODE_SUCCESS)
    {
        if (SetParseATCmdCondtion())
        {
            LOG_WARN("CATService Ready");
            return ERR_CODE_SUCCESS;
        }
    }
    else if (ret != ERR_CODE_CHNL_NOT_EXIST)  // 检查升级结果期间ttyUSB节点可能没有，此时会有大量错误日志-过滤
    {
        LOG_WARN("m_pAtChnl->Init %d", ret);
    }
    else
    {
        LOG_INFO("m_pAtChnl->Init %d", ret);
    }

    return SearchATChnl();
}

RET_CODE CATService::SearchATChnl()
{
    CHECK_EXPR_RET(m_pAtChnl == NULL, ERR_CODE_OBJ_NULL);

    list<string> dev_list;
    RET_CODE ret = m_pAtChnl->GetDevList(dev_list);
    CHECK_EXPR_RET(ret != ERR_CODE_SUCCESS, ret);

    list<string>::iterator it = dev_list.begin();
    for (it = dev_list.begin(); it != dev_list.end(); ++it)
    {
        string& chnl_path = *it;
        LOG_WARN("TEST AT_CHANNEL %s", chnl_path.c_str());

        ret = m_pAtChnl->SetChnlPath(chnl_path);
        if (ret == ERR_CODE_SUCCESS)
        {
            if (SetParseATCmdCondtion())
            {
                LOG_WARN("MATCH AT_CHANNEL => %s", chnl_path.c_str());
                return ERR_CODE_SUCCESS;
            }
            else
            {
                return ERR_CODE_AT_NOT_READY;
            }
        }
        else
        {
            LOG_INFO("m_pAtChnl->SetChnlPath %d", ret);
        }
    }

    return ret;
}

void CATService::InitReportATList(void)
{
    for ( unsigned int iIndex = 0; iIndex < sizeof(g_report_set) / sizeof(g_report_set[0]); ++iIndex)
    {
        m_listReportAT.push_back(g_report_set[iIndex]);
    }
}

bool CATService::IsReportAT(const char * pszAT)
{
    CHECK_EXPR_RET(pszAT == NULL, false);

    string strRsp = pszAT;
    CHECK_EXPR_RET((strRsp.find(CMEE_ERROR_4) != string::npos), false);  // 该错误码不过滤

    bool bIsReport = false;
    if (string::npos != strRsp.find("+") || string::npos != strRsp.find("^"))
    {
        unsigned int iIndexOfPlus = strRsp.find("+");
        unsigned int iIndexOfCaret =strRsp.find("^");
        if (string::npos != strRsp.find(":"))
        {
            unsigned int iIndexOfColon =strRsp.find(":");
            if ((iIndexOfColon>iIndexOfPlus+1)||(iIndexOfColon>iIndexOfCaret+1))
            {
                return true;
            }
        }
    }

    list<string>::const_iterator iter = m_listReportAT.begin();
    for (; iter != m_listReportAT.end(); iter++)
    {
        if (!strncmp(iter->c_str(), pszAT, strlen(iter->c_str())))
        {
            bIsReport = true;
            break;
        }
    }

    return bIsReport;
}

RET_CODE CATService::QueryChnlMode(E_DATACHANNEL_MODE &chnl_mode)
{
    AT_EXECUTE_RESULT_CODE atErrCode = AT_RESULT_UNKNOWN;
    list<string> listRes;

    bool bResVal = ExecuteCmdWaitResponse(AT_CMD_QUERY_CHNLMODE, listRes, &atErrCode);
    if (!bResVal)
    {
        LOG_WARN("%s No Response", AT_CMD_QUERY_CHNLMODE);
        return ERR_CODE_AT_QUERYCHNL_FAIL;
    }

    if (atErrCode != AT_RESULT_OK)
    {
        LOG_WARN("%s atErrCode: %d", AT_CMD_QUERY_CHNLMODE, atErrCode);
    }
    else
    {
        list<string>::const_iterator iter = listRes.begin();
        if (iter != listRes.end())
        {
            if (*iter == PORT_MODE_PCIE)  // 只有PCIE模式走PCIE通道
            {
                chnl_mode = DATACHANNEL_MODE_PCIE;
            }
            else // 双模式或USB模式固定走USB通道
            {
                chnl_mode = DATACHANNEL_MODE_USB;
            }

            LOG_WARN("%s ChnlMode: %s", AT_CMD_QUERY_CHNLMODE, (*iter).c_str());
            return ERR_CODE_SUCCESS;
        }
    }

    return ERR_CODE_AT_QUERYCHNL_FAIL;
}

/*******************************************************************************
*
*  返回值 - true: 读到数据, false：没读到数据
*  enAtResCode：AT执行结果 - AT_RESULT_OK - 0， 其他失败
*  listCmdResult：返回结果字符串
*
********************************************************************************/
bool CATService::ExecuteCmdWaitResponse(const char *szCmdString,
                                        list<string> &listCmdResult,
                                        AT_EXECUTE_RESULT_CODE *enAtResCode,
                                        UINT iTimeOut)
{
    *enAtResCode = AT_RESULT_UNKNOWN;

    if (szCmdString == NULL || enAtResCode == NULL || m_pAtChnl == NULL)
    {
        LOG_ERROR("NULL PTR");
        return false;
    }

    unsigned cmd_len = strlen(szCmdString) + 1;   // 1 for <S3>
    char *cmd_with_crlf = new char[cmd_len + 1];  // 1 for string end

    CHECK_EXPR_RET(cmd_with_crlf == NULL, false);
    memset(cmd_with_crlf, 0, cmd_len + 1);

    // AT命令使用用户配置<S3>(注意: AT命令没有要求携带ATS4, 携带非缺省ATS4的行为未定义, ATS4仅用于响应消息封装)
    snprintf(cmd_with_crlf, cmd_len + 1, "%s%c", szCmdString, s_S3Code);

    // 下发AT命令
    size_t lWriteLen = m_pAtChnl->SendData(cmd_with_crlf, cmd_len);
    delete[] cmd_with_crlf;
    if (cmd_len != lWriteLen)
    {
        LOG_ERROR("SendData %s Error (%d vs %d)", szCmdString, cmd_len, lWriteLen);
        return false;
    }

    usleep(INTERVAL_WAIT_RESPONSE_US);

    return true;
}

void CATService::ParseATResult(const char *pszAtResponse, list<string> &listRes)
{
    char *pszBegin = NULL;
    char *pszEnd = NULL;
    char *pszTmp = NULL;
    string strItem;

    if (pszAtResponse == NULL)
    {
        LOG_ERROR("NULL PTR");
        return;
    }

    pszTmp = const_cast<char *>(pszAtResponse);
    size_t nSepLen = strlen(CR_LF_DEFAULT);
    size_t nLen = strlen(pszAtResponse);

    while (true)
    {
        // 如果查找到字符串尾，则退出
        if (pszTmp + nSepLen > pszAtResponse + nLen)
        {
            break;
        }

        pszBegin = strstr(pszTmp, CR_LF_DEFAULT);
        pszEnd = strstr(pszTmp + nSepLen, CR_LF_DEFAULT);

        if (pszBegin != NULL && pszEnd != NULL)
        {
            // 如果AT应答字串不是以<CR><LF>开始或者不是V1标准的格式，则特殊处理
            if (pszTmp != pszBegin)
            {
                pszEnd = pszBegin;
                pszBegin = pszTmp;

                strItem.assign(pszBegin, pszEnd - pszBegin);
            }
            else
            {
                // 如果两个分隔符之间没有字符的话，则跳过一个分隔符
                if (pszBegin + nSepLen >= pszEnd)
                {
                    pszTmp += nSepLen;
                    continue;
                }

                strItem.assign(pszBegin + nSepLen, pszEnd - pszBegin - nSepLen);
            }

            // 如果是AT回显，则不添加到链表中
            if (!strncmp(strItem.c_str(), AT_NORMAL_HEAD, strlen(AT_NORMAL_HEAD)))
            {
                LOG_WARN("AT echo : %s", strItem.c_str());
                pszTmp = pszEnd;
                continue;
            }

            // 过滤主动上报
            bool bReport = IsReportAT(strItem.c_str());
            if (bReport)
            {
                LOG_WARN("Report : %s", strItem.c_str());
                pszTmp = pszEnd;
                continue;
            }

            // 子串指针偏移
            pszTmp = pszEnd + nSepLen;

            // 将解析结果字串插入到链表中
            LOG_INFO("%s push_back %s", __FUNCTION__, strItem.c_str());
            listRes.push_back(strItem);
        }
        else
        {
            LOG_WARN("invalid at response %s", pszAtResponse);
            break;
        }
    }
}

AT_EXECUTE_RESULT_CODE CATService::SimpleATCmdExecute(const char *pszCmd, UINT iTimeOut)
{
    if (NULL == pszCmd)
    {
        LOG_ERROR("pszCmd NULL");
    }

    list<string> listAtResult;
    AT_EXECUTE_RESULT_CODE atErrCode = AT_RESULT_UNKNOWN;
    bool bResVal = ExecuteCmdWaitResponse(pszCmd, listAtResult,  &atErrCode, iTimeOut);
    if (!bResVal)
    {
        LOG_ERROR("error %s No Response", pszCmd);
        atErrCode = AT_EXECUTE_FAILED;
    }
    else if (atErrCode != AT_RESULT_OK)
    {
        LOG_ERROR("%s atErrCode: %d", pszCmd, atErrCode);
    }

    return atErrCode;
}

bool CATService::SetParseATCmdCondtion()
{
    return true;
}

bool CATService::ATSetCmee(EM_CMEE_MODE enMode)
{
    char szATCmd[AT_RESULT_BUFFER_LEN_LITTLE] = {0,};

    sprintf(szATCmd, AT_SET_CMEE, enMode);
    AT_EXECUTE_RESULT_CODE enAtRes = SimpleATCmdExecute(szATCmd);
    if (enAtRes != AT_RESULT_OK)
    {
        LOG_ERROR("%s, ret: %d", szATCmd,  enAtRes);
        return false;
    }

    return true;
}

bool CATService::ATCloseEcho()
{
    AT_EXECUTE_RESULT_CODE enAtRes = SimpleATCmdExecute(AT_ATE0);
    if (enAtRes != AT_RESULT_OK)
    {
        LOG_WARN("%s, ret: %d", AT_ATE0, enAtRes);
        return false;
    }

    return true;
}

bool CATService::ATTest()
{
    AT_EXECUTE_RESULT_CODE atErrCode = SimpleATCmdExecute(AT_NORMAL_HEAD);
    LOG_WARN("%s, ret: %d", AT_NORMAL_HEAD, atErrCode);
    return (atErrCode == AT_RESULT_OK);
}

bool CATService::ATReturnStringResult()
{
    // ATQ0: 明确MT返回执行结果给TE
    (void)SimpleATCmdExecute(AT_ATQ0);

    // ATV1: 明确字符串显示返回AT执行结果(非数字形式, 缺省配置)
    (void)SimpleATCmdExecute(AT_ATV1);

    // ATQ0和ATV1不校验返回值-根据ATV?查询命令返回情况判断设置是否生效
    list<string> listRes;
    AT_EXECUTE_RESULT_CODE atErrCode = AT_RESULT_UNKNOWN;
    bool bResVal = ExecuteCmdWaitResponse(AT_ATV_QUERY, listRes, &atErrCode);
    if (!bResVal)
    {
        LOG_WARN("%s No Response", AT_ATV_QUERY);
        return false;
    }

    if (atErrCode != AT_RESULT_OK)
    {
        LOG_WARN("%s atErrCode: %d", AT_ATV_QUERY, atErrCode);
        return false;
    }

    return true;
}

void CATService::TransformATMsgFromModule(char * buffer, UINT len)
{
    CHECK_EXPR_RET_VOID(s_S3Code == ATS3_CODE_DEFAULT && s_S4Code == ATS4_CODE_DEFAULT);
    CHECK_EXPR_RET_VOID(buffer == NULL || len < 2);

    for (UINT index = 0; index < len - 1; index++)
    {
        if (buffer[index] == s_S3Code && buffer[index + 1] == s_S4Code)
        {
            LOG_WARN("%s <%d><%d> found at [%d]", __FUNCTION__, s_S3Code, s_S4Code, index);
            buffer[index] = ATS3_CODE_DEFAULT;
            buffer[index + 1] = ATS4_CODE_DEFAULT;
            index++; // 注意：此处不能跳出循环，需要将所有的<S3><S4>替换掉
        }
    }
}
