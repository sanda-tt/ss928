#ifndef _MTP_DEFINE_
#define _MTP_DEFINE_

#include "volatile.h"

#ifndef TRUE
#define TRUE    1
#endif

#ifndef FALSE
#define FALSE   0
#endif

#ifndef NULL
#ifdef __cplusplus
#define NULL    0
#else
#define NULL    ((void *)0)
#endif
#endif

#define EXPAND(x)  x
#define _COMPILE_TIME_  EXPAND(__DATE__ " " __TIME__)

#ifdef WIN32
#include <windows.h>
typedef HANDLE          HPORT;
typedef int             socklen_t;
typedef DWORD           THREAD_R;

#define MTP_MAX_PATH    MAX_PATH

#else
typedef void *  HANDLE;
typedef int     BOOL;
typedef unsigned long DWORD;

typedef long    HPORT;
typedef int     SOCKET;
typedef void *  THREAD_R;

#define INVALID_HANDLE_VALUE    (-1)
#define INVALID_SOCKET          (-1)
#define SOCKET_ERROR            (-1)

#define MTP_MAX_PATH            260
#ifndef Sleep
#define Sleep(n)                usleep(n * 1000)
#endif
#define stricmp                 strcasecmp

#endif

typedef enum {
    MTP_SUCCESS = 0,
    MTP_SOCK_ALREADY_CREATED,
    MTP_SOCK_FAIL_CREATE,
    MTP_SOCK_FAIL_BIND,
    MTP_SOCK_FAIL_LISTEN,
} MTP_RESULT;

#endif
