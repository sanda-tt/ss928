﻿#ifndef FILEOPER_LINUX_H_
#define FILEOPER_LINUX_H_

#include "CommonDef.h"
#include <string>
#include "typedef.h"

#define PATH_CREATE_MODE 0644
using std::string;

class FileOper
{
public:
    typedef enum _E_OPER_MODE
    {
        READ_MODE   = 4,
        WRITE_MODE  = 2,
        DELETE_MODE = 1,
    } E_OPER_MODE;

    FileOper(string file_path, E_OPER_MODE mode)
    : m_file_path(file_path),
      m_fd(INVALID_FD),
      m_mode(mode)
    {
        // DO NOTHING but initialization
    }

    ~FileOper()
    {
        Destroy();
    }

    RET_CODE Init();

    RET_CODE Destroy();

    UINT ReadData(CHAR *buff, UINT max_len, FILE_OFFSET offset);

    UINT WriteData(const CHAR *buff, UINT len);

    RET_CODE Complete(bool is_ok);

    FILE_OFFSET GetFileSize();

    static bool IsOperAllowed(string file_path, E_OPER_MODE mode);

    static FILE_OFFSET GetFileSize(const char* file_path);

    static RET_CODE DeleteFile(const char* file_path);

private:
    string m_file_path;
    FILE_HANDLE m_fd;
    E_OPER_MODE m_mode;
};

#endif /* FILEOPER_LINUX_H_ */
