#include <unistd.h>
#include <utils/HsaThread.h>
#include <utils/mdm_log.h>

using namespace HsaThreadManager;
using namespace ModemLogMdmLog;

HsaThread::HsaThread(std::string threadName, ThreadProcFunction procFunction, void *procArg)
    : m_threadId(0), m_threadName(threadName), m_isRunning(false), m_threadState(TS_INIT)
{
    m_threadArg.procFunction = procFunction;
    m_threadArg.procArg = procArg;
}

HsaThread::~HsaThread() {}

bool HsaThread::StartRun()
{
    if (m_threadState == TS_STARTED) {
        IMODEMLOG(MDM_LOG_INFO, "Thread already started: %s", m_threadName.c_str());
        return true;
    }
    m_threadArg.threadObj = reinterpret_cast<void *>(this);
    if (pthread_create(&m_threadId, nullptr, HsaThread::ThreadLoop, reinterpret_cast<void *>(&m_threadArg)) == -1) {
        IMODEMLOG(MDM_LOG_ERROR, "Thread created failed: %s", m_threadName.c_str());
        return false;
    }
    SetThreadState(TS_STARTED);
    IMODEMLOG(MDM_LOG_INFO, "Create thread scceed: %s", m_threadName.c_str());
    return true;
}

bool HsaThread::StopRun(int waitSecs)
{
    if (m_threadState == TS_STOPPED) {
        IMODEMLOG(MDM_LOG_INFO, "Thread already stopped: %s", m_threadName.c_str());
        return true;
    }
    m_threadState = TS_STOPPING;
    IMODEMLOG(MDM_LOG_INFO, "Thread stopping: %s", m_threadName.c_str());
    const int waitUSecs = 50 * 1000;
    int waitCnt = waitSecs * 20;
    while (m_isRunning && waitCnt > 0) {
        usleep(waitUSecs);
        waitCnt--;
    }
    if (!m_isRunning) {
        IMODEMLOG(MDM_LOG_INFO, "Thread stopped: %s", m_threadName.c_str());
        return true;
    } else {
        IMODEMLOG(MDM_LOG_INFO, "Stop thread timeout: %s", m_threadName.c_str());
        return false;
    }
}

void *HsaThread::ThreadLoop(void *threadArg)
{
    ThreadArg *tArg = reinterpret_cast<ThreadArg *>(threadArg);
    HsaThread *thisPtr = reinterpret_cast<HsaThread *>(tArg->threadObj);
    while (thisPtr->GetThreadState() == TS_STARTED) {
        tArg->procFunction(tArg->procArg);
    }
    thisPtr->SetThreadState(TS_STOPPED);
    return nullptr;
}
