﻿#ifndef OTAPLUSTIMER_H_
#define OTAPLUSTIMER_H_

#include "CommonDef.h"
#include <sys/time.h>
#include <string.h>
#include <string>

const long PERIOD_INTERVAL_DEFAULT_1S = 1000;
class OtaplusTimer
{
public:
    OtaplusTimer(const char* desc) : m_desc(desc), m_timeout_interval(PERIOD_INTERVAL_DEFAULT_1S),
                               m_period_interval(PERIOD_INTERVAL_DEFAULT_1S), m_period_counter(0), m_is_expired(false)
    {
        timerclear(&m_tv_init_period);
        timerclear(&m_tv_init_alife);
        timerclear(&m_tv_cur);
    }

    RET_CODE Init(UINT timeout_interval, UINT period_interval = PERIOD_INTERVAL_DEFAULT_1S)
    {
        m_timeout_interval = timeout_interval;
        m_period_interval = period_interval;
        RET_CODE ret = gettimeofday(&m_tv_init_alife,NULL);
        memcpy(&m_tv_init_period, &m_tv_init_alife, sizeof(m_tv_init_period));
        if (ret != ERR_CODE_SUCCESS)
        {
            LOG_ERROR("%s gettimeofday ret %d", m_desc.c_str(), ret);
        }

        return ret;
    }

    inline bool IsLifeExpired()
    {
        if (ERR_CODE_SUCCESS != gettimeofday(&m_tv_cur,NULL))
        {
            return true;
        }

        m_is_expired = ((m_tv_cur.tv_sec - m_tv_init_alife.tv_sec) * 1000
                      + (m_tv_cur.tv_usec - m_tv_init_alife.tv_usec) / 1000) > m_timeout_interval;
        if (m_is_expired)
        {
            LOG_WARN("%s life timeout from %lld.%lld to %lld.%lld", m_desc.c_str(),
                      m_tv_init_alife.tv_sec, m_tv_init_alife.tv_usec, m_tv_cur.tv_sec, m_tv_cur.tv_usec);
        }

        return m_is_expired;
    }

    inline bool IsPeriodExpired()
    {
        if (ERR_CODE_SUCCESS != gettimeofday(&m_tv_cur,NULL))
        {
            return true;
        }

        m_is_expired = ((m_tv_cur.tv_sec - m_tv_init_period.tv_sec) * 1000
                      + (m_tv_cur.tv_usec - m_tv_init_period.tv_usec) / 1000) > (m_period_counter * m_period_interval);
        if (m_is_expired)
        {
            m_period_counter++;
            /* LOG_WARN("%s period timeout from %lld.%lld to %lld.%lld", m_desc.c_str(),
                      m_tv_init_period.tv_sec, m_tv_init_period.tv_usec, m_tv_cur.tv_sec, m_tv_cur.tv_usec);  */
        }

        return m_is_expired;
    }

    inline void ReLife()
    {
        if (m_tv_cur.tv_sec > m_tv_init_alife.tv_sec)
        {
            memcpy(&m_tv_init_alife, &m_tv_cur, sizeof(m_tv_init_alife));
        }
    }

private:
    std::string m_desc;
    struct timeval m_tv_init_period;
    struct timeval m_tv_init_alife;
    struct timeval m_tv_cur;
    long   m_timeout_interval;    // 单位是毫秒 ms
    long   m_period_interval;
    long   m_period_counter;
    bool   m_is_expired;
};

class OtaplusTimeRecorder
{
public:
    OtaplusTimeRecorder(const char* msg) //: m_msg(string(msg))
    {
        /* timerclear(&m_tv_init);
        timerclear(&m_tv_cur);

        int ret = gettimeofday(&m_tv_init,NULL);
        LOG_WARN("%s start : %ld.%06ld, ret %d",
                  m_msg.c_str(), m_tv_init.tv_sec, m_tv_init.tv_usec, ret); */
    }

    ~OtaplusTimeRecorder()
    {
        /* int ret = gettimeofday(&m_tv_cur,NULL);
        LOG_WARN("%s end : %ld.%06ld, ret %d, total time %ld s",
                  m_msg.c_str(), m_tv_init.tv_sec, m_tv_init.tv_usec, ret, m_tv_cur.tv_sec - m_tv_init.tv_sec); */
    }

private:
    /* struct timeval m_tv_init;
    struct timeval m_tv_cur;
    string m_msg; */
};

#endif /* OTAPLUSTIMER_H_ */