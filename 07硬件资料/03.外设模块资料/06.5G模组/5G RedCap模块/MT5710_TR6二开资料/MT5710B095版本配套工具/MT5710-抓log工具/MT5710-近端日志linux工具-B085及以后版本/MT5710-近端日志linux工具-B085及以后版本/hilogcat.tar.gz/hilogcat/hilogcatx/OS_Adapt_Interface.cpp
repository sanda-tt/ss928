#include "OS_Adapt_Interface.h"
#include "OS_Adapt_PortOperationImpl_Android.h"


COSAdapt g_COSAdapt;

OS_ADAPT_ERROR OS_ADAPT_EnumDevicePortInfo( OS_ADAPT_PORT_TYPE enPortType, OS_ADAPT_DEVICEINFOLIST* pstDeviceInfoList )
{
    if ( OS_ADAPT_ERROR_SUCCED != g_COSAdapt.FindPortByDriverToolString(enPortType, pstDeviceInfoList))
    {
        return g_COSAdapt.EnumDevicePortInfo( enPortType, pstDeviceInfoList );
    }
    return OS_ADAPT_ERROR_SUCCED;
}

OS_ADAPT_ERROR OS_ADAPT_OpenPort( const char* pszPortName, PORT_HANDLE* phFileDesc )
{
    return g_COSAdapt.OpenPort( pszPortName, phFileDesc );
}


OS_ADAPT_ERROR OS_ADAPT_ClosePort( PORT_HANDLE hFileDesc )
{
    return g_COSAdapt.ClosePort( hFileDesc );
}

OS_ADAPT_ERROR OS_ADAPT_Read( PORT_HANDLE hFileDesc, void* pBuffer, long lInSize, long* plOutSize )
{
    return g_COSAdapt.Read( hFileDesc, pBuffer, lInSize, plOutSize );
}

OS_ADAPT_ERROR OS_ADAPT_Write( PORT_HANDLE hFileDesc, void* pBuffer, long lInSize, long* plOutSize )
{
    return g_COSAdapt.Write( hFileDesc, pBuffer, lInSize, plOutSize );
}

OS_ADAPT_PORTSTATUS_TYPE OS_ADAPT_GetPortState( const char* pszPortName )
{
    return g_COSAdapt.GetPortState( pszPortName );
}

OS_ADAPT_ERROR OS_ADAPT_RegisterDeviceStateProcessCallBack( OS_ADAPT_DEVICE_STATE_PROCESS_CALLBACK_FUNC pfnFunc )
{
    return g_COSAdapt.RegisterDeviceStateProcessCallBack(pfnFunc);
}

OS_ADAPT_ERROR OS_ADAPT_UnRegisterDeviceStateProcessCallBack( OS_ADAPT_DEVICE_STATE_PROCESS_CALLBACK_FUNC pfnFunc )
{
    return g_COSAdapt.UnRegisterDeviceStateProcessCallBack(pfnFunc);
}
extern "C" OSADAPTSHARED_EXPORT void OS_ADAPT_SetPortMode( OS_ADAPT_MODE mode )
{
    g_COSAdapt.SetPortMode(mode);
}

extern "C" OSADAPTSHARED_EXPORT OS_ADAPT_MODE OS_ADAPT_GetPortMode()
{
    return g_COSAdapt.GetPortMode();
}
