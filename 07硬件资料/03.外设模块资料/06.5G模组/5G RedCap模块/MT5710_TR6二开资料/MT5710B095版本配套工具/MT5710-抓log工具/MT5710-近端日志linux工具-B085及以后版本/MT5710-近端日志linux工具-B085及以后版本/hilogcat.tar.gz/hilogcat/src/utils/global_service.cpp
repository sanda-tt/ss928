﻿#include "global_service.h"
#include <utils/mdm_log.h>
#include <main/LpdFileManager.h>
#include <inc/custom_define.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

using namespace std;
using namespace ModemLogMdmLog;
using namespace HsaLpdFileManager;

#define LOCKMODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

volatile bool GlobalService::m_processExit = false;

// 递归创建文件目录（类似：mkdir -p）
bool GlobalService::mkdirs(const char *sPathName, mode_t mode)
{
    char  DirName[MAX_PATH_LENGTH] = {0};
    // DTS2017061602705 modemlogcat crash lishiquan/00309883 20170620
    if (sPathName == nullptr) {
        IMODEMLOG(MDM_LOG_ERROR, "sPathName is null");
        return false;
    }
   #ifdef USE_CCC_TDT
    int err = strncpy_s(DirName, MAX_PATH_LENGTH, sPathName, MAX_PATH_LENGTH - 1);
    if (err != EOK) {
        IMODEMLOG(MDM_LOG_ERROR, "strncpy_s failed, errno = %d", err);
        return false;
    }
    #endif
    if (DirName[MAX_PATH_LENGTH - 1] != 0) {
        IMODEMLOG(MDM_LOG_ERROR, "log path is longer than max");
        return false;
    }
    size_t len = strlen(DirName); /* 已做检查，不会越界 */
    if (len == MAX_PATH_LENGTH - 1) {
        if (DirName[len - 1] != '/') {
            DirName[len - 1] = '/';
            len++;
        }
    } else if (DirName[len - 1] != '/') {
        DirName[len] = '/'; /* 已做检查，不会越界 */
        len++;
    }

    for (size_t i = 1; i < len; i++) {
        if (DirName[i] != '/') {
            continue;
        }
        DirName[i] = 0;
        if (access(DirName, F_OK) != 0) {
            if (mkdir(DirName, mode) == -1) {
                return false;
            }
        }
        DirName[i] = '/';
    }
    return true;
}

int GlobalService::LockFile(int fd)
{
    struct flock fl;
    fl.l_type = F_WRLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;
    int nRet = fcntl(fd, F_SETLK, &fl);
    return nRet;
}

bool GlobalService::checkProcessExistByName(const char *filename)
{
    int fd = 0;
    char buf[16] = "lockflag";
    fd = open(filename, O_RDWR | O_CREAT, LOCKMODE);
    if (fd < 0) {
        exit(1);
    }
    if (LockFile(fd) == -1) {
        if (errno == EACCES || errno == EAGAIN) {
            close(fd);
            return true;
        }
        close(fd);
        exit(1);
    }
    if (ftruncate(fd, 0) != 0) {
        IMODEMLOG(MDM_LOG_ERROR, "ftruncate failed");
    }
    write(fd, buf, strlen(buf) + 1);
    return false;
}

void GlobalService::InitWorkPath()
{
    if (chdir(WORK_PATH_BASE.c_str()) < 0) {
        mkdirs(WORK_PATH_BASE.c_str(), S_IRWXU);
    }
    if (chdir(DEFAULT_LPDLOG_PATH.c_str()) < 0) {
        mkdirs(DEFAULT_LPDLOG_PATH.c_str(), S_IRWXU);
    }
}

string GlobalService::GetHexString(const unsigned char *data, uint32_t size)
{
    const int oneByteStrLen = 4;
    string hexInfo;
    for (uint32_t i = 0; i < size; i++) {
        char hex[oneByteStrLen] = { 0 };
       #ifdef USE_CCC_TDT
        int printLen = sprintf_s(hex, oneByteStrLen, "%02x ", data[i]);
        
        if (printLen < 0) {
            IMODEMLOG(MDM_LOG_ERROR, "sprintf_s failed, printLen: %d, errno: %d", printLen, errno);
            return hexInfo;
        }
        #endif
        hexInfo += string(hex, oneByteStrLen - 1);
        if (hexInfo.size() > (MAX_LOG_BUF_LEN / 2)) {   // 2 times buffer
            hexInfo += string("...");
            break;
        }
    }
    return hexInfo;
}