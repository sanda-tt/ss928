﻿#include "FileOper_Linux.h"
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

RET_CODE FileOper::Init()
{
    if (m_fd == INVALID_FD)
    {
        if (m_mode == WRITE_MODE)
        {
            m_fd = open(m_file_path.c_str(), O_WRONLY |O_CREAT | O_TRUNC, PATH_CREATE_MODE);
        }
        else
        {
            m_fd = open(m_file_path.c_str(), O_RDONLY);
        }

        LOG_WARN("file FD %d -> %s", m_fd, m_file_path.c_str());
        CHECK_EXPR_RET(m_fd < 0, ERR_CODE_FILE_OPEN_FAIL);
    }

    return ERR_CODE_SUCCESS;
}

RET_CODE FileOper::Destroy()
{
    if (m_fd != INVALID_FD)
    {
        close(m_fd);
        m_fd = INVALID_FD;
    }

    return ERR_CODE_SUCCESS;
}

UINT FileOper::ReadData(CHAR *buff, UINT max_len, FILE_OFFSET offset)
{
    CHECK_EXPR_RET(m_fd < 0, 0);
    FILE_OFFSET cur = lseek(m_fd, offset, SEEK_SET);
    int read_len = read(m_fd, buff, max_len);

    if (read_len <= 0)
    {
        LOG_WARN("ReadData offset=%lld, cur = %lld, read_len = %d ", offset, cur, read_len);
    }

    return read_len;
}

UINT FileOper::WriteData(const CHAR *buff, UINT len)
{
    CHECK_EXPR_RET(m_fd < 0, 0);
    int write_len = write(m_fd, buff, len);

    if (write_len <= 0)
    {
        LOG_WARN("WriteData write_len = %d ", write_len);
    }

    return write_len;
}

RET_CODE FileOper::Complete(bool is_ok)
{
    RET_CODE ret = ERR_CODE_SUCCESS;
    close(m_fd);
    m_fd = INVALID_FD;

    if (!is_ok)
    {
        ret = unlink(m_file_path.c_str());
    }

    return ret;
}

FILE_OFFSET FileOper::GetFileSize()
{
    CHECK_EXPR_RET(m_fd < 0, INVALID_FILE_SIZE);

    FILE_OFFSET file_size = lseek(m_fd, 0, SEEK_END);
    LOG_WARN("GetFileSize size = %lld ", file_size);

    return file_size;
}

FILE_OFFSET FileOper::GetFileSize(const char* file_path)
{
    FILE_OFFSET size = INVALID_FILE_SIZE;
    FILE_HANDLE fd = open(file_path, O_RDONLY);
    if (fd != INVALID_FD)
    {
        size = lseek(fd, 0, SEEK_END);
        close(fd);
    }

    return size;
}

bool FileOper::IsOperAllowed(string file_path, E_OPER_MODE mode)
{
    return true;  // 调测或工具侧-不限制文件读写
}

RET_CODE FileOper::DeleteFile(const char* file_path)
{
    RET_CODE ret = unlink(file_path);

    LOG_WARN("delete %s, ret %d", file_path, ret);
    return ret;
}
