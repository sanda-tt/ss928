﻿#ifndef XMODEM_CRC16_
#define XMODEM_CRC16_
#define BIT_NUM_PER_BYTE 8

class XModemCrc16
{

public:
    // 计算CRC16
    static unsigned short CalcCrc16(unsigned char *data_buffer, unsigned int length);

};

#endif /* XMODEM_CRC16_ */