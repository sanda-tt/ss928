﻿#ifndef OTAPLUSLOGGER_H_
#define OTAPLUSLOGGER_H_
#include <stdarg.h>

typedef enum _E_OTAPLUS_LOG_LEVEL
{
    OTAPLUS_LOG_LEVEL_INFO = 0,
    OTAPLUS_LOG_LEVEL_WARN,
    OTAPLUS_LOG_LEVEL_DEFAULT = OTAPLUS_LOG_LEVEL_WARN,
    OTAPLUS_LOG_LEVEL_ERR,
} E_OTAPLUS_LOG_LEVEL;

class OtaplusLogger
{
public:
    static OtaplusLogger* Instance();

    static void Destroy();

    void Log(E_OTAPLUS_LOG_LEVEL level, const char* file_name, unsigned line, const char* fmt, ...);

    void SetLogLevel(const char* log_level);

private:
    OtaplusLogger();

    ~OtaplusLogger();

    void Init();

public:
    static bool s_need_prefix;

private:
    static OtaplusLogger* s_pInstance;
    E_OTAPLUS_LOG_LEVEL m_log_level;
    int  m_fd_log;
    bool m_file_write;
};

#define LOG_ERROR(log_msg, args...) OtaplusLogger::Instance()->Log(OTAPLUS_LOG_LEVEL_ERR,  __FILE__, __LINE__, log_msg, ##args)
#define LOG_WARN(log_msg, args...)  OtaplusLogger::Instance()->Log(OTAPLUS_LOG_LEVEL_WARN, __FILE__, __LINE__, log_msg, ##args)
#define LOG_INFO(log_msg, args...)  OtaplusLogger::Instance()->Log(OTAPLUS_LOG_LEVEL_INFO, __FILE__, __LINE__, log_msg, ##args)

#endif /* OTAPLUSLOGGER_H_ */
