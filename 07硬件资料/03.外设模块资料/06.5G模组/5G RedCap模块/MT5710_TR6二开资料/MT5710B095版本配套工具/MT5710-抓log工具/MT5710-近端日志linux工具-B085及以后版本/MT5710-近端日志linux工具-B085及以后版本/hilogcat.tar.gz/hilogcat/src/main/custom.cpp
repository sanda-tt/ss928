#include <inc/custom_define.h>

errno_t memcpy_s(void *det, size_t detSize, const void * src, size_t srcSize)
{
	if (srcSize > detSize || src == NULL || det == NULL)
	{
		return -1;
	}

	memcpy(det, src, srcSize);

	return 0;
}

errno_t memset_s(void *dest, size_t destMax, int c, size_t count){

    /* 检查参数是否合法 */
    if (dest == NULL || destMax < count)
    {
		return -1;
    }

    memset(dest, c, count);
    
    return 0;
}


errno_t strncpy_s(char *strDest, size_t destMax, const char *strSrc, size_t count){
	if (count > destMax || strDest == NULL || strSrc == NULL)
	{
		return -1;
	}
    strcpy(strDest, strSrc);

	return 0;
}

errno_t snprintf_s(char *strDest, size_t destMax, size_t count, const char *format,...){
    
	if (count > destMax || strDest == NULL)
	{
		return -1;
	}

    va_list args;
    va_start(args, format);
    vsnprintf(strDest, destMax, format, args);
    va_end(args);

    return 0;
}

errno_t sprintf_s(char *strDest, size_t destMax, const char *format, ...){
	if (destMax == 0 || strDest == NULL)
	{
		return -1;
	}

    va_list args;
    va_start(args, format);
    vsnprintf(strDest, destMax, format, args);
    va_end(args);

    return 0;
}

errno_t vsnprintf_s(char *strDest, size_t destMax, size_t count, const char *format, ...){
	if (count > destMax || strDest == NULL)
	{
		return -1;
	}
	
    va_list args;
    va_start(args, format);
    vsnprintf(strDest, destMax, format, args);
    va_end(args);

    return 0;
}
