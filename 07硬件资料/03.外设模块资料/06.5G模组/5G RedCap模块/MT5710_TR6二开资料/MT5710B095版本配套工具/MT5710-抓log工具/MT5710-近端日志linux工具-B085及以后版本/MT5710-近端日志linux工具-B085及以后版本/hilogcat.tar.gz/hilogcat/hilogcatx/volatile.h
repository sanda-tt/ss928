#ifndef __VOLATILE_H__
#define __VOLATILE_H__

#ifdef ULOG_DEMO
#define _THIS_VERSION_    "2.3.0.4 DEMO version"
#else
#define _THIS_VERSION_    "2.3.0.4"
#endif


#endif
