﻿#ifndef DATACHANNEL_LINUX_H_
#define DATACHANNEL_LINUX_H_

#include "CommonDef.h"
#include "OS_Adapt_Interface.h"
#include <string>
#include <list>
#include <termios.h>
#include <vector>
#include <map>

using std::vector;
using std::string;
using std::list;
using std::map;

typedef bool (*READEND_FUNC)(CHAR* buffer, UINT len);
typedef string (*REPORT_CHNL_FNC)();

class DataChannel
{
public:
    DataChannel(const char* chnl_path = "");

    virtual ~DataChannel();

    void CleanResource();

    bool SetChnlMode(E_DATACHANNEL_MODE chnl_mode);

    bool IsChannelAvailable();
	
	void SendAtCmd(const char *cmd, UINT buff_len);
	
	bool getPorts( vector<string> &strPorts );
	
	bool isPcuiPort( const string& portName );
	
	bool isGpsPort( const string& portName );
	
	string getPcuiPortName();
	string getGpsPortName();

    RET_CODE Init(E_DATACHANNEL_MODE chnl_mode);

    RET_CODE Destroy();

    RET_CODE ReOpen();

    RET_CODE SetChnlPath(string chnl_path);

    UINT ReadData(CHAR *buff, UINT max_len, READEND_FUNC is_end_func = NULL);

    UINT SendData(const CHAR *buff, UINT len);

    virtual const char* GetChnlQueryScript(bool is_1st_try);

    virtual const char* GetPcieChnlPath();

    virtual bool CanChnlChange() { return true; }

private:
    RET_CODE ConfigChannel(FILE_HANDLE fd);

    RET_CODE AdjustChnlMode(E_DATACHANNEL_MODE& chnl_mode);
	
	void initPcuiSignList();
	void initGpsSignList();

protected:
    string m_chnl_path;

private:
    E_DATACHANNEL_MODE m_chnl_mode;
    FILE_HANDLE m_fd_in;
    FILE_HANDLE m_fd_out;
    struct termios m_chnl_option;
	vector<string> m_pcuiSignList;
	vector<string> m_gpsSignList;
	map<string, OS_ADAPT_PORT_TYPE> m_ports_type;
};

#endif /* DATACHANNEL_LINUX_H_ */
