#include "utils/global_service.h"
#include <unistd.h>
#include <utils/mdm_log.h>
#include <main/AgentMsgManager.h>
#include <main/LpdFileManager.h>
#include <inc/custom_define.h>
#include "ChannelDataHandler.h"
#include <stdlib.h>

using namespace ModemLogMdmLog;
using namespace HsaLpdFileManager;

CChannelDataHandler dataHandler;
string g_ip;
int g_limit;

// 处理外部进程发给Modemlogcat的信号（kill: signal 9, teminate: signal 15）
static void HandleSignal(int signo)
{
    IMODEMLOG(MDM_LOG_EVENT, "main process got signal(signo = %d), is about to exit.\n", signo);
    // GlobalService::m_processExit = true;
    int state = 0;
    AgentMsgManager::GetInstance()->SendReqMsg(CMDID_SET_HSA_START_STOP_REQ, &state, sizeof(int));
}

// 注册进程退出时信号处理函数
void RegSignalHandler()
{
    struct sigaction sa;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sa.sa_handler = HandleSignal;
    sigaction(SIGTERM, &sa, nullptr);
}

// 主线程循环
void LoopMainProc()
{
    while (!GlobalService::m_processExit) {
        const uint64_t sleepTime = 1;
        sleep(sleepTime);
    }
    IMODEMLOG(MDM_LOG_EVENT, "m_processExit is true, main process exit");
}

void Init()
{
    // 初始化
    GlobalService::m_processExit = false;
    // 初始化工作目录
    GlobalService::InitWorkPath();
}

// 进程退出时的逻辑处理
void ExitMainProcess()
{
    // 删除PID，避免进程重复启动
    if (remove(PROC_LOCKFILE.c_str()) == -1) {
        IMODEMLOG(MDM_LOG_EVENT, "remove hscpid file failed");
    }
    IMODEMLOG(MDM_LOG_EVENT, "remove hscpid file end");
}

int main(int argc, char *argv[])
{
    if (strcmp(argv[1], "-aplog") == 0) {
	dataHandler.CaptureAPOfflineLog(argv[2]);
	return 0;
    } else if (strcmp(argv[1], "-cplog") != 0) {
	_exit(0);	
    }

    dataHandler.CaptureCPOfflineLog();

    bool needExist = GlobalService::checkProcessExistByName(PROC_LOCKFILE.c_str());
    if (needExist == true) {
        IMODEMLOG(MDM_LOG_ERROR, "second process return ..........................");
        return 0;
    }
    IMODEMLOG(MDM_LOG_EVENT, "modemlogcat main start ..........................");
    IMODEMLOG(MDM_LOG_INFO, "version: 20210402-2");
    RegSignalHandler();
    Init();
    g_ip = string(argv[2]);
	//g_ip = ipResult;
    if (argc > 3) {
        if (strcmp(argv[3], "-limit") == 0) {
            g_limit = 1;
        }
    }

    LpdFileManager::GetInstance().StartWriteLpdProc();

    if (!AgentMsgManager::GetInstance()->OpenCmdChannel(g_ip)) {
        IMODEMLOG(MDM_LOG_ERROR, "OpenCmdChannel failed");
        return 0;
    }
    AgentMsgManager::GetInstance()->StartCnfRecvProc();
    
    // 启动抓modem log
    int state = MODEMLOG_START;
    AgentMsgManager::GetInstance()->SendReqMsg(CMDID_SET_HSA_START_STOP_REQ, &state, sizeof(int));
    // 主线程循环
    IMODEMLOG(MDM_LOG_EVENT, "main thread loop ...");
    LoopMainProc();
    AgentMsgManager::GetInstance()->StopIndRecvProc();
    AgentMsgManager::GetInstance()->CloseIndChannel();
    AgentMsgManager::GetInstance()->StopCnfRecvProc();
    AgentMsgManager::GetInstance()->CloseCmdChannel();
    LpdFileManager::GetInstance().StopWriteLpdProc();
    dataHandler.StopCPOfflineLog();
    // 进程退出时的逻辑处理
    ExitMainProcess();
    IMODEMLOG(MDM_LOG_EVENT, "modemlogcat main end ..........................");
    _exit(0);
    return 0;
}
