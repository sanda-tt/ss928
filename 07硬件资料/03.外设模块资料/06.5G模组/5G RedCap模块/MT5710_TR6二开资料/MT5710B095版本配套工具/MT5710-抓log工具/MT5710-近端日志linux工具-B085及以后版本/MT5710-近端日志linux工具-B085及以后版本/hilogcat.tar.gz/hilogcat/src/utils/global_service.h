#ifndef GLOBAL_SERVICE_H
#define GLOBAL_SERVICE_H

#include <cstdio>
#include <signal.h>
#include <list>
#include <cstring>
#include <sys/types.h>
#include <sys/wait.h>
#include <main/AgentMsgManager.h>

// Modemlog状态(用于内部标记)
enum ModemlogStatus {
    MODEMLOG_STOP = 0,
    MODEMLOG_START = 1,
};

class GlobalService {
public:
    static bool checkProcessExistByName(const char *filename);
    static void InitWorkPath();
    static std::string GetHexString(const unsigned char *data, uint32_t size);

    static volatile bool m_processExit;
private:
    static bool mkdirs(const char *sPathName, mode_t mode);
    static int LockFile(int fd);
};
#endif // GLOBAL_SERVICE_H