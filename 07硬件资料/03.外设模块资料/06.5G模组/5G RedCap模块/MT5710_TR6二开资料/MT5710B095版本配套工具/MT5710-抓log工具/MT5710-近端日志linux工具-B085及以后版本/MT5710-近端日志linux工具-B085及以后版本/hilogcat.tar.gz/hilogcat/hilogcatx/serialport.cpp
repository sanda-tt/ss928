#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <string.h>
#include <errno.h>
#include "serialport.h"
#include <sys/file.h>

#define MTP_TDTECH_VID                          "3466"
#define MTP_HP_VID                              "03F0"
#ifndef WIN32
#define MTP_PATH_DRIVERS                        "/sys/bus/usb/devices"
#define MTP_PATH_DRIVERS_OPTION                 "/sys/bus/usb/drivers/option"
#define MTP_PATH_CHILD_DRIVERS_OPTION_FORMAT    "/sys/bus/usb/drivers/option/%s"                    // /sys/bus/usb/drivers/option/x-x:x.x Ŀ¼��
#define MTP_PATH_MODALIAS_FORMAT                "/sys/bus/usb/drivers/option/%s/modalias"           // modalias�ļ����洢
#define MTP_PATH_BINTERFACENUMBER_FORMAT        "/sys/bus/usb/drivers/option/%s/bInterfaceNumber"   //�ļ�bInterfaceNumber·��
#define MTP_PATH_BINTERFACEPROTOCOL_FORMAT      "/sys/bus/usb/drivers/option/%s/bInterfaceProtocol"

// �ṹ����number��bInterfaceNumber�е�ֵһ��
// indexֵ��ʾ��Ӧʲô�˿�0:modem 1:diag  2:pcui
struct PORTINFO
{
    const char * number;
    int  index;
};

struct DEVICEPORTS
{
    const char * PID;
    struct PORTINFO modem;
    struct PORTINFO diag;
    struct PORTINFO pcui;
    struct PORTINFO serial;
};

static const struct DEVICEPORTS Devices[] = {
    {"1001", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1003", {"00",0}, {"_",1},  {"01",2}, {"_",3}},  //"_"��ʾû�ж˿ڶ�Ӧ
    {"1004", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1401", {"_",0},  {"00",1}, {"02",2}, {"_",3}},
    {"1402", {"00",0}, {"_",1},  {"02",2}, {"_",3}},
    {"1403", {"_",0},  {"02",1}, {"00",2}, {"_",3}},
    {"1404", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1405", {"_",0},  {"_",1},  {"00",2}, {"_",3}},
    {"1406", {"00",0}, {"_",1},  {"01",2}, {"_",3}},
    {"1408", {"_",0},  {"_",1},  {"00",2}, {"_",3}},
    {"140A", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"140B", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"140C", {"00",0}, {"01",1}, {"03",2}, {"_",3}},
    {"140E", {"_",0},  {"01",1}, {"02",2}, {"_",3}},
    {"1417", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1418", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"141E", {"00",0}, {"_",1},  {"01",2}, {"_",3}},
    {"1420", {"00",0}, {"_",1},  {"01",2}, {"_",3}},
    {"1421", {"_",0},  {"_",1},  {"00",2}, {"_",3}},
    {"1422", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1427", {"00",0}, {"02",1}, {"03",2}, {"_",3}},
    {"1428", {"00",0}, {"02",1}, {"03",2}, {"_",3}},
    {"1429", {"00",0}, {"_",1},  {"02",2}, {"_",3}},
    {"142A", {"00",0}, {"_",1},  {"02",2}, {"_",3}},
    {"1448", {"00",0}, {"_",1},  {"01",2}, {"_",3}},
    {"144A", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"144B", {"00",0}, {"01",1}, {"03",2}, {"_",3}},
    {"14A8", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"14A9", {"00",0}, {"_",1},  {"01",2}, {"_",3}},
    {"14AA", {"00",0}, {"02",1}, {"03",2}, {"_",3}},
    {"14AB", {"00",0}, {"02",1}, {"03",2}, {"_",3}},
    {"14AC", {"00",0}, {"02",1}, {"03",2}, {"_",3}},
    {"1506", {"00",0}, {"02",1}, {"01",2}, {"_",3}},
    {"1510", {"00",0}, {"01",1}, {"03",2}, {"_",3}},
    {"1511", {"00",0}, {"01",1}, {"03",2}, {"_",3}},
    {"1512", {"00",0}, {"_",1},  {"02",2}, {"_",3}},
    {"1513", {"00",0}, {"01",1}, {"02",2}, {"_",3}},
    {"1514", {"00",0}, {"01",1}, {"03",2}, {"_",3}},
    {"1515", {"00",0}, {"02",1}, {"01",2}, {"_",3}},
    {"1F1A", {"02",0}, {"03",1}, {"04",2}, {"06",3}}
};

// ��PID������bInterfaceProtocol != 0xFF,����Ķ˿���̬���±�����ֵ����.
static const MTP_PORT_TYPE newpid_protocol_map[0x80] = {
    // ͨ�ð�Protocol
    MTP_PORT_UNKNOWN   , MTP_PORT_MODEM     , MTP_PORT_PCUI      , MTP_PORT_DIAG      , // 0, 1, 2, 3
    MTP_PORT_PCSC      , MTP_PORT_NMEA      , MTP_PORT_GPS_CTRL  , MTP_PORT_WIN_NDIS  , // 4, 5, 6, 7
    MTP_PORT_ECM_DATA  , MTP_PORT_ECM_CTRL  , MTP_PORT_BLUETOOTH , MTP_PORT_FINGERPRNT, // 8, 9, 0x0A, 0x0B
    MTP_PORT_ACM_CTRL  , MTP_PORT_MMS       , MTP_PORT_VOICE     , MTP_PORT_DVB       , // 0x0C,0x0D,0x0E,0x0F
    MTP_PORT_MODEM_NO3G, MTP_PORT_NDIS_NO3G , MTP_PORT_PCUI_NO3G , MTP_PORT_DIAG_NO3G , // 0x10,0x11,0x12,0x13
    MTP_PORT_GPS_NO3G  , MTP_PORT_VOICE_NO3G, MTP_PORT_NCM       , MTP_PORT_MODEM_ORNG, // 0x14,0x15,0x16,0x17
    MTP_PORT_SHELL_A   , MTP_PORT_SHELL_B   , MTP_PORT_COM_A     , MTP_PORT_COM_B     , // 0x18,0x19,0x1A,0x1B
    MTP_PORT_COM_C     , MTP_PORT_GNSS      , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x1C,0x1D,0x1E,0x1F
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x20,0x21,0x22,0x23
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x24,0x25,0x26,0x27
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x28,0x29,0x2A,0x2B
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x2C,0x2D,0x2E,0x2F

    // VDF���ư�Protocol
    MTP_PORT_UNKNOWN   , MTP_PORT_MODEM     , MTP_PORT_PCUI      , MTP_PORT_DIAG      , // 0x30,0x31,0x32,0x33
    MTP_PORT_PCSC      , MTP_PORT_NMEA      , MTP_PORT_GPS_CTRL  , MTP_PORT_WIN_NDIS  , // 0x34,0x35,0x36,0x37
    MTP_PORT_ECM_DATA  , MTP_PORT_ECM_CTRL  , MTP_PORT_BLUETOOTH , MTP_PORT_FINGERPRNT, // 0x38,0x39,0x3A,0x3B
    MTP_PORT_ACM_CTRL  , MTP_PORT_MMS       , MTP_PORT_VOICE     , MTP_PORT_DVB       , // 0x3C,0x3D,0x3E,0x3F
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x40,0x41,0x42,0x43
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_NCM       , MTP_PORT_UNKNOWN   , // 0x44,0x45,0x46,0x47
    MTP_PORT_SHELL_A   , MTP_PORT_SHELL_B   , MTP_PORT_COM_A     , MTP_PORT_COM_B     , // 0x48,0x49,0x4A,0x4B
    MTP_PORT_COM_C     , MTP_PORT_GNSS      , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x4C,0x4D,0x4E,0x4F
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x50,0x51,0x52,0x53
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x54,0x55,0x56,0x57
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x58,0x59,0x5A,0x5B
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x5C,0x5D,0x5E,0x5F

    // �ް汾����
    MTP_PORT_UNKNOWN   , MTP_PORT_MODEM     , MTP_PORT_PCUI      , MTP_PORT_DIAG      , // 0x60,0x61,0x62,0x63
    MTP_PORT_PCSC      , MTP_PORT_NMEA      , MTP_PORT_GPS_CTRL  , MTP_PORT_WIN_NDIS  , // 0x64,0x65,0x66,0x67
    MTP_PORT_ECM_DATA  , MTP_PORT_ECM_CTRL  , MTP_PORT_BLUETOOTH , MTP_PORT_FINGERPRNT, // 0x68,0x69,0x6A,0x6B
    MTP_PORT_ACM_CTRL  , MTP_PORT_MMS       , MTP_PORT_VOICE     , MTP_PORT_DVB       , // 0x6C,0x6D,0x6E,0x6F
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x70,0x71,0x72,0x73
    MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , MTP_PORT_NCM       , MTP_PORT_UNKNOWN   , // 0x74,0x75,0x76,0x77
    MTP_PORT_SHELL_A   , MTP_PORT_SHELL_B   , MTP_PORT_COM_A     , MTP_PORT_COM_B     , // 0x78,0x79,0x7A,0x7B
    MTP_PORT_COM_C     , MTP_PORT_GNSS      , MTP_PORT_UNKNOWN   , MTP_PORT_UNKNOWN   , // 0x7C,0x7D,0x7E,0x7F
};
#endif

CSerialPort::CSerialPort(void)
{

}

CSerialPort::~CSerialPort(void)
{
    //Close();
}

const char * CSerialPort::PortType(MTP_PORT_TYPE type)
{
    const char * strType[] =
    {
        "UNKNOWN",
        "MODEM",
        "PCUI",
        "DIAG",
        "PCSC",
        "NMEA",
        "GPS CONTROL",
        "WIN NDIS",
        "ECM DATA",
        "ECM CONTROL",
        "BLUETOOTH",
        "FINGERPRNT",
        "ACM CONTROL",
        "MMS",
        "VOICE",
        "DVB",
        "MODEM NO3G",
        "NDIS NO3G",
        "PCUI NO3G",
        "DIAG NO3G",
        "GPS NO3G",
        "VOICE NO3G",
        "NCM",
        "MODEM ORANGE",
        "SHELL A",
        "SHELL B",
        "General COM A",
        "General COM B",
        "General COM C",
        "GNSS"
    };

    if (type >= 0 && type <= MTP_PORT_GNSS)
    {
        return strType[type];
    }

    return "";
}

BOOL CSerialPort::IsValidVid(const char * pszModaliasData)
{
    const char * vid_list[] = 
    {
        MTP_TDTECH_VID,
        MTP_HP_VID
    };

    for (unsigned int i=0; i < sizeof(vid_list)/sizeof(vid_list[0]); ++i)
    {
        if (strstr(pszModaliasData, vid_list[i]))
        {
            return TRUE;
        }
    }

    return FALSE;
}

BOOL CSerialPort::FindPortName(const char * path, char name[MTP_MAX_PORT_NAME], BOOL oldPid)
{
    struct dirent *pdirent = NULL;
    DIR * pDir = opendir(path);

    name[0] = '\0';
    if (NULL != pDir)
    {
        while (TRUE)
        {
            pdirent = readdir(pDir);
            if (NULL == pdirent)
            {
                break;
            }

            if( strstr(pdirent->d_name,"ttyUSB") || (oldPid && strstr(pdirent->d_name,"ttyACM")) )
            {
                snprintf(name, MTP_MAX_PORT_NAME - 1, "/dev/%s", pdirent->d_name);
                break;
            }
        }
        closedir(pDir);
    }

    return name[0] != '\0';
}


void CSerialPort::EnumAllPorts(MTP_PORT_LIST * port_list)
{
    EnumAllPortsByDir(port_list, MTP_PATH_DRIVERS_OPTION);
    if( 0 >= port_list->actNum )
    {
         EnumAllPortsByDir(port_list, MTP_PATH_DRIVERS);
    }
}

void CSerialPort::EnumAllPortsByDir(MTP_PORT_LIST * port_list, const char* pDriverDir)
{
    //Trace_INFO("Enum port in Dir: %s\n", pDriverDir);
    DIR *pDrvOptionDir = NULL;      // /sys/bus/usb/drivers/optionĿ¼�µ�Ŀ¼��
    FILE *pfmodalias = NULL;        // /sys/bus/usb/drivers/option/%s/modalias �ļ�ָ��

    char szModaliasFile[MTP_MAX_PATH] = { 0 };  //"/sys/bus/usb/drivers/option/%s/modalias"�ļ�
    char szModaliasData[MTP_MAX_PATH] = { 0 };  //����modalias�е�����

    struct dirent * pdir = NULL;

    if (!port_list)
    {
        return;
    }

    port_list->actNum = 0;

    //����"sys/bus/usb/drivers/option"Ŀ¼�µ��ļ�
    pDrvOptionDir = opendir(pDriverDir);
    if (pDrvOptionDir)
    {
        do
        {
            pdir = readdir(pDrvOptionDir);
            if (!pdir)
            {
                break;
            }
            //Trace_INFO("Get PID: %s\n", pdir->d_name);    
            if (strchr(pdir->d_name, ':')) //�ж��ļ�����ʽ�Ƿ���ȷ.x-x:x-x Ŀ¼����, ����"2-1.4:1.0"
            {
                char szMdaliasFomat[MTP_MAX_PATH] = {0};
                strcat(szMdaliasFomat, pDriverDir);
                strcat(szMdaliasFomat, "/%s/modalias");
                sprintf(szModaliasFile, (const char*)szMdaliasFomat, pdir->d_name);                      //�ļ�modalias·��

                //��ȡmodalias�ļ�����.modalias�ļ��е�����,������Ʒ��VID,PID.����:cat modalias  usb:v12D1p1506d0001dc00dsc00dp00icFFisc02ip01
                pfmodalias = fopen(szModaliasFile, "r");
                if(NULL != pfmodalias)
                {
                    if (NULL == fgets(szModaliasData, MTP_MAX_PATH - 1, pfmodalias))
                    {
                        fclose(pfmodalias);
                        continue;
                    }

                    //�ж��Ƿ��ǻ�Ϊ�ĵ���ӿ�
                    //Trace_INFO("Get VID: %s\n", szModaliasData);
                    if (!IsValidVid(szModaliasData))
                    {
                        fclose(pfmodalias);
                        continue;
                    }

                    //�ж�PID�Ƿ�ƥ��
                    if (MactchInterfaceNumber(pDriverDir, szModaliasData, pdir->d_name, &port_list->list[port_list->actNum]))
                    {
                        port_list->actNum++;
                    }

                    fclose(pfmodalias);
                }
            } /* endof if (strchr(pdir->d_name, ':')) */
        } while (1);

        closedir(pDrvOptionDir);
    } /* endof if (pDrvOptionDir) */
}


BOOL CSerialPort::MactchInterfaceNumber(const char* pDriverDir, const char * pszPID, const char * dirname, MTP_PORT_INFO * port)
{
    //DIR *pDir = NULL;                      // /sys/bus/usb/drivers/option/x-x:x.x Ŀ¼�µ�Ŀ¼��
    //struct dirent *pdirent = NULL;
    FILE *pfbInterfaceNumber = NULL;
    FILE *pfbInterfaceProtocol = NULL;
    char szbFileName[MTP_MAX_PATH] = { 0 };
    char szbBuffer[MTP_MAX_PORT_SIZE] = { 0 };

    // 1. ��ѯ�˿����ͣ������ж��Ƿ�Ϊ��PID����
    char szbInterfaceProtocolFormat[MTP_MAX_PATH] = {0};
    strcat(szbInterfaceProtocolFormat, pDriverDir);
    strcat(szbInterfaceProtocolFormat, "/%s/bInterfaceProtocol");
    sprintf(szbFileName, (const char*)szbInterfaceProtocolFormat, dirname);  //"/sys/bus/usb/drivers/option/%s/bInterfaceProtocol"
    pfbInterfaceProtocol = fopen(szbFileName, "r");
    if (NULL == pfbInterfaceProtocol)
    {
        return FALSE;
    }

    memset(szbBuffer, 0, sizeof(szbBuffer));
    fread(szbBuffer, 1, sizeof(szbBuffer), pfbInterfaceProtocol);
    fclose(pfbInterfaceProtocol);
    //Trace_INFO("Get bInterfaceProtocol: %s\n", szbBuffer);
    port->type = MTP_PORT_UNKNOWN;
    if (szbBuffer[0] != 'F' && szbBuffer[1] != 'F') // bInterfaceProtocol != 0xFF,�������豸����PID����
    {
        long protocol = strtol(szbBuffer, NULL, 16);
        if (protocol > 0 && protocol < (long)(sizeof(newpid_protocol_map) / sizeof(MTP_PORT_TYPE)))
        {
            port->type = newpid_protocol_map[protocol];
        }

        if (MTP_PORT_UNKNOWN == port->type)
        {
            return FALSE;   // ��PID������δ�ҵ�ƥ��Ķ˿�������ֱ�ӷ��ش���.
        }
    }

    // 2. ��ѯ�˿�����
    // ���ҵ�ǰĿ¼���Ƿ��а���"ttyUSB"��"ttyACM"���ļ���.����У�����ļ���Ϊ��������
    char szChildFormat[MTP_MAX_PATH] = {0};
    strcat(szChildFormat, pDriverDir);
    strcat(szChildFormat, "/%s");
    sprintf(szbFileName, (const char*)szChildFormat, dirname);
    if (port->type != MTP_PORT_UNKNOWN)     // ��PID����,ֱ�ӷ��ز��Ҷ˿����ƵĽ��
    {
        return FindPortName(szbFileName, port->name, FALSE);
    }
    else if (!FindPortName(szbFileName, port->name, TRUE))
    {
        return FALSE;
    }

    // �ɵ�PID����,ͨ��bInterfaceNumber��ֵ��PIDTable��ӳ���ϵ�ж�
    // ��bInterfaceNumber�ļ����Ӹ��ļ��ж�ȡ�ӿں��룬���ݴ˺����ж϶˿�����(MODEM/DIAG/PCUI)
    char szbbInterfaceNumber[MTP_MAX_PATH] = {0};
    strcat(szbbInterfaceNumber, pDriverDir);
    strcat(szbbInterfaceNumber, "/%s/bInterfaceNumber");
    sprintf(szbFileName, (const char*)szbbInterfaceNumber, dirname); //"/sys/bus/usb/drivers/option/%s/bInterfaceNumber"�ļ�
    pfbInterfaceNumber = fopen(szbFileName, "r");
    if (NULL == pfbInterfaceNumber)
    {
        return FALSE;
    }

    memset(szbBuffer, 0, sizeof(szbBuffer));
    fread(szbBuffer, 1, sizeof(szbBuffer), pfbInterfaceNumber);
    fclose(pfbInterfaceNumber);
    //Trace_INFO("Get bInterfaceNumber: %s\n", szbBuffer);
    //�����豸PID��
    for(unsigned int i = 0; i < sizeof(Devices) / sizeof(struct DEVICEPORTS); i++)
    {
        if (strstr(pszPID, Devices[i].PID))
        {
            //ƥ�䡰bInterfaceNumber���ļ���ȡ�����ݺ�PID����number
            if (strstr(szbBuffer, Devices[i].modem.number))
            {
                port->type = MTP_PORT_MODEM;
                return TRUE;
            }
            else if (strstr(szbBuffer, Devices[i].diag.number))
            {
                port->type = MTP_PORT_DIAG;
                return TRUE;
            }
            else if (strstr(szbBuffer, Devices[i].pcui.number))
            {
                port->type = MTP_PORT_PCUI;
                return TRUE;
            }
            else if (strstr(szbBuffer, Devices[i].serial.number))
            {
                port->type = MTP_PORT_COM_B;
                return TRUE;
            }

            break;
        }
    }

    return FALSE;
}


BOOL CSerialPort::Open(const char * pszPortName, HPORT *hPort)
{

    if (!pszPortName || strlen(pszPortName) == 0)
    {
        return FALSE;
    }

    *hPort = open(pszPortName, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (*hPort < 0)
    {
        //Trace_INFO( "Open %s failed with error code %d.\n", pszPortName, errno);
        if (errno == 13)
        {
            //Trace_INFO( "\tPermission denied.\n");
        }
        return FALSE;
    }

    if(flock(*hPort,LOCK_EX|LOCK_NB) != 0)
        {
           close(*hPort);
           return FALSE;
        }

    struct termios opt;
    if (tcgetattr(*hPort, &opt) != 0)
    {
        Close(*hPort);
        return FALSE;
    }

    cfsetispeed(&opt, B115200);
    cfsetospeed(&opt, B115200);

    opt.c_cflag &= ~(CSIZE | CSTOPB | PARENB );
    opt.c_cflag |= CS8 | CREAD | CLOCAL;

    opt.c_lflag &= ~(ICANON | ISIG | ECHO);

    opt.c_oflag = ONLCR|OCRNL|IGNCR;

    opt.c_iflag &= ~(ISTRIP|IUCLC|IGNCR|ICRNL|INLCR|IXON|PARMRK|BRKINT|INPCK);
    opt.c_iflag |= IGNBRK|IGNPAR;

    cfmakeraw(&opt);    // Ī�������һ�д��룬Ӱ�첻�󣬲���ɾ

    opt.c_cc[VTIME] = 0;
    opt.c_cc[VMIN] = 0;

    if(tcsetattr(*hPort, TCSAFLUSH, &opt) != 0)
    {
        Close(*hPort);
        return FALSE;
    }

    return TRUE;
}


void CSerialPort::Close(HPORT hPort)
{
    if ( INVALID_HANDLE_VALUE != hPort )
    {
        close(hPort);
        hPort = INVALID_HANDLE_VALUE;
    }
}

int CSerialPort::Read( HPORT hPort, unsigned char * pBuffer, const unsigned int length, const int milliseconds)
{
    fd_set set;
    struct timeval tv;

    if (INVALID_HANDLE_VALUE == hPort)
    {
        printf("ERROR: %s port invalid\n", __func__);
        return -1;
    }

    FD_ZERO(&set);
    FD_SET(hPort, &set);

    if (milliseconds >= 0)
    {
        tv.tv_sec = milliseconds / 1000;
        tv.tv_usec = milliseconds % 1000 * 1000;
    }

    switch (select(hPort+1, &set, NULL, NULL, milliseconds >= 0 ? &tv : NULL))
    {
    case -1:    // error occured
        return -1;
    case 0:     // timeout
        return 0;
    default:
        if (pBuffer == NULL || length == 0)
        {
            int bytes = 0;
            return ioctl(hPort, FIONREAD, &bytes) < 0 ? -1 : bytes;
        }
        else
        {
            return read(hPort, pBuffer, length);
        }
        break;
    }

    return -1;
}


int CSerialPort::Write( HPORT hPort, unsigned char * pBuffer, const unsigned int length )
{
    if (INVALID_HANDLE_VALUE == hPort || NULL == pBuffer || 0 == length)
    {
        return -1;
    }

    ssize_t size = write(hPort, pBuffer, length);

    //if (size < 0 && EBADF == errno)
    //{
    //    logError(LOG_RMT, "error, file descriptor is invalid\n");
    //    return -1;
    //}

    return (int)size;
}

