﻿#include "OtaplusLogger.h"
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <time.h>

#define OTAPLUS_LOG_PATH "/data/modem_tool/logcat.log"

#define OTAPLUS_LOG_BAKPATH OTAPLUS_LOG_PATH "_bak"

const long MAX_LOG_FILE_SIZE = 1 * 1024 * 1024;  // 1MB

const int   INVALID_FD = -1;
const int   LOG_FILE_MODE = 0644;

OtaplusLogger* OtaplusLogger::s_pInstance = NULL;
bool OtaplusLogger::s_need_prefix = true;

OtaplusLogger* OtaplusLogger::Instance()
{
    if (s_pInstance == NULL)
    {
        s_pInstance = new OtaplusLogger();
    }

    return s_pInstance;
}

void OtaplusLogger::Destroy()
{
    if (s_pInstance != NULL)
    {
        delete s_pInstance;
        s_pInstance = NULL;
    }
}

OtaplusLogger::OtaplusLogger() : m_log_level(OTAPLUS_LOG_LEVEL_DEFAULT), m_fd_log(INVALID_FD)
{
    m_file_write = false;
}

OtaplusLogger::~OtaplusLogger()
{
    if (m_fd_log != INVALID_FD)
    {
        close(m_fd_log);
        m_fd_log = INVALID_FD;
    }
}

void OtaplusLogger::Init()
{
    // 如果日志文件不存在-则创建
    if (access(OTAPLUS_LOG_PATH, W_OK) == F_OK)
    {
        if (m_fd_log == INVALID_FD)
        {
            m_fd_log = open(OTAPLUS_LOG_PATH, O_RDWR | O_CREAT | O_TRUNC, LOG_FILE_MODE);
            return;
        }
    }

    if (m_fd_log != INVALID_FD)
    {
        if (m_file_write)
        {
            return;
        }
        else
        {
            close(m_fd_log);
        }
    }

    m_fd_log = open(OTAPLUS_LOG_PATH, O_RDWR | O_CREAT | O_APPEND, LOG_FILE_MODE);
    m_file_write = true;
}

void OtaplusLogger::Log(E_OTAPLUS_LOG_LEVEL level, const char* file_name, unsigned line, const char* log_msg, ...)
{
    Init();
    if ((m_fd_log == INVALID_FD) || (level < m_log_level))
    {
        return;
    }

    const unsigned MAX_STRING_IN_BYTES = 1124;
    char msg_full[MAX_STRING_IN_BYTES] = {0};
    char msg_write[MAX_STRING_IN_BYTES] = {0};

    va_list args;
    va_start(args, log_msg);
    vsnprintf(msg_full, sizeof(msg_full), log_msg, args);
    va_end(args);

    if (s_need_prefix)
    {
        // 获取当前时间戳
        time_t timestamp_cur;
        time(&timestamp_cur);
        struct tm * time_ds = localtime(&timestamp_cur);

        char timestamp_str[32] = { 0 };
        snprintf(timestamp_str, sizeof(timestamp_str), "%4d-%02d-%02d %02d:%02d:%02d",
                time_ds->tm_year + 1900, time_ds->tm_mon + 1, time_ds->tm_mday,
                time_ds->tm_hour, time_ds->tm_min, time_ds->tm_sec);

        snprintf(msg_write, sizeof(msg_write), "[%s] %s:%d %s\n", timestamp_str, file_name, line, msg_full);
    }
    else
    {
        snprintf(msg_write, sizeof(msg_write), "%s", msg_full);
    }

    size_t write_len = write(m_fd_log, msg_write, strlen(msg_write));
    if (write_len <= 0)
    {
        printf("write_len <= 0\n");
    }

    if (lseek(m_fd_log, 0, SEEK_CUR) > MAX_LOG_FILE_SIZE)
    {
        syncfs(m_fd_log);
        int ret_value = close(m_fd_log);
        if (ret_value != 0)
        {
            printf("%s close failed \n", __FUNCTION__);
        }
        else
        {
            m_fd_log = INVALID_FD;
            (void)rename(OTAPLUS_LOG_PATH, OTAPLUS_LOG_BAKPATH);
        }
    }

    return;
}

void OtaplusLogger::SetLogLevel(const char* log_level)
{
    if (!strcmp(log_level, "info"))
    {
        m_log_level = OTAPLUS_LOG_LEVEL_INFO;
    }
    else if (!strcmp(log_level, "warn"))
    {
        m_log_level = OTAPLUS_LOG_LEVEL_WARN;
    }
    else if (!strcmp(log_level, "error"))
    {
        m_log_level = OTAPLUS_LOG_LEVEL_ERR;
    }
    else
    {
        m_log_level = OTAPLUS_LOG_LEVEL_DEFAULT;
    }
}

