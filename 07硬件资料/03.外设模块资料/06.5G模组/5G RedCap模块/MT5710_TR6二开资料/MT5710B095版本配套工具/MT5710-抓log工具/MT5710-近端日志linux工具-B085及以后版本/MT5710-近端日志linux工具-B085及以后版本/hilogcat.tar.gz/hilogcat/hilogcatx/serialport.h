#pragma once
#include "mtpdef.h"

#define MTP_MAX_PORT_NAME 48
#define MTP_MAX_PORT_SIZE 16

typedef enum _MTP_PORT_TYPE
{
    MTP_PORT_UNKNOWN    = 0,
    MTP_PORT_MODEM      = 1,
    MTP_PORT_PCUI       = 2,
    MTP_PORT_DIAG       = 3,
    MTP_PORT_PCSC       = 4,
    MTP_PORT_NMEA       = 5,
    MTP_PORT_GPS_CTRL   = 6,
    MTP_PORT_WIN_NDIS   = 7,
    MTP_PORT_ECM_DATA   = 8,
    MTP_PORT_ECM_CTRL   = 9,
    MTP_PORT_BLUETOOTH  = 0x0A,
    MTP_PORT_FINGERPRNT = 0x0B,
    MTP_PORT_ACM_CTRL   = 0x0C,
    MTP_PORT_MMS        = 0x0D,
    MTP_PORT_VOICE      = 0x0E,
    MTP_PORT_DVB        = 0x0F,
    MTP_PORT_MODEM_NO3G = 0x10,
    MTP_PORT_NDIS_NO3G     = 0x11,
    MTP_PORT_PCUI_NO3G     = 0x12,
    MTP_PORT_DIAG_NO3G  = 0x13,
    MTP_PORT_GPS_NO3G   = 0x14,
    MTP_PORT_VOICE_NO3G = 0x15,
    MTP_PORT_NCM        = 0x16,
    MTP_PORT_MODEM_ORNG = 0x17,
    MTP_PORT_SHELL_A    = 0x18,
    MTP_PORT_SHELL_B    = 0x19,
    MTP_PORT_COM_A      = 0x1A,
    MTP_PORT_COM_B      = 0x1B,
    MTP_PORT_COM_C      = 0x1C,
    MTP_PORT_GNSS       = 0x1D,
} MTP_PORT_TYPE;

typedef struct _MTP_PORT_INFO
{
    MTP_PORT_TYPE   type;
    char            name[MTP_MAX_PORT_NAME];
    int             reserved;
} MTP_PORT_INFO;

typedef struct _MTP_PORT_LIST
{
    MTP_PORT_INFO   list[MTP_MAX_PORT_SIZE];
    int             actNum;
} MTP_PORT_LIST;

class CSerialPort
{
public:
    CSerialPort(void);
    virtual ~CSerialPort(void);

    static void EnumAllPorts(MTP_PORT_LIST * port_list);
    static void EnumAllPortsByDir(MTP_PORT_LIST * port_list, const char* pDriverDir);
    static const char * PortType(MTP_PORT_TYPE type);

    //�򿪶˿�
    /**
    * @param pszPortName    [in] �˿�����
    * @return ������
    */
    BOOL Open( const char * pszPortName, HPORT *hPort );


    //�رն˿�.����˿�δ�򿪣���ֱ�ӷ���.
    void Close(HPORT hPort);


    //������
    /**
    * @param pBuffer        [out] ������ָ��
    * @param length         [in] ��������С
    * @param milliseconds   [in] ��ʱʱ��,��λ:����.����-1��ʾ���޵ȴ�.
    * @return ʵ�ʶ�ȡ���ֽڳ���. ����-1��ʾ��ȡ����.
    */
    int Read( HPORT hPort, unsigned char * pBuffer, const unsigned int length, const int milliseconds = -1);


    //ͬ��д����.
    /**
    * @param pBuffer        [out] ������ָ��
    * @param length         [in] ��������С
    * @return ʵ��д����ֽڳ���. ����-1��ʾд�����.
    */
    int Write(HPORT hPort, unsigned char * pBuffer, const unsigned int length );

private:
    static BOOL MactchInterfaceNumber(const char* pDriverDir, const char * pszPID, const char * dirname, MTP_PORT_INFO * port);
    static BOOL IsValidVid(const char * pszModaliasData);
    static BOOL FindPortName(const char * path, char name[MTP_MAX_PORT_NAME], BOOL oldPid);
};
