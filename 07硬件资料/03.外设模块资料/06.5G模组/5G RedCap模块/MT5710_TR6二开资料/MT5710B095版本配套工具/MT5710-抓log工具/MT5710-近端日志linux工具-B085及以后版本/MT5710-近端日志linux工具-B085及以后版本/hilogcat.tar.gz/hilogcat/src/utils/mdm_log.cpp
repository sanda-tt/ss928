#include "mdm_log.h"
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/time.h>
#include <fcntl.h>
#include <ctime>
#include <inc/custom_define.h>

using namespace std;
using namespace ModemLogMdmLog;

MdmLog::MdmLog()
    : m_fd(0),
      m_fileName(LOGCAT_LOG),
      m_fileMutexFlag(false),
      m_ulFileMaxSize(LOG_FILE_MAX_SIZE)
{
    if (pthread_mutex_init(&m_fileMutex, nullptr) == 0) {
        m_fileMutexFlag = true;
    }
}

MdmLog::~MdmLog()
{
    if (m_fd > 0) {
        close(m_fd);
        m_fd = 0;
    }

    if (m_fileMutexFlag == true) {
        pthread_mutex_destroy(&m_fileMutex);
        m_fileMutexFlag = false;
    }
}

uint32_t MdmLog::GetFileSize(const char *filename)
{
    struct stat buf;
    if (stat(filename, &buf) < 0) {
        return 0;
    }
    return (uint32_t)buf.st_size;
}

void MdmLog::Open(const char *pfileName)
{
    if (GetFileSize(pfileName) > m_ulFileMaxSize) {
        string sRet = ModifyFileName(pfileName);
        if (sRet != "") {
            rename(pfileName, sRet.c_str());
        }
    }
    const uint32_t authority = 0644;
    m_fd = open(pfileName, O_RDWR | O_CREAT | O_APPEND, authority);
};

void MdmLog::Close()
{
    if (m_fd > 0) {
        close(m_fd);
        m_fd = 0;
    }
}

void MdmLog::WriteLog(MdmLogType logType, string fileName, uint32_t lineNumber, string funcName, const char *fmt, ...)
{
    // 解决modemlogcat 格式化字符串奔溃 20170730 mawenming
    if (fmt == nullptr || m_fileMutexFlag == false) {
        return;
    }
    pthread_mutex_lock(&m_fileMutex);
    const char *fileNameHere = m_fileName.c_str();
    Open(fileNameHere);
    if (m_fd < 0) {
        pthread_mutex_unlock(&m_fileMutex);
        return;
    }

    // get current time
    struct timeval tv;
    struct timezone tz;
    gettimeofday(&tv, &tz);
    time_t tsec = time(nullptr);
    struct tm *tstruct = localtime(&tsec);
    const int timeLength = 32;
    char timeBuf[timeLength] = {0};
    if (tstruct != nullptr) {
        strftime(timeBuf, sizeof(timeBuf), "%m-%d %H:%M:%S", tstruct);
    } else {
        const char *strbuf = "unknown-time";
       #ifdef USE_CCC_TDT
        strncpy(timeBuf, strbuf, strlen(strbuf));
        #endif
    }
    char logBuf[MAX_LOG_BUF_LEN] = {0};
   #ifdef USE_CCC_TDT
    int ret = snprintf(logBuf, sizeof(logBuf) - 1, "%s.%06ld\t%s\t[%s:%u:%s] ", timeBuf, tv.tv_usec,
                         MODEM_LOG_TYPE[logType].c_str(), fileName.c_str(), lineNumber, funcName.c_str()); // 长度控制在范围之内
    if (ret < 0) {
        Close();
        pthread_mutex_unlock(&m_fileMutex);
        return;
    }
    #endif
    va_list args;
    va_start(args, fmt);

   #ifdef USE_CCC_TDT
    // clean converity 20170815 mawenming, 最多只能拷贝sizeof(logBuf) - ret - 1个，否则越界
    ret = vsnprintf(logBuf + ret, sizeof(logBuf) - ret - 1, fmt, args);
    if (ret < 0) {
        Close();
        va_end(args);
        pthread_mutex_unlock(&m_fileMutex);
        return;
    }
    #endif
    write(m_fd, logBuf, strlen(logBuf));
    write(m_fd, "\n", 1);
    Close();

    pthread_mutex_unlock(&m_fileMutex);
    return;
}


string MdmLog::ModifyFileName(const char *fileSrcName)
{
    if (fileSrcName == nullptr) {
        return "";
    }

    time_t t;
    const int timeLength = 30;
    char timeStamp[timeLength] = {0};
    string fileDstName;
    fileDstName += fileSrcName;

    time(&t);
    struct tm *tmp_time = localtime(&t);
    strftime(timeStamp, sizeof(timeStamp), "%Y%m%d-%H%M%S", tmp_time);
    fileDstName.insert(fileDstName.size() - strlen(".txt"), timeStamp);

    return fileDstName;
}
