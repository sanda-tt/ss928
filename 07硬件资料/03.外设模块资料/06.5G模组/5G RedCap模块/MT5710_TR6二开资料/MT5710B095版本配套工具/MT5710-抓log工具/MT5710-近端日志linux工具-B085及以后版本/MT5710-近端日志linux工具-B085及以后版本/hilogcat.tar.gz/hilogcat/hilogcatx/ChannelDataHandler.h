/*******************************************************************************
*
*  ChannelDataHandler.cpp: implementation of the CChannelDataHandler class.
*
********************************************************************************/

#if !defined(AFX_CHANNELDATAHANDLER_H__D0A252D4_C004_463C_926C_7FAD1A3A4DBC__INCLUDED_)
#define AFX_CHANNELDATAHANDLER_H__D0A252D4_C004_463C_926C_7FAD1A3A4DBC__INCLUDED_

#include <stdlib.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/file.h>
#include <pthread.h>

#include "OtaplusLogger.h"
#include "FileReceiver.h"
#include "CommonDef.h"
#include "ATService.h"
#include "typedef.h"


class CChannelDataHandler
{

public:
    CChannelDataHandler();
    virtual ~CChannelDataHandler();

public:

    BOOL CaptureAPOfflineLog(char *argv);
    BOOL CaptureCPOfflineLog();
    BOOL StopCPOfflineLog();
	
protected:
    FileReceiver*    m_pFileReceiver;
    DataChannel*     m_pDataChannel;
    
};

#endif // !defined(AFX_CHANNELDATAHANDLER_H__D0A252D4_C004_463C_926C_7FAD1A3A4DBC__INCLUDED_)
