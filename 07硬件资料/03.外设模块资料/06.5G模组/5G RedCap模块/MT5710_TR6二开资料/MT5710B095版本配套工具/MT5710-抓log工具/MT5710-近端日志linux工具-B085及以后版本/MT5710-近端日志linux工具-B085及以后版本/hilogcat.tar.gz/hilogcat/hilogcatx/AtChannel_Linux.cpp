﻿#include "AtChannel_Linux.h"
#include <string.h>

const char* QUERY_ATCHNL_CMD = "ls -d /sys/bus/usb/devices/*-*/*:*.2/ttyUSB* 2>/dev/null";
const char* ATCHNL_PATH_PCIE = "/dev/stty_nr31";

AtChannel::AtChannel(const char* chnl_path) : DataChannel(chnl_path)
{
    // DO NOTHING but initialization
}

RET_CODE AtChannel::GetDevList(list<string>& dev_list)
{
    dev_list.push_back(m_chnl_path);

    return ERR_CODE_SUCCESS;
}

const char* AtChannel::GetChnlQueryScript(bool /* is_1st_try */)
{
    LOG_WARN("%s => %s\n", __FUNCTION__, QUERY_ATCHNL_CMD);
    return QUERY_ATCHNL_CMD;
}

const char* AtChannel::GetPcieChnlPath()
{
    return ATCHNL_PATH_PCIE;
}

