 /*
* \file OS_Adapt_PortOperationImpl.h
*
* \brief Port operation implement file
*
* Copyright (C) 2009 Tdtech Technologies Co.,Ltd
*
* \author: 
*
* \version 2.0
*/
#include "OS_Adapt_PortOperationImpl_Android.h"

COSAdapt::COSAdapt()
{

}

COSAdapt::~COSAdapt()
{

}

OS_ADAPT_ERROR COSAdapt::EnumDevicePortInfo( OS_ADAPT_PORT_TYPE enPortType, OS_ADAPT_DEVICEINFOLIST* pstDeviceInfoList )
{
    MTP_PORT_LIST ports;
    m_serialPort.EnumAllPorts(&ports);
    if( 0 < ports.actNum )
    {
        pstDeviceInfoList->lDeviceCount = 1;
        pstDeviceInfoList->szStDeviceInfo[0].lPortCount = ports.actNum;
    }
    for(int i = 0; i <  ports.actNum; i++ )
    {
        strcpy(pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].szPortName, ports.list[i].name);
        switch(ports.list[i].type)
        {
        case MTP_PORT_PCUI:
        case MTP_PORT_PCUI_NO3G:
            pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].enPortType = OS_ADAPT_PCUI_PORT;
            break;
        case MTP_PORT_DIAG:
        case MTP_PORT_DIAG_NO3G:
            pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].enPortType = OS_ADAPT_DIAG_PORT;
            break;
        case MTP_PORT_MODEM:
        case MTP_PORT_MODEM_NO3G:
            pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].enPortType = OS_ADAPT_MODEM_PORT;
            break;
        case MTP_PORT_COM_B:
            pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].enPortType = OS_ADAPT_COMB_PORT;
            break;
        default:
            pstDeviceInfoList->szStDeviceInfo[0].szStPortInfo[i].enPortType = OS_ADAPT_COMM_PORT;
        }
    }
    return OS_ADAPT_ERROR_SUCCED;
}

OS_ADAPT_ERROR COSAdapt::OpenPort( const char* pszPortName, PORT_HANDLE* phFileDesc )
{
    if( m_serialPort.Open( pszPortName, (HPORT *)phFileDesc))
    {
        return OS_ADAPT_ERROR_SUCCED;
    }
    return OS_ADAPT_ERROR_FAILED;
}

OS_ADAPT_ERROR COSAdapt::ClosePort( PORT_HANDLE hFileDesc )
{
    m_serialPort.Close((HPORT)hFileDesc);
    return OS_ADAPT_ERROR_SUCCED;
}

OS_ADAPT_ERROR COSAdapt::Read( PORT_HANDLE hFileDesc, void* pBuffer, long lInSize, long* plOutSize )
{
    *plOutSize  = m_serialPort.Read((HPORT)hFileDesc, (unsigned char*)pBuffer, lInSize );
    if( *plOutSize > 0 )
    {
        return OS_ADAPT_ERROR_SUCCED;
    }
    return OS_ADAPT_ERROR_FAILED;
}

OS_ADAPT_ERROR COSAdapt::Write( PORT_HANDLE hFileDesc, void* pBuffer, long lInSize, long* plOutSize )
{
    *plOutSize  = m_serialPort.Write((HPORT)hFileDesc, (unsigned char*)pBuffer, lInSize );
    if( *plOutSize > 0 )
    {
        return OS_ADAPT_ERROR_SUCCED;
    }
    return OS_ADAPT_ERROR_FAILED;
}

void COSAdapt::SetPortMode( OS_ADAPT_MODE mode )
{
    
}

OS_ADAPT_MODE COSAdapt::GetPortMode()
{
    return SERIAL_MODE;
}

OS_ADAPT_ERROR COSAdapt::UnRegisterDeviceStateProcessCallBack( OS_ADAPT_DEVICE_STATE_PROCESS_CALLBACK_FUNC pfnFunc )
{
    return OS_ADAPT_ERROR_FAILED;
}

OS_ADAPT_ERROR COSAdapt::RegisterDeviceStateProcessCallBack( OS_ADAPT_DEVICE_STATE_PROCESS_CALLBACK_FUNC pfnFunc )
{
    return OS_ADAPT_ERROR_FAILED;
}

OS_ADAPT_PORTSTATUS_TYPE COSAdapt::GetPortState( const char* pszPortName )
{
    return OS_ADAPT_PORT_UNKNOWN;
}

OS_ADAPT_ERROR COSAdapt::FindPortByDriverToolString(OS_ADAPT_PORT_TYPE enPortType, OS_ADAPT_DEVICEINFOLIST* pstDeviceInfoList)
{
    return OS_ADAPT_ERROR_FAILED;
}