﻿#ifndef ATCHANNEL_LINUX_H_
#define ATCHANNEL_LINUX_H_

#include "DataChannel_Linux.h"
#include "CommonDef.h"
#include <string>

class AtChannel : public DataChannel
{
public:
    AtChannel(const char* chnl_path = "");

    ~AtChannel()
    {
        // DO NOTHING
    }

    virtual bool CanChnlChange() { return false; }

    virtual const char* GetChnlQueryScript(bool is_1st_try);

    virtual const char* GetPcieChnlPath();

    RET_CODE GetDevList(list<string>& dev_list);
};

#endif /* ATCHANNEL_LINUX_H_ */
