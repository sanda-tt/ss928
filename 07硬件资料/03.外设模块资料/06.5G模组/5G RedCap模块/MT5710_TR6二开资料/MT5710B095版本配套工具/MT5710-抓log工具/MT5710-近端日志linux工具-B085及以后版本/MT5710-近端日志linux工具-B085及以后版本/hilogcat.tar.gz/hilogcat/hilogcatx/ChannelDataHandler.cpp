/*******************************************************************************
*
*  ChannelDataHandler.cpp: implementation of the CChannelDataHandler class.
*
********************************************************************************/
#include "CommonDef.h"
#include "DataChannel_Linux.h"
#include "ChannelDataHandler.h"

#include <stdio.h>
#include <string.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <string>
#include <algorithm>
#include <dirent.h>
#include <sys/file.h>
#include <vector>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/shm.h>
#include <netinet/tcp.h>

extern "C"
{
#include "confile.h"
}

const char* PcuiPort = "/dev/ttyUSB1";
const char* SET_AT_CMD_MDON4 = "AT^XMODEMLOG=4\r\n";
const char* SET_AT_CMD_MDON3 = "AT^XMODEMLOG=3\r\n";
const char* SET_AT_CMD_MDON2 = "AT^XMODEMLOG=2\r\n";
const char* SET_AT_CMD_MDON1 = "AT^XMODEMLOG=1\r\n";
const char* SET_AT_CMD_MDON0 = "AT^XMODEMLOG=0\r\n";
const char* SET_AT_CMD_LOGCAT1 = "AT^LOGCATSWITCH=1\r\n";
const char* SET_AT_CMD_LOGCAT0 = "AT^LOGCATSWITCH=0\r\n";

/*******************************************************************************
*  Construction/Destruction
********************************************************************************/
CChannelDataHandler::CChannelDataHandler()
{

    m_pFileReceiver = NULL;
    m_pDataChannel  = NULL;

}

CChannelDataHandler::~CChannelDataHandler()
{
    if (m_pFileReceiver != NULL)
    {
        delete m_pFileReceiver;
        m_pFileReceiver = NULL;
    }
    if (m_pDataChannel != NULL)
    {
        delete m_pDataChannel;
        m_pDataChannel = NULL;
    }
}

BOOL CChannelDataHandler::CaptureAPOfflineLog(char *argv)
{
    int  retVal = ERR_CODE_SUCCESS;
    char fileName[256]  = {0};
    char *cmd = NULL;

    if (m_pFileReceiver != NULL)
    {
        delete m_pFileReceiver;
        m_pFileReceiver = NULL;
    }

    m_pFileReceiver = new FileReceiver();

    if(NULL == m_pFileReceiver)
    {
        LOG_ERROR("Create FileReceiver object failed.");
        return FALSE;
    }

        FILE *fp = fopen(PcuiPort, "r+");
        if (fp == NULL) {
            LOG_WARN("fopen failed, errno: %d\n", errno);
            return FALSE;
        }
        if (strcmp(argv, "0") == 0) {
            fputs(SET_AT_CMD_MDON0, fp);
		} else if (strcmp(argv, "1") == 0) {
            fputs(SET_AT_CMD_MDON1, fp);
		} else if (strcmp(argv, "2") == 0) {
            fputs(SET_AT_CMD_MDON2, fp);
		} else if (strcmp(argv, "3") == 0) {
            fputs(SET_AT_CMD_MDON3, fp);
		} else {
            fputs(SET_AT_CMD_MDON4, fp);
		}

        fclose(fp);
        sprintf(fileName, "./log.tar.gz");
        retVal = m_pFileReceiver->Receive(fileName, DATACHANNEL_MODE_USB);
        if(retVal != ERR_CODE_SUCCESS)
        {
            LOG_WARN("Error respond code : %d\n.", retVal);
        }


    return TRUE;
}

BOOL CChannelDataHandler::CaptureCPOfflineLog()
{
		FILE *fp = fopen(PcuiPort, "r+");
        if (fp == NULL) {
            LOG_WARN("fopen failed, errno: %d\n", errno);
            return FALSE;
        }
        fputs(SET_AT_CMD_LOGCAT1, fp);
        fclose(fp);
        sleep(6);
        return TRUE;
}

BOOL CChannelDataHandler::StopCPOfflineLog()
{
		FILE *fp = fopen(PcuiPort, "r+");
        if (fp == NULL) {
            LOG_WARN("fopen failed, errno: %d\n", errno);
            return FALSE;
        }
        fputs(SET_AT_CMD_LOGCAT0, fp);
        fclose(fp);
        sleep(1);
        return TRUE;
}

